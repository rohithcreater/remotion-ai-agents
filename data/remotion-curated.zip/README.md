# remotion-curated (merged from 3 datasets)

Chat-format SFT data (system / user / assistant) for text-to-Remotion-project generation.
Splits: train 9,519 | validation 787 | test 775. Total 11,081.

## Sources (original splits preserved, so no train/test leakage)
- remotion-30s-3000: 2,485 train. Full 30 s storyboarded videos (promo/explainer, 15 scene types).
- remotion-combined-9149: 2,473 train. 36 families (2D ads, charts, titles, CSS-3D, three.js).
- toon3d_dataset: 4,561 train. Drawn 2.5D SVG characters, 100 character x background families.

## What was filtered
1. All 5 project files present; package.json valid; remotion pinned to 4.0.539.
2. Source static checks all true; quality_score 1.0.
3. Every distinct code shape (4,445) type-checked with strict TypeScript against the REAL remotion 4.0.539 typings
   (+ @remotion/three, @remotion/transitions). 0 failures.
4. Prompts with conflicting outputs removed; exact duplicate outputs removed (none found).
5. Per-code-shape cap (train: combined 40, toon 5, 30s 4) so no single template dominates.
   This removed 6,014 near-identical combined records; the other sources lost 54.
6. Unified system prompt; every answer starts with a '// PLAN:' line (combined plans are built from its
   timeline/family fields, not invented).

## NOT verified
- User-reported render verification: the merged set was rendered and everything appeared correct.
- Variety is compositional (templates + parameters), not hand-made creative range.
- Assistant answers are ~11.5k chars (~3.4k tokens) median, 17.8k max: train with >= 8k context.
