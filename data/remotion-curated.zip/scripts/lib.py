import json,re,hashlib
FILE_RE=re.compile(r'^// ===== FILE: (.+?) =====\s*$',re.M)
def parse_files(out):
    """returns (plan_line_or_None, {path: content})"""
    ms=list(FILE_RE.finditer(out)); files={}
    plan=out[:ms[0].start()].strip() if ms else out.strip()
    for i,m in enumerate(ms):
        end=ms[i+1].start() if i+1<len(ms) else len(out)
        files[m.group(1)]=out[m.end():end].strip('\n')+'\n'
    return (plan or None),files
def norm(s):
    s=re.sub(r'"(?:[^"\\\n]|\\.)*"','"s"',s); s=re.sub(r"'(?:[^'\\\n]|\\.)*'","'s'",s); s=re.sub(r'`[^`]*`','`s`',s)
    s=re.sub(r'#[0-9a-fA-F]{3,8}','#c',s); return re.sub(r'\d+(\.\d+)?','0',s)
def h(s): return hashlib.md5(s.encode()).hexdigest()
def load(p):
    return [json.loads(l) for l in open(p)]
