import json,collections,random,re,os
from lib import *
random.seed(7)
SYSTEM=("You are an expert Remotion v4 + TypeScript motion designer. Given a video brief, reply with one line starting with '// PLAN:' "
        "summarising the motion design, then the complete project as files, each introduced by a line '// ===== FILE: <path> =====' "
        "followed by the file contents. Use only 'remotion' and the dependencies listed in package.json. All animation must be a pure "
        "function of useCurrentFrame() so frames render deterministically.")
SRC=[('30s','remotion-30s-3000/%s.jsonl'),('comb','remotion-combined-9149/%s.jsonl'),('toon','toon3d_dataset/dataset/%s.jsonl')]
CAP={'30s':{'train':4,'validation':4,'test':4},'comb':{'train':40,'validation':6,'test':6},'toon':{'train':5,'validation':3,'test':3}}
bad=set(json.load(open('tc_state.json'))['bad']); r2s=json.load(open('rec2shape.json'))
REQ=['package.json','tsconfig.json','src/index.ts','src/Root.tsx','src/Video.tsx']
drops=collections.Counter(); keep=collections.defaultdict(list)
def plan_for(name,r,plan,files):
    if plan: return plan.replace('\n',' ')
    if name=='30s': return '// PLAN: '+re.sub(r'^Plan:\s*','',r['thought']).replace('\n',' ')
    tl=r.get('timeline') or {}
    return (f"// PLAN: {r.get('family','scene').replace('_',' ')} ({r.get('category','')}), {tl.get('width')}x{tl.get('height')} at {tl.get('fps')} fps, "
            f"{tl.get('durationInFrames')} frames, rendered with {r.get('rendering_tech')}; every animated value is a pure function of useCurrentFrame().")
for name,p in SRC:
    for sp in ['train','validation','test']:
        pool=collections.defaultdict(list)
        for r in load(p%sp):
            out=r['output'] if 'output' in r else r['messages'][2]['content']
            user=r['instruction'] if 'instruction' in r else r['messages'][1]['content']
            plan,f=parse_files(out)
            def drop(why): drops[(name,why)]+=1
            if any(x not in f for x in REQ): drop('missing_file'); continue
            try: pj=json.loads(f['package.json']); d=pj['dependencies']
            except Exception: drop('bad_package_json'); continue
            if d.get('remotion')!='4.0.539': drop('unpinned'); continue
            sc=r.get('static_checks')
            if isinstance(sc,dict) and not all(v is True for v in sc.values()): drop('static_check_fail'); continue
            if r.get('quality_score') not in (None,1.0): drop('quality<1'); continue
            if r2s[f'{name}|{r["id"]}'] in bad: drop('tsc_fail'); continue
            if not user.strip() or len(f['src/Video.tsx'])<400: drop('too_small'); continue
            if 'Composition' not in f['src/Root.tsx'] or 'useCurrentFrame' not in f['src/Video.tsx'] and name!='toon': drop('no_frame_driven'); continue
            pool[r2s[f'{name}|{r["id"]}']].append((r,user,out,plan,f))
        for shape,items in pool.items():
            random.shuffle(items); n=0
            for it in items:
                if n>=CAP[name][sp]: drops[(name,'shape_cap')]+=1; continue
                keep[sp].append((name,)+it); n+=1
# ambiguity + exact dup removal over all splits
seen_user=collections.defaultdict(set); seen_out=set(); final=collections.defaultdict(list)
for sp in ['train','validation','test']:
    for name,r,user,out,plan,f in keep[sp]: seen_user[user].add(h(out))
for sp in ['train','validation','test']:
    for name,r,user,out,plan,f in keep[sp]:
        if len(seen_user[user])>1: drops[(name,'ambiguous_prompt')]+=1; continue
        if h(out) in seen_out: drops[(name,'dup_output')]+=1; continue
        seen_out.add(h(out))
        a=plan_for(name,r,plan,f)+'\n\n'+'\n\n'.join(f'// ===== FILE: {k} =====\n{f[k].rstrip()}' for k in REQ)+'\n'
        final[sp].append({'id':f'{name}-{r["id"]}','source':name,'family':r.get('family'),'messages':[{'role':'system','content':SYSTEM},{'role':'user','content':user},{'role':'assistant','content':a}]})
os.makedirs('out',exist_ok=True)
for sp in final:
    random.shuffle(final[sp])
    with open(f'out/{sp}.jsonl','w') as o:
        for x in final[sp]: o.write(json.dumps(x,ensure_ascii=False)+'\n')
print({sp:len(v) for sp,v in final.items()})
print(collections.Counter(x['source'] for x in final['train']))
for k,v in sorted(drops.items()): print(k,v)
