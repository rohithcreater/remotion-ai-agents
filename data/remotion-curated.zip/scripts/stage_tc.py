import json,os,subprocess,shutil,sys,collections
from lib import *
SRC=[('30s','remotion-30s-3000/%s.jsonl'),('comb','remotion-combined-9149/%s.jsonl'),('toon','toon3d_dataset/dataset/%s.jsonl')]
reps={}   # shape -> (name,id,files)
rec2shape={}
for name,p in SRC:
    for sp in ['train','validation','test']:
        for r in load(p%sp):
            out=r['output'] if 'output' in r else r['messages'][2]['content']
            _,f=parse_files(out)
            k=h(norm(f.get('src/Video.tsx',''))+norm(f.get('src/Root.tsx',''))+norm(f.get('src/index.ts','')))
            rec2shape[(name,r['id'])]=k
            if k not in reps: reps[k]=(name,r['id'],f)
json.dump({f"{a}|{b}":v for (a,b),v in rec2shape.items()},open('rec2shape.json','w'))
keys=sorted(reps); BATCH=500
import os.path
state=json.load(open('tc_state.json')) if os.path.exists('tc_state.json') else {'done':[],'bad':{}}
bad=state['bad']
for bi in range(0,len(keys),BATCH):
    if bi in state['done']: continue
    batch=keys[bi:bi+BATCH]; d=f'tc/p{bi}'; shutil.rmtree(d,ignore_errors=True)
    for k in batch:
        for path,c in reps[k][2].items():
            if path.startswith('src/'):
                fp=f'{d}/{k}/{path}'; os.makedirs(os.path.dirname(fp),exist_ok=True); open(fp,'w').write(c)
    ts={"compilerOptions":{"target":"ES2020","module":"ESNext","moduleResolution":"bundler","jsx":"react-jsx","strict":True,"noEmit":True,"skipLibCheck":True,"esModuleInterop":True,"lib":["DOM","ES2020"],"types":[]},"include":[f"p{bi}/**/src/*.ts*"]}
    json.dump(ts,open(f'tc/tsconfig.p{bi}.json','w'))
    r=subprocess.run(['node_modules/.bin/tsc','-p',f'tsconfig.p{bi}.json'],cwd='tc',capture_output=True,text=True)
    errs=collections.defaultdict(list)
    for line in (r.stdout+r.stderr).splitlines():
        if line.startswith(f'p{bi}/'):
            k=line.split('/')[1]; errs[k].append(line[:200])
    for k,v in errs.items(): bad[k]=v[:3]
    print(bi,len(batch),'errors in',len(errs),flush=True)
    shutil.rmtree(d,ignore_errors=True)
    state['done'].append(bi); json.dump(state,open('tc_state.json','w'))
json.dump(bad,open('tc_bad.json','w'))
print('total shapes',len(keys),'bad',len(bad))
