import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#2b3cff', bg2: '#4050ff', fg: '#ffffff', accent: '#ffffff', acc2: '#ffd23f',
  muted: '#959eff', card: '#3a4aff', line: '#4957ff', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';
const rnd = (seed: number) => { const s = Math.sin(seed * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const Hud: React.FC<{label: string}> = ({label}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const s = Math.floor(frame / fps), f = frame % fps;
  const tc = `TC 00:00:${String(s % 60).padStart(2, '0')}:${String(f).padStart(2, '0')}`;
  const u = Math.min(width, height) / 1080;
  const corner = (pos: React.CSSProperties): React.CSSProperties => ({position: 'absolute', width: 36 * u, height: 36 * u, border: `${3 * u}px solid ${C.fg}`, ...pos});
  const txt: React.CSSProperties = {position: 'absolute', fontFamily: MONO, fontSize: 20 * u, letterSpacing: '0.14em', textTransform: 'uppercase', color: C.fg};
  const m = 40 * u;
  return (
    <AbsoluteFill style={{opacity: 0.7, pointerEvents: 'none'}}>
      <div style={corner({top: m, left: m, borderRight: 0, borderBottom: 0})} />
      <div style={corner({top: m, right: m, borderLeft: 0, borderBottom: 0})} />
      <div style={corner({bottom: m, left: m, borderRight: 0, borderTop: 0})} />
      <div style={corner({bottom: m, right: m, borderLeft: 0, borderTop: 0})} />
      <div style={{...txt, top: m + 10 * u, left: m + 56 * u}}>Claude / Motion Reel</div>
      <div style={{...txt, top: m + 10 * u, right: m + 56 * u}}>{width}×{height} · {fps}P</div>
      <div style={{...txt, bottom: m + 10 * u, left: m + 56 * u}}>{tc}</div>
      <div style={{...txt, bottom: m + 10 * u, right: m + 56 * u}}>{label}</div>
    </AbsoluteFill>
  );
};

const WORD = 'SHIFT';
const P = 66, OFF = 3 * 2, STEP = 2; // glitch re-rolls every STEP frames
const slice = (seed: number) => {
  const on = rnd(seed * 1.7) > 0.45;
  const a = Math.floor(rnd(seed * 3.1) * 80), b = Math.floor(rnd(seed * 5.3) * (100 - a - 5));
  const dx = (rnd(seed * 7.9) > 0.5 ? 1 : -1) * (2 + Math.floor(rnd(seed * 9.7) * 10)) * 2;
  return on ? {clip: `inset(${a}% 0 ${b}% 0)`, dx} : {clip: 'inset(0)', dx: 0};
};
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const size = Math.min(width * 0.16, height * 0.3);
  const ph = (frame % P) / P;
  const tick = Math.floor(frame / STEP);
  const sa = slice(tick + 11), sb = slice(tick + 97);
  // main word jitter only near the end of each loop
  const jit = ph > 0.9 && ph < 0.96 ? (ph < 0.93 ? 8 : -6) : 0;
  const layer = (color: string, left: number, s: {clip: string; dx: number}) => (
    <div style={{position: 'absolute', inset: 0, color, left, mixBlendMode: 'screen', clipPath: s.clip, transform: `translateX(${s.dx}px)`}}>{WORD}</div>
  );
  return (
    <div style={{position: 'relative', fontSize: size, fontWeight: 900, letterSpacing: '-0.045em', transform: `skewX(${jit}deg) translateX(${jit * 0.8}px)`}}>
      {WORD}
      {layer('#ff2a55', -OFF, sa)}
      {layer('#22e6ff', OFF, sb)}
      <div style={{position: 'fixed', inset: 0, background: 'repeating-linear-gradient(0deg, #0000 0 4px, #0000001f 4px 6px)', pointerEvents: 'none'}} />
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
      <Hud label="07 — GLITCH" />
  </Stage>
);
