import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';

const C = {
  bg: '#fff1f0', bg2: '#fffafa', fg: '#2a0f12', accent: '#ff4d6d', acc2: '#ffb703',
  muted: '#948081', card: '#fffcfb', line: '#e1d1d1', on: '#ffffff', sh: '#0000001f', sh2: '#00000033',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const rnd = (seed: number) => { const s = Math.sin(seed * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const N = 700, PULL = 80, TRAIL = 12, DUR = 240;
const COLS = ["#ff4d6d", "#ffb703", "#948081"];
const WIDTH = 1920, HEIGHT = 1080;
// Deterministic simulation: positions for every frame are computed once, so any frame can be rendered in any order.
const TRAJ: Float32Array[] = (() => {
  const px = new Float32Array(N), py = new Float32Array(N), vx = new Float32Array(N), vy = new Float32Array(N);
  for (let i = 0; i < N; i++) { px[i] = rnd(i * 2 + 1) * WIDTH; py[i] = rnd(i * 2 + 2) * HEIGHT; }
  const out: Float32Array[] = [];
  for (let f = 0; f < DUR; f++) {
    const t = (f / 30) * 1000;
    const ax = WIDTH / 2 + Math.cos(t / 1100) * WIDTH * 0.25, ay = HEIGHT / 2 + Math.sin(t / 1700) * HEIGHT * 0.25;
    const snap = new Float32Array(N * 2);
    for (let i = 0; i < N; i++) {
      const dx = ax - px[i], dy = ay - py[i], d = Math.hypot(dx, dy) + 30, k = (PULL / d) * 0.0016 * 2;
      vx[i] = (vx[i] + dx * k) * 0.97; vy[i] = (vy[i] + dy * k) * 0.97;
      px[i] += vx[i] * 2; py[i] += vy[i] * 2;
      snap[i * 2] = px[i]; snap[i * 2 + 1] = py[i];
    }
    out.push(snap);
  }
  return out;
})();
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ref = React.useRef<HTMLCanvasElement | null>(null);
  React.useEffect(() => {
    const c = ref.current; if (!c) return;
    const x = c.getContext('2d'); if (!x) return;
    x.clearRect(0, 0, WIDTH, HEIGHT);
    const last = Math.min(frame, DUR - 1);
    for (let k = TRAIL; k >= 0; k--) {
      const f = Math.max(0, last - k), s = TRAJ[f];
      x.globalAlpha = (1 - k / (TRAIL + 1)) * 0.9;
      for (let i = 0; i < N; i++) { x.fillStyle = COLS[i % COLS.length]; x.fillRect(s[i * 2], s[i * 2 + 1], 3, 3); }
    }
    x.globalAlpha = 1;
  }, [frame]);
  return <canvas ref={ref} width={WIDTH} height={HEIGHT} style={{position: 'absolute', inset: 0, width: '100%', height: '100%'}} />;
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
  </Stage>
);
