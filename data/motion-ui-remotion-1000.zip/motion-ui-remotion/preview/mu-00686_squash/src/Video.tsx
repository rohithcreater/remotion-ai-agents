import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#0d0d0d', bg2: '#242424', fg: '#f5f5f0', accent: '#ff3b1f', acc2: '#ffffff',
  muted: '#81817e', card: '#1e1e1e', line: '#2d2d2d', on: '#ffffff', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const clamp01 = (x: number) => Math.min(1, Math.max(0, x));

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

// piecewise keyframes: stops t[i]→v[i] with an easing function per segment
const kf = (ph: number, ts: number[], vs: number[], es: ((t: number) => number)[]) => {
  for (let i = 0; i < ts.length - 1; i++) {
    if (ph <= ts[i + 1]) {
      const k = (ph - ts[i]) / (ts[i + 1] - ts[i]);
      return vs[i] + (vs[i + 1] - vs[i]) * es[i](Math.min(1, Math.max(0, k)));
    }
  }
  return vs[vs.length - 1];
};
const P = 45, D = 352, SIZE = 144, SQ = 1.3;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ph = (frame % P) / P;
  const fall = Easing.bezier(0.55, 0, 1, 0.45), out = Easing.out(Easing.quad), rise = Easing.bezier(0, 0.55, 0.45, 1), lin = (t: number) => t;
  // keyframes mirror classic squash & stretch: stretch on fall → contact → squash → rebound
  const y = kf(ph, [0, 0.47, 0.5, 0.58, 1], [-D, 0, 0, -D * 0.45, -D], [fall, lin, rise, Easing.in(Easing.quad)]);
  const sx = kf(ph, [0, 0.47, 0.5, 0.58, 1], [0.94, 0.88, SQ, 0.9, 0.94], [out, lin, out, lin]);
  const sy = kf(ph, [0, 0.47, 0.5, 0.58, 1], [1.06, 1.14, 0.6, 1.12, 1.06], [out, lin, out, lin]);
  const shadow = 0.5 - 0.5 * Math.cos(((1 - Math.abs(ph * 2 - 1) * 1) * Math.PI)); // 0 at top → 1 at floor
  const near = clamp01(1 - Math.abs(y) / D);
  return (
    <div style={{position: 'relative', width: 520, height: D + SIZE + 80}}>
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 20, height: 1.5, background: C.line}} />
      <div style={{position: 'absolute', left: '50%', bottom: 4, width: SIZE, height: 28, marginLeft: -SIZE / 2, borderRadius: '50%', background: '#000', opacity: 0.1 + 0.28 * near, filter: 'blur(10px)', transform: `scale(${0.45 + (SQ - 0.45) * near * (0.4 + 0.6 * shadow)}, 1)`}} />
      <div style={{position: 'absolute', left: '50%', bottom: 24, width: SIZE, height: SIZE, marginLeft: -SIZE / 2, borderRadius: '50%', background: `radial-gradient(circle at 35% 30%, #ffffffaa, #fff0 38%), ${C.accent}`, boxShadow: '0 -6px 18px #0002 inset', transformOrigin: '50% 100%', transform: `translateY(${y}px) scale(${sx}, ${sy})`}} />
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
  </Stage>
);
