import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#16181d', bg2: '#2b2d32', fg: '#e8eaf0', accent: '#6ee7b7', acc2: '#60a5fa',
  muted: '#7f8186', card: '#26282d', line: '#33353b', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const Hud: React.FC<{label: string}> = ({label}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const s = Math.floor(frame / fps), f = frame % fps;
  const tc = `TC 00:00:${String(s % 60).padStart(2, '0')}:${String(f).padStart(2, '0')}`;
  const u = Math.min(width, height) / 1080;
  const corner = (pos: React.CSSProperties): React.CSSProperties => ({position: 'absolute', width: 36 * u, height: 36 * u, border: `${3 * u}px solid ${C.fg}`, ...pos});
  const txt: React.CSSProperties = {position: 'absolute', fontFamily: MONO, fontSize: 20 * u, letterSpacing: '0.14em', textTransform: 'uppercase', color: C.fg};
  const m = 40 * u;
  return (
    <AbsoluteFill style={{opacity: 0.7, pointerEvents: 'none'}}>
      <div style={corner({top: m, left: m, borderRight: 0, borderBottom: 0})} />
      <div style={corner({top: m, right: m, borderLeft: 0, borderBottom: 0})} />
      <div style={corner({bottom: m, left: m, borderRight: 0, borderTop: 0})} />
      <div style={corner({bottom: m, right: m, borderLeft: 0, borderTop: 0})} />
      <div style={{...txt, top: m + 10 * u, left: m + 56 * u}}>Claude / Motion Reel</div>
      <div style={{...txt, top: m + 10 * u, right: m + 56 * u}}>{width}×{height} · {fps}P</div>
      <div style={{...txt, bottom: m + 10 * u, left: m + 56 * u}}>{tc}</div>
      <div style={{...txt, bottom: m + 10 * u, right: m + 56 * u}}>{label}</div>
    </AbsoluteFill>
  );
};

const WORD = 'VELOCITY';
const ROWS = 11, P = 300;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {width} = useVideoConfig();
  const ph = (frame % P) / P;
  const size = Math.min(width * 0.0625, 120);
  const set = Array.from({length: 10}).map((_, i) => (
    <span key={i} style={{paddingRight: '0.35em'}}>{WORD}</span>
  ));
  return (
    <>
      <div style={{position: 'absolute', inset: '-30%', display: 'flex', flexDirection: 'column', justifyContent: 'center', transform: 'rotate(12deg)'}}>
        {Array.from({length: ROWS}).map((_, row) => {
          const shift = row % 2 === 1 ? -50 * (1 - ph) : -50 * ph; // alternate rows run in opposite directions
          const filled = row % 3 === 2;
          return (
            <div key={row} style={{display: 'flex', width: 'max-content', whiteSpace: 'nowrap', fontSize: size, fontWeight: 900, letterSpacing: '-0.03em', lineHeight: 0.95, transform: `translateX(${shift}%)`, color: filled ? C.accent : 'transparent', WebkitTextStroke: filled ? '0px' : `3px ${C.fg}`}}>
              <div style={{display: 'flex'}}>{set}</div>
              <div style={{display: 'flex'}}>{set}</div>
            </div>
          );
        })}
      </div>
      <div style={{position: 'relative', zIndex: 1, padding: '0.1em 0.35em', background: C.bg, color: C.fg, fontSize: size * 0.85, fontWeight: 900, letterSpacing: '-0.03em', boxShadow: `0 0 0 28px ${C.bg}`}}>
        {WORD.charAt(0) + WORD.slice(1).toLowerCase()}
      </div>
    </>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
      <Hud label="07 — TYPOGRAPHIC PATTERN" />
  </Stage>
);
