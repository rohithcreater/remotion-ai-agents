import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#ece9e1', bg2: '#f8f7f4', fg: '#111111', accent: '#e5341d', acc2: '#111111',
  muted: '#7e7d79', card: '#fafaf8', line: '#cdcbc4', on: '#ffffff', sh: '#0000001f', sh2: '#00000033',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const WORD = 'RHYTHM';
const ROWS = 11, P = 210;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {width} = useVideoConfig();
  const ph = (frame % P) / P;
  const size = Math.min(width * 0.0625, 120);
  const set = Array.from({length: 10}).map((_, i) => (
    <span key={i} style={{paddingRight: '0.35em'}}>{WORD}</span>
  ));
  return (
    <>
      <div style={{position: 'absolute', inset: '-30%', display: 'flex', flexDirection: 'column', justifyContent: 'center', transform: 'rotate(-14deg)'}}>
        {Array.from({length: ROWS}).map((_, row) => {
          const shift = row % 2 === 1 ? -50 * (1 - ph) : -50 * ph; // alternate rows run in opposite directions
          const filled = row % 3 === 2;
          return (
            <div key={row} style={{display: 'flex', width: 'max-content', whiteSpace: 'nowrap', fontSize: size, fontWeight: 900, letterSpacing: '-0.03em', lineHeight: 0.95, transform: `translateX(${shift}%)`, color: filled ? C.accent : 'transparent', WebkitTextStroke: filled ? '0px' : `3px ${C.fg}`}}>
              <div style={{display: 'flex'}}>{set}</div>
              <div style={{display: 'flex'}}>{set}</div>
            </div>
          );
        })}
      </div>
      <div style={{position: 'relative', zIndex: 1, padding: '0.1em 0.35em', background: C.bg, color: C.fg, fontSize: size * 0.85, fontWeight: 900, letterSpacing: '-0.03em', boxShadow: `0 0 0 28px ${C.bg}`}}>
        {WORD.charAt(0) + WORD.slice(1).toLowerCase()}
      </div>
    </>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
  </Stage>
);
