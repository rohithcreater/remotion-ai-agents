import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';

const C = {
  bg: '#16181d', bg2: '#2b2d32', fg: '#e8eaf0', accent: '#6ee7b7', acc2: '#60a5fa',
  muted: '#7f8186', card: '#26282d', line: '#33353b', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const rnd = (seed: number) => { const s = Math.sin(seed * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const N = 1500, SCALE = 0.0034, SPEED = 1.2, DUR = 240, TRAIL = 56;
const COLS = ["#6ee7b7", "#60a5fa"];
const WIDTH = 1920, HEIGHT = 1080;
const angle = (x: number, y: number, t: number) =>
  (Math.sin(x * SCALE + t * 0.00018 * 1000 / 30) + Math.cos(y * SCALE * 1.3 - t * 0.00014 * 1000 / 30) + Math.sin((x + y) * SCALE * 0.6)) * Math.PI * 0.8;
// Precompute every particle path so rendering is a pure function of the frame number.
const PATHS: {xs: Float32Array; ys: Float32Array; a: Float32Array}[] = (() => {
  const out = [];
  for (let i = 0; i < N; i++) {
    let x = rnd(i * 3 + 1) * WIDTH, y = rnd(i * 3 + 2) * HEIGHT, life = 40 + rnd(i * 3 + 3) * 200;
    const xs = new Float32Array(DUR), ys = new Float32Array(DUR), a = new Float32Array(DUR);
    for (let f = 0; f < DUR; f++) {
      const ang = angle(x, y, f * 33.3);
      x += Math.cos(ang) * SPEED * 3; y += Math.sin(ang) * SPEED * 3; life--;
      if (life < 0 || x < 0 || y < 0 || x > WIDTH || y > HEIGHT) { x = rnd(i * 977 + f * 3.3) * WIDTH; y = rnd(i * 613 + f * 5.1) * HEIGHT; life = 120 + rnd(i * 31 + f) * 160; xs[f] = x; ys[f] = y; a[f] = -1; continue; }
      xs[f] = x; ys[f] = y; a[f] = ang;
    }
    out.push({xs, ys, a});
  }
  return out;
})();
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ref = React.useRef<HTMLCanvasElement | null>(null);
  React.useEffect(() => {
    const c = ref.current; if (!c) return;
    const x = c.getContext('2d'); if (!x) return;
    x.clearRect(0, 0, WIDTH, HEIGHT);
    x.lineWidth = 2; x.lineCap = 'round';
    const last = Math.min(frame, DUR - 1);
    for (let i = 0; i < N; i++) {
      const P = PATHS[i];
      const ang = P.a[last] < 0 ? 0 : P.a[last];
      x.strokeStyle = COLS[Math.floor((((ang / (Math.PI * 2)) % 1) + 1) % 1 * COLS.length)];
      for (let k = TRAIL; k > 0; k -= 1) {
        const f1 = last - k + 1, f0 = last - k;
        if (f0 < 0 || P.a[f1] < 0 || P.a[f0] < 0) continue;
        x.globalAlpha = Math.pow(1 - k / TRAIL, 1.6) * 0.85;
        x.beginPath(); x.moveTo(P.xs[f0], P.ys[f0]); x.lineTo(P.xs[f1], P.ys[f1]); x.stroke();
      }
    }
    x.globalAlpha = 1;
  }, [frame]);
  return <canvas ref={ref} width={WIDTH} height={HEIGHT} style={{position: 'absolute', inset: 0, width: '100%', height: '100%'}} />;
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
  </Stage>
);
