import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#0f0b1f', bg2: '#262235', fg: '#f1edff', accent: '#7c5cff', acc2: '#ff6adf',
  muted: '#807c8f', card: '#201c2f', line: '#2f2b3e', on: '#ffffff', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const Hud: React.FC<{label: string}> = ({label}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const s = Math.floor(frame / fps), f = frame % fps;
  const tc = `TC 00:00:${String(s % 60).padStart(2, '0')}:${String(f).padStart(2, '0')}`;
  const u = Math.min(width, height) / 1080;
  const corner = (pos: React.CSSProperties): React.CSSProperties => ({position: 'absolute', width: 36 * u, height: 36 * u, border: `${3 * u}px solid ${C.fg}`, ...pos});
  const txt: React.CSSProperties = {position: 'absolute', fontFamily: MONO, fontSize: 20 * u, letterSpacing: '0.14em', textTransform: 'uppercase', color: C.fg};
  const m = 40 * u;
  return (
    <AbsoluteFill style={{opacity: 0.7, pointerEvents: 'none'}}>
      <div style={corner({top: m, left: m, borderRight: 0, borderBottom: 0})} />
      <div style={corner({top: m, right: m, borderLeft: 0, borderBottom: 0})} />
      <div style={corner({bottom: m, left: m, borderRight: 0, borderTop: 0})} />
      <div style={corner({bottom: m, right: m, borderLeft: 0, borderTop: 0})} />
      <div style={{...txt, top: m + 10 * u, left: m + 56 * u}}>Claude / Motion Reel</div>
      <div style={{...txt, top: m + 10 * u, right: m + 56 * u}}>{width}×{height} · {fps}P</div>
      <div style={{...txt, bottom: m + 10 * u, left: m + 56 * u}}>{tc}</div>
      <div style={{...txt, bottom: m + 10 * u, right: m + 56 * u}}>{label}</div>
    </AbsoluteFill>
  );
};

const FS = "precision highp float;uniform float t;uniform vec2 r;\nfloat smin(float a,float b,float k){float h=max(k-abs(a-b),0.)/k;return min(a,b)-h*h*k*.25;}\nfloat map(vec3 p){float d=1e5;for(int i=0;i<3;i++){float fi=float(i);\nvec3 c=vec3(sin(t*0.600+fi*2.1)*0.809,cos(t*0.600*.8+fi*1.7)*0.809*.7,sin(t*0.600*.6+fi*1.3)*.45);d=smin(d,length(p-c)-0.495,0.801);}return d;}\nvec3 nor(vec3 p){vec2 e=vec2(.002,0.);return normalize(vec3(map(p+e.xyy)-map(p-e.xyy),map(p+e.yxy)-map(p-e.yxy),map(p+e.yyx)-map(p-e.yyx)));}\nvec3 pal(float x){return .5+.5*cos(6.28318*(x+vec3(0.,.33,.67)+0.907));}\nvoid main(){vec2 uv=(gl_FragCoord.xy-.5*r)/r.y;vec3 ro=vec3(0.,0.,-4.),rd=normalize(vec3(uv,1.7));float d=0.,tt=0.;bool hit=false;\nfor(int i=0;i<72;i++){d=map(ro+rd*tt);if(d<.002){hit=true;break;}tt+=d;if(tt>9.)break;}\nvec3 bg=vec3(0.059,0.043,0.122);vec3 col=bg+vec3(0.486,0.361,1.000)*exp(-length(uv)*1.8)*.14;\nif(hit){vec3 p=ro+rd*tt,n=nor(p);float fr=pow(1.+dot(rd,n),3.);vec3 ir=pal(dot(n,vec3(.3,.5,.8))*1.3+t*.04+fr*.7);\nvec3 L=normalize(vec3(.6,.8,-.5));float spec=pow(max(dot(reflect(rd,n),L),0.),48.);float dif=.5+.5*dot(n,L);\ncol=mix(ir*(.35+.4*dif),ir+.35,fr)+spec*.9;col=mix(col,vec3(1.),fr*.12);}\ncol*=1.-.35*dot(uv,uv);col+=(fract(sin(dot(gl_FragCoord.xy,vec2(12.9898,78.233)))*43758.5453)-.5)*.025;gl_FragColor=vec4(col,1.);}";
const VS = 'attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}';
const compile = (gl: WebGLRenderingContext, type: number, src: string) => {
  const s = gl.createShader(type)!;
  gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) ?? 'shader error');
  return s;
};
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const ref = React.useRef<HTMLCanvasElement | null>(null);
  React.useEffect(() => {
    const c = ref.current; if (!c) return;
    // preserveDrawingBuffer so the frame survives until Remotion screenshots it (render with --gl=angle)
    const gl = c.getContext('webgl', {preserveDrawingBuffer: true}); if (!gl) return;
    const pr = gl.createProgram()!;
    gl.attachShader(pr, compile(gl, gl.VERTEX_SHADER, VS));
    gl.attachShader(pr, compile(gl, gl.FRAGMENT_SHADER, FS));
    gl.linkProgram(pr); gl.useProgram(pr);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(pr, 'p');
    gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    gl.viewport(0, 0, width, height);
    gl.uniform1f(gl.getUniformLocation(pr, 't'), frame / fps);   // time is a pure function of the frame
    gl.uniform2f(gl.getUniformLocation(pr, 'r'), width, height);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }, [frame, fps, width, height]);
  return <canvas ref={ref} width={width} height={height} style={{position: 'absolute', inset: 0, width: '100%', height: '100%'}} />;
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
      <Hud label="09 — SMOOTH UNION / SDF" />
  </Stage>
);
