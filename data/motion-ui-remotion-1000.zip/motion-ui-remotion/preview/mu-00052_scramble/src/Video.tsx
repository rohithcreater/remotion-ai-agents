import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#0b0b0c', bg2: '#222223', fg: '#f4f4f0', accent: '#f4f4f0', acc2: '#ff3b1f',
  muted: '#80807e', card: '#1c1c1d', line: '#2c2c2c', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';
const rnd = (seed: number) => { const s = Math.sin(seed * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const Hud: React.FC<{label: string}> = ({label}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const s = Math.floor(frame / fps), f = frame % fps;
  const tc = `TC 00:00:${String(s % 60).padStart(2, '0')}:${String(f).padStart(2, '0')}`;
  const u = Math.min(width, height) / 1080;
  const corner = (pos: React.CSSProperties): React.CSSProperties => ({position: 'absolute', width: 36 * u, height: 36 * u, border: `${3 * u}px solid ${C.fg}`, ...pos});
  const txt: React.CSSProperties = {position: 'absolute', fontFamily: MONO, fontSize: 20 * u, letterSpacing: '0.14em', textTransform: 'uppercase', color: C.fg};
  const m = 40 * u;
  return (
    <AbsoluteFill style={{opacity: 0.7, pointerEvents: 'none'}}>
      <div style={corner({top: m, left: m, borderRight: 0, borderBottom: 0})} />
      <div style={corner({top: m, right: m, borderLeft: 0, borderBottom: 0})} />
      <div style={corner({bottom: m, left: m, borderRight: 0, borderTop: 0})} />
      <div style={corner({bottom: m, right: m, borderLeft: 0, borderTop: 0})} />
      <div style={{...txt, top: m + 10 * u, left: m + 56 * u}}>Claude / Motion Reel</div>
      <div style={{...txt, top: m + 10 * u, right: m + 56 * u}}>{width}×{height} · {fps}P</div>
      <div style={{...txt, bottom: m + 10 * u, left: m + 56 * u}}>{tc}</div>
      <div style={{...txt, bottom: m + 10 * u, right: m + 56 * u}}>{label}</div>
    </AbsoluteFill>
  );
};

const WORDS = ["FRAME", "BY FRAME", "IN CODE", "EVERY PIXEL"];
const GLYPHS = '█▓▒░/[]{}=+*^?#_';
const SCRAMBLE = 36, HOLD = 39; // frames
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const slot = SCRAMBLE + HOLD;
  const idx = Math.floor(frame / slot) % WORDS.length;
  const prev = WORDS[(idx + WORDS.length - 1) % WORDS.length];
  const to = WORDS[idx];
  const f = frame % slot;
  const L = Math.max(prev.length, to.length);
  const chars: React.ReactNode[] = [];
  for (let k = 0; k < L; k++) {
    const start = Math.floor(rnd(idx * 101 + k * 7 + 1) * 12);
    const end = start + 8 + Math.floor(rnd(idx * 53 + k * 13 + 2) * 16);
    if (f >= end) chars.push(<span key={k}>{to[k] ?? ''}</span>);
    else if (f >= start) {
      const g = GLYPHS[Math.floor(rnd(frame * 0.5 + k * 3.1 + idx) * GLYPHS.length)];
      chars.push(<span key={k} style={{color: C.accent, opacity: 0.85}}>{g}</span>);
    } else chars.push(<span key={k}>{idx === 0 && frame < slot ? to[k] ?? '' : prev[k] ?? ''}</span>);
  }
  const cursor = Math.floor(frame / 15) % 2 === 0;
  return (
    <div style={{display: 'flex', alignItems: 'center', font: `700 60px/1.1 ${MONO}`, letterSpacing: '0.04em', whiteSpace: 'pre'}}>
      <span>{chars}</span>
      <span style={{display: 'inline-block', width: '0.5em', height: '0.9em', marginLeft: 4, background: C.accent, opacity: cursor ? 1 : 0}} />
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
      <Hud label="09 — TEXT SCRAMBLE" />
  </Stage>
);
