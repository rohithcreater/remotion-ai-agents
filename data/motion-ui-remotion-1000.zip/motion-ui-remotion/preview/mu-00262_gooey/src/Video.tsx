import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#fff1f0', bg2: '#fffafa', fg: '#2a0f12', accent: '#ff4d6d', acc2: '#ffb703',
  muted: '#948081', card: '#fffcfb', line: '#e1d1d1', on: '#ffffff', sh: '#0000001f', sh2: '#00000033',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const BLOBS = [{"d": 277, "l": 354, "t": 176, "m": 1, "off": 0.0, "x0": -35, "y0": -92, "s0": 0.62, "x1": -73, "y1": 73, "s1": 0.98}, {"d": 323, "l": 15, "t": 400, "m": 1, "off": 0.2, "x0": 95, "y0": -92, "s0": 0.74, "x1": 119, "y1": -79, "s1": 0.98}, {"d": 321, "l": 264, "t": 273, "m": 1, "off": 0.4, "x0": -26, "y0": 101, "s0": 0.73, "x1": 110, "y1": -86, "s1": 1.22}, {"d": 271, "l": 317, "t": 141, "m": 2, "off": 0.6, "x0": -13, "y0": -64, "s0": 0.74, "x1": 64, "y1": -117, "s1": 1.27}, {"d": 224, "l": 398, "t": 156, "m": 2, "off": 0.8, "x0": 0, "y0": 97, "s0": 0.89, "x1": -13, "y1": -77, "s1": 1.21}];
const L = 420; // loop length in frames; each blob completes m ping-pong cycles per loop
const SIZE = 750;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(0.42, 0, 0.58, 1); // CSS ease-in-out
  return (
    <div style={{position: 'relative', width: SIZE, height: SIZE, filter: `url(#goo) drop-shadow(0 30px 40px ${C.sh})`}}>
      <svg width={0} height={0} style={{position: 'absolute'}}>
        <defs>
          <filter id="goo">
            <feGaussianBlur in="SourceGraphic" stdDeviation={20 * 2.2} result="b" />
            <feColorMatrix in="b" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 22 -9" />
          </filter>
        </defs>
      </svg>
      {BLOBS.map((b, i) => {
        const cyc = (frame / L) * b.m + b.off;           // cycles completed
        const tri = Math.abs(((cyc % 1) + 1) % 1 * 2 - 1); // ping-pong 0..1..0
        const t = ease(1 - tri);
        const x = b.x0 + (b.x1 - b.x0) * t, y = b.y0 + (b.y1 - b.y0) * t, s = b.s0 + (b.s1 - b.s0) * t;
        return <div key={i} style={{position: 'absolute', width: b.d, height: b.d, left: b.l, top: b.t, borderRadius: '50%', background: C.accent, transform: `translate(${x}px, ${y}px) scale(${s})`}} />;
      })}
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
  </Stage>
);
