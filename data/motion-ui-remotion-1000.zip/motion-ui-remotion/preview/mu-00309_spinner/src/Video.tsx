import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#140a0a', bg2: '#2c2120', fg: '#fff1e8', accent: '#ff7a45', acc2: '#ffd166',
  muted: '#8a7e79', card: '#241b1b', line: '#352a29', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ph = (frame % 86) / 86;
  const t = ph < 0.5 ? ph * 2 : 2 - ph * 2;
  const e = Easing.bezier(0.7, 0, 0.2, 1)(t);
  return (
    <div style={{width: 128, height: 128, background: C.accent, borderRadius: `${50 - 28 * e}%`, transform: `rotate(${ph * 360}deg) scale(${1 - 0.22 * e})`, boxShadow: `0 14px 40px ${C.sh}`}} />
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
