import {Composition} from 'remotion';
import {Video} from './Video';

export const RemotionRoot = () => {
  return (
    <Composition id="Main" component={Video} durationInFrames={344} fps={30} width={1080} height={1080} />
  );
};
