import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#0c0f08', bg2: '#23261d', fg: '#eef5d8', accent: '#c6ff3d', acc2: '#ffffff',
  muted: '#7d8270', card: '#1d2019', line: '#2c2f25', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const Hud: React.FC<{label: string}> = ({label}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const s = Math.floor(frame / fps), f = frame % fps;
  const tc = `TC 00:00:${String(s % 60).padStart(2, '0')}:${String(f).padStart(2, '0')}`;
  const u = Math.min(width, height) / 1080;
  const corner = (pos: React.CSSProperties): React.CSSProperties => ({position: 'absolute', width: 36 * u, height: 36 * u, border: `${3 * u}px solid ${C.fg}`, ...pos});
  const txt: React.CSSProperties = {position: 'absolute', fontFamily: MONO, fontSize: 20 * u, letterSpacing: '0.14em', textTransform: 'uppercase', color: C.fg};
  const m = 40 * u;
  return (
    <AbsoluteFill style={{opacity: 0.7, pointerEvents: 'none'}}>
      <div style={corner({top: m, left: m, borderRight: 0, borderBottom: 0})} />
      <div style={corner({top: m, right: m, borderLeft: 0, borderBottom: 0})} />
      <div style={corner({bottom: m, left: m, borderRight: 0, borderTop: 0})} />
      <div style={corner({bottom: m, right: m, borderLeft: 0, borderTop: 0})} />
      <div style={{...txt, top: m + 10 * u, left: m + 56 * u}}>Claude / Motion Reel</div>
      <div style={{...txt, top: m + 10 * u, right: m + 56 * u}}>{width}×{height} · {fps}P</div>
      <div style={{...txt, bottom: m + 10 * u, left: m + 56 * u}}>{tc}</div>
      <div style={{...txt, bottom: m + 10 * u, right: m + 56 * u}}>{label}</div>
    </AbsoluteFill>
  );
};

// piecewise keyframes: stops t[i]→v[i] with an easing function per segment
const kf = (ph: number, ts: number[], vs: number[], es: ((t: number) => number)[]) => {
  for (let i = 0; i < ts.length - 1; i++) {
    if (ph <= ts[i + 1]) {
      const k = (ph - ts[i]) / (ts[i + 1] - ts[i]);
      return vs[i] + (vs[i + 1] - vs[i]) * es[i](Math.min(1, Math.max(0, k)));
    }
  }
  return vs[vs.length - 1];
};
const SEQ = ['3', '2', '1', 'GO'];
const P = 150, FS = 280;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(.7,0,.2,1);
  const ph = (frame % P) / P;
  // digits slide up through a clipped window; each hold is followed by an eased step
  const y = kf(ph, [0, 0.16, 0.24, 0.41, 0.49, 0.66, 0.74, 1], [0, 0, -FS, -FS, -2 * FS, -2 * FS, -3 * FS, -3 * FS], [(t) => t, ease, (t) => t, ease, (t) => t, ease, (t) => t]);
  const R = 46, circ = 2 * Math.PI * R;
  const prog = kf(ph, [0, 0.74, 1], [0, 1, 1], [(t) => t, (t) => t]);
  const ringOp = kf(ph, [0, 0.74, 1], [1, 1, 0.2], [(t) => t, (t) => t]);
  const S = FS * 1.9;
  return (
    <div style={{position: 'relative', display: 'grid', placeItems: 'center', width: S, height: S}}>
      <svg viewBox="0 0 100 100" style={{position: 'absolute', inset: 0, width: '100%', height: '100%', transform: 'rotate(-90deg)'}}>
        <circle cx="50" cy="50" r={R} fill="none" stroke={C.line} strokeWidth={1.5} />
        <circle cx="50" cy="50" r={R} fill="none" stroke={C.accent} strokeWidth={1.5} strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={circ * (1 - prog)} opacity={ringOp} />
      </svg>
      <div style={{height: FS, overflow: 'hidden', fontSize: FS, fontWeight: 900, letterSpacing: '-0.06em', lineHeight: `${FS}px`, textAlign: 'center'}}>
        <div style={{transform: `translateY(${y}px)`}}>
          {SEQ.map((s, i) => <div key={s} style={{height: FS, color: i === 3 ? C.accent : C.fg}}>{s}</div>)}
        </div>
      </div>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
      <Hud label="03 — COUNTDOWN" />
  </Stage>
);
