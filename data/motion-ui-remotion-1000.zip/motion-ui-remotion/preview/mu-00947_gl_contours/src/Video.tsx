import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#eeeeea', bg2: '#f9f9f8', fg: '#0a0a0a', accent: '#0a0a0a', acc2: '#ff3b1f',
  muted: '#7c7c7a', card: '#fbfbfa', line: '#cececb', on: '#ffffff', sh: '#0000001f', sh2: '#00000033',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const FS = "precision highp float;uniform float t;uniform vec2 r;\nvoid main(){vec2 uv=(gl_FragCoord.xy-.5*r)/r.y;float v=0.;\nfor(int i=0;i<5;i++){float fi=float(i)+1.;vec2 c=vec2(cos(t*.21*fi+fi*2.),sin(t*.17*fi+fi*3.))*.42;v+=sin(length(uv-c)*7.94-t*0.92)/fi;}\nfloat w=abs(fract(v*3.0*.25)-.5);float l=smoothstep(.43,.5,w);vec3 line=mix(vec3(0.039,0.039,0.039),vec3(1.000,0.231,0.122),uv.x+.5);\nvec3 col=mix(vec3(0.933,0.933,0.918),line,l*(.55+.45*smoothstep(.9,.0,length(uv))));col*=1.-.3*dot(uv,uv);gl_FragColor=vec4(col,1.);}";
const VS = 'attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}';
const compile = (gl: WebGLRenderingContext, type: number, src: string) => {
  const s = gl.createShader(type)!;
  gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) ?? 'shader error');
  return s;
};
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const ref = React.useRef<HTMLCanvasElement | null>(null);
  React.useEffect(() => {
    const c = ref.current; if (!c) return;
    // preserveDrawingBuffer so the frame survives until Remotion screenshots it (render with --gl=angle)
    const gl = c.getContext('webgl', {preserveDrawingBuffer: true}); if (!gl) return;
    const pr = gl.createProgram()!;
    gl.attachShader(pr, compile(gl, gl.VERTEX_SHADER, VS));
    gl.attachShader(pr, compile(gl, gl.FRAGMENT_SHADER, FS));
    gl.linkProgram(pr); gl.useProgram(pr);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(pr, 'p');
    gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    gl.viewport(0, 0, width, height);
    gl.uniform1f(gl.getUniformLocation(pr, 't'), frame / fps);   // time is a pure function of the frame
    gl.uniform2f(gl.getUniformLocation(pr, 'r'), width, height);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }, [frame, fps, width, height]);
  return <canvas ref={ref} width={width} height={height} style={{position: 'absolute', inset: 0, width: '100%', height: '100%'}} />;
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
  </Stage>
);
