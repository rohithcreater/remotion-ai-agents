import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#0b0b0c', bg2: '#222223', fg: '#f4f4f0', accent: '#f4f4f0', acc2: '#ff3b1f',
  muted: '#80807e', card: '#1c1c1d', line: '#2c2c2c', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

// piecewise keyframes: stops t[i]→v[i] with an easing function per segment
const kf = (ph: number, ts: number[], vs: number[], es: ((t: number) => number)[]) => {
  for (let i = 0; i < ts.length - 1; i++) {
    if (ph <= ts[i + 1]) {
      const k = (ph - ts[i]) / (ts[i + 1] - ts[i]);
      return vs[i] + (vs[i + 1] - vs[i]) * es[i](Math.min(1, Math.max(0, k)));
    }
  }
  return vs[vs.length - 1];
};
const LAYERS = [{"d": "M150.0,0.0 L51.4,24.7 L93.5,117.3 L12.7,55.6 L-33.4,146.2 L-35.5,44.6 L-135.1,65.1 L-57.0,0.0 L-135.1,-65.1 L-35.5,-44.6 L-33.4,-146.2 L12.7,-55.6 L93.5,-117.3 L51.4,-24.7 Z", "delay": 0, "col": "accent"}, {"d": "M120.0,21.8 L37.5,27.3 L57.8,107.5 L2.1,46.3 L-48.0,112.2 L-34.9,30.5 L-117.6,32.4 L-45.6,-8.3 L-98.7,-71.8 L-21.9,-40.8 L-5.4,-121.9 L18.2,-42.6 L91.9,-80.2 L44.7,-12.3 Z", "delay": 10, "col": "acc2"}];
const P = 135, DUR = 405, N = 7;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(0.65, 0, 0.35, 1);
  // star polygons are N-fold symmetric, so turning by 360/N over the loop is seamless
  const rotate = (frame / DUR) * (360 / N);
  return (
    <svg width={860} height={860} viewBox="-170 -170 340 340" style={{overflow: 'visible', transform: `rotate(${rotate}deg)`}}>
      {LAYERS.map((l, i) => {
        const local = frame - l.delay;
        const ph = local < 0 ? 0 : (local % P) / P;
        const off = kf(ph, [0, 0.4, 0.85, 1], [1, 0, 0, -1], [ease, (t) => t, ease]);
        const fo = kf(ph, [0, 0.4, 0.6, 0.85, 1], [0, 0, 0.16, 0.16, 0], [(t) => t, ease, (t) => t, ease]);
        const op = kf(ph, [0, 0.85, 1], [1, 1, 0.2], [(t) => t, ease]);
        const col = l.col === 'accent' ? C.accent : C.acc2;
        return <path key={i} d={l.d} pathLength={1} fill={col} fillOpacity={fo} stroke={col} strokeWidth={2} strokeLinejoin="round" strokeDasharray="1" strokeDashoffset={off} opacity={op} />;
      })}
    </svg>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
  </Stage>
);
