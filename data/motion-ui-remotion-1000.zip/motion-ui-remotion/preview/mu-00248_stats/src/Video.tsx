import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#06121c', bg2: '#1c2833', fg: '#e6f3ff', accent: '#38bdf8', acc2: '#a78bfa',
  muted: '#76828e', card: '#17232c', line: '#25323c', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};
const seg = (f: number, a: number, b: number, easing: (t: number) => number = Easing.inOut(Easing.cubic)) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const TABS = ["Day", "Week", "Month"];
const TOTALS = [140225, 280450, 252960];
const PATHS = ["M0.0,53.9 C13.6,53.9 13.6,51.8 27.3,51.8 C40.9,51.8 40.9,57.2 54.5,57.2 C68.2,57.2 68.2,55.2 81.8,55.2 C95.5,55.2 95.5,57.3 109.1,57.3 C122.7,57.3 122.7,57.3 136.4,57.3 C150.0,57.3 150.0,66.2 163.6,66.2 C177.3,66.2 177.3,69.9 190.9,69.9 C204.5,69.9 204.5,76.0 218.2,76.0 C231.8,76.0 231.8,80.2 245.5,80.2 C259.1,80.2 259.1,79.6 272.7,79.6 C286.4,79.6 286.4,88.2 300.0,88.2", "M0.0,70.8 C13.6,70.8 13.6,69.4 27.3,69.4 C40.9,69.4 40.9,76.0 54.5,76.0 C68.2,76.0 68.2,77.2 81.8,77.2 C95.5,77.2 95.5,71.4 109.1,71.4 C122.7,71.4 122.7,73.2 136.4,73.2 C150.0,73.2 150.0,80.7 163.6,80.7 C177.3,80.7 177.3,77.3 190.9,77.3 C204.5,77.3 204.5,83.6 218.2,83.6 C231.8,83.6 231.8,77.9 245.5,77.9 C259.1,77.9 259.1,76.2 272.7,76.2 C286.4,76.2 286.4,77.9 300.0,77.9", "M0.0,58.9 C13.6,58.9 13.6,57.1 27.3,57.1 C40.9,57.1 40.9,56.5 54.5,56.5 C68.2,56.5 68.2,65.2 81.8,65.2 C95.5,65.2 95.5,73.9 109.1,73.9 C122.7,73.9 122.7,70.3 136.4,70.3 C150.0,70.3 150.0,68.5 163.6,68.5 C177.3,68.5 177.3,76.9 190.9,76.9 C204.5,76.9 204.5,73.5 218.2,73.5 C231.8,73.5 231.8,71.9 245.5,71.9 C259.1,71.9 259.1,72.2 272.7,72.2 C286.4,72.2 286.4,67.4 300.0,67.4"];
const HOLD = 84;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(.16,1,.3,1);
  const i = Math.floor(frame / HOLD) % 3;
  const local = frame % HOLD;
  const slide = ease(seg(local, 0, 14, (x) => x));
  const prev = (i + 2) % 3;
  const pillX = (i === 0 && frame >= HOLD ? prev + (3 - prev) * slide : prev + (i - prev) * slide) % 3;
  const count = Math.round(TOTALS[i] * (1 - Math.pow(1 - seg(local, 0, 36, (x) => x), 4)));
  const draw = ease(seg(local, 0, 39, (x) => x));
  const area = seg(local, 15, 39, (x) => x);
  const colW = 64;
  return (
    <div style={{width: 380, padding: '24px 26px 26px', borderRadius: 28, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 30px 70px ${C.sh}`}}>
      <div style={{position: 'relative', display: 'flex', gap: 4, padding: 4, borderRadius: 99, background: C.line, width: 'max-content', margin: '0 auto 22px'}}>
        <div style={{position: 'absolute', top: 4, bottom: 4, left: 4, width: colW - 4, borderRadius: 99, background: C.accent, transform: `translateX(${pillX * colW}px)`}} />
        {TABS.map((t, k) => (
          <div key={t} style={{position: 'relative', zIndex: 1, width: colW - 4, textAlign: 'center', padding: '7px 0', fontSize: 12, fontWeight: 600, color: k === i ? C.on : C.muted}}>{t}</div>
        ))}
      </div>
      <div style={{fontSize: 56, fontWeight: 700, letterSpacing: '-0.04em', fontVariantNumeric: 'tabular-nums', lineHeight: 1}}>{count.toLocaleString('en-US')}</div>
      <div style={{fontSize: 13, color: C.muted, margin: '6px 0 14px'}}>sessions</div>
      <svg viewBox="0 0 300 140" style={{width: '100%', overflow: 'visible'}}>
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={C.accent} stopOpacity={0.28} /><stop offset="1" stopColor={C.accent} stopOpacity={0} /></linearGradient>
        </defs>
        <path d={PATHS[i] + ' L300,140 L0,140 Z'} fill="url(#g)" opacity={area} />
        <path d={PATHS[i]} pathLength={1} fill="none" stroke={C.accent} strokeWidth={2.5} strokeLinecap="round" strokeDasharray="1" strokeDashoffset={1 - draw} />
      </svg>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
