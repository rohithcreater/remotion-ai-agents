import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#0f0b1f', bg2: '#262235', fg: '#f1edff', accent: '#7c5cff', acc2: '#ff6adf',
  muted: '#807c8f', card: '#201c2f', line: '#2f2b3e', on: '#ffffff', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const a = (frame / durationInFrames) * Math.PI * 2;
  const x = Math.sin(a), y = Math.cos(a * 1.0 + 0.9);
  const gx = 50 + x * 45, gy = 50 + y * 45;
  return (
    <div style={{perspective: 900}}>
      <div style={{position: 'relative', width: 280, height: 360, borderRadius: 28, background: 'linear-gradient(145deg, #fddb92, #f093fb 55%, #5b8cff)', transformStyle: 'preserve-3d', boxShadow: `0 40px 80px ${C.sh2}`, overflow: 'hidden', transform: `rotateY(${x * 10}deg) rotateX(${-y * 10}deg)`}}>
        <div style={{position: 'absolute', inset: 0, background: `radial-gradient(420px circle at ${gx}% ${gy}%, #ffffff66, #fff0 55%)`, mixBlendMode: 'soft-light'}} />
        <div style={{position: 'absolute', top: 24, left: 26, font: `700 10px ${MONO}`, letterSpacing: '0.18em', padding: '7px 11px', borderRadius: 99, background: '#00000040', color: '#fff', transform: 'translateZ(40px)'}}>LIMITED</div>
        <div style={{position: 'absolute', left: 26, bottom: 60, fontSize: 44, fontWeight: 800, letterSpacing: '-0.04em', color: '#fff', transform: `translateZ(60px) translate(${-x * 4}px, ${y * 3}px)`, textShadow: '0 8px 24px #0004'}}>Prism</div>
        <div style={{position: 'absolute', left: 26, bottom: 32, fontSize: 13, color: '#ffffffcc', transform: 'translateZ(30px)'}}>Collection 2026 · Hover to tilt</div>
      </div>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
