import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#06121c', bg2: '#1c2833', fg: '#e6f3ff', accent: '#38bdf8', acc2: '#a78bfa',
  muted: '#76828e', card: '#17232c', line: '#25323c', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const RINGS = [{"rx": 57, "ry": 28.5, "m": 2, "off": 0.892, "rad": 5, "col": "accent"}, {"rx": 101, "ry": 50.5, "m": 3, "off": 0.478, "rad": 5, "col": "acc2"}, {"rx": 145, "ry": 72.5, "m": 1, "off": 0.242, "rad": 4, "col": "accent"}, {"rx": 189, "ry": 94.5, "m": 1, "off": 0.512, "rad": 5, "col": "acc2"}];
const L = 360; // loop length: planet i completes m full orbits per loop
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const pulse = 12 + (24 - 12) * (0.5 - 0.5 * Math.cos((frame / (L / 4)) * Math.PI * 2));
  return (
    <svg width={1300} height={1300} viewBox="-300 -300 600 600" style={{overflow: 'visible'}}>
      <g transform="rotate(25)">
        {RINGS.map((rg, i) => {
          const a = ((frame / L) * rg.m + rg.off) * Math.PI * 2;
          const x = rg.rx * Math.cos(a), y = -rg.ry * Math.sin(a); // counter-clockwise like the SVG path
          const col = rg.col === 'accent' ? C.accent : C.acc2;
          return (
            <g key={i}>
              <ellipse rx={rg.rx} ry={rg.ry} fill="none" stroke={C.muted} strokeOpacity={0.55} strokeWidth={1.2} />
              <circle cx={x} cy={y} r={rg.rad} fill={col} />
            </g>
          );
        })}
        <circle r={pulse} fill={C.accent} style={{filter: `drop-shadow(0 0 20px ${C.accent})`}} />
      </g>
    </svg>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
  </Stage>
);
