import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#0f0b1f', bg2: '#262235', fg: '#f1edff', accent: '#7c5cff', acc2: '#ff6adf',
  muted: '#807c8f', card: '#201c2f', line: '#2f2b3e', on: '#ffffff', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const clamp01 = (x: number) => Math.min(1, Math.max(0, x));

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};
const seg = (f: number, a: number, b: number, easing: (t: number) => number = Easing.inOut(Easing.cubic)) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const MSGS = [["Payment received", "$248.00 from Acme Inc."], ["New comment", "Maya replied to your post"], ["Deploy finished", "main \u2192 production in 42s"], ["Reminder", "Standup starts in 5 min"]];
const EVERY = 57, LIFE = 78, GAP = 14;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(.16,1,.3,1);
  const newest = Math.floor(frame / EVERY);
  const stack = [0, 1, 2, 3].map((k) => newest - k).filter((i) => i >= 0);
  return (
    <div style={{position: 'relative', width: 340, height: 230}}>
      {stack.map((i, k) => {
        const age = frame - i * EVERY;
        const enter = ease(seg(age, 0, 18, (x) => x));
        // slot position eases when a newer toast arrives
        const slot = k === 0 ? 0 : k - 1 + ease(seg(frame - newest * EVERY, 0, 18, (x) => x));
        const depth = Math.min(3, slot);
        const m = MSGS[i % MSGS.length];
        const life = clamp01(1 - age / LIFE);
        return (
          <div key={i} style={{position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10 - k, padding: '16px 18px 18px', borderRadius: 20, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 20px 50px ${C.sh}`, overflow: 'hidden', transformOrigin: '50% 0', transform: `translateY(${depth * GAP - (1 - enter) * 34}px) scale(${(1 - depth * 0.05) * (0.96 + 0.04 * enter)})`, opacity: enter * (1 - Math.min(3, depth) * 0.28)}}>
            <div style={{fontSize: 15, fontWeight: 700, letterSpacing: '-0.01em'}}>{m[0]}</div>
            <div style={{fontSize: 13, color: C.muted}}>{m[1]}</div>
            <div style={{position: 'absolute', left: 0, bottom: 0, height: 3, width: '100%', background: C.accent, transformOrigin: 'left', transform: `scaleX(${life})`}} />
          </div>
        );
      })}
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
