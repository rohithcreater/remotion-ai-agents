import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#0b0b0c', bg2: '#222223', fg: '#f4f4f0', accent: '#f4f4f0', acc2: '#ff3b1f',
  muted: '#80807e', card: '#1c1c1d', line: '#2c2c2c', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const TRACK = 200; // track length in seconds
const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const Icon: React.FC<{d: string; size?: number}> = ({d, size = 22}) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill={C.fg}><path d={d} /></svg>
);
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  // pause for a beat in the middle of the loop, with a spring-like press on the button
  const pausing = frame > 120 && frame < 180;
  const press = frame >= 118 && frame < 130 ? 1 - 0.14 * Math.sin(((frame - 118) / 12) * Math.PI) : frame >= 178 && frame < 190 ? 1 - 0.14 * Math.sin(((frame - 178) / 12) * Math.PI) : 1;
  const shown = pausing ? (TRACK * 0.3 + 120 / fps) % TRACK : (TRACK * 0.3 + (frame > 180 ? frame - 60 : frame) / fps) % TRACK;
  const sp = (shown / TRACK) * 100;
  const sh = 50 + 50 * Math.sin((frame / durationInFrames) * Math.PI * 2 * 1.5);
  return (
    <div style={{width: 350, padding: 18, borderRadius: 30, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 30px 70px ${C.sh}`}}>
      <div style={{display: 'flex', gap: 14, alignItems: 'center'}}>
        <div style={{width: 68, height: 68, borderRadius: 18, background: 'linear-gradient(135deg, #00c6ff, #7b5cff, #ff4d9d)', backgroundSize: '220% 220%', backgroundPosition: `${sh}% ${sh}%`, boxShadow: '0 10px 24px #7b5cff66'}} />
        <div>
          <div style={{fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em'}}>frame by frame</div>
          <div style={{fontSize: 13, color: C.muted}}>live session</div>
        </div>
      </div>
      <div style={{margin: '20px 0 8px', height: 5, borderRadius: 9, background: C.line, position: 'relative'}}>
        <div style={{height: '100%', width: `${sp}%`, borderRadius: 'inherit', background: C.accent, position: 'relative'}}>
          <div style={{position: 'absolute', right: -6, top: '50%', width: 12, height: 12, marginTop: -6, borderRadius: '50%', background: C.accent, boxShadow: `0 2px 8px ${C.sh2}`}} />
        </div>
      </div>
      <div style={{display: 'flex', justifyContent: 'space-between', font: `11px ${MONO}`, color: C.muted}}>
        <span>{fmt(shown)}</span><span>-{fmt(TRACK - shown)}</span>
      </div>
      <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 32, marginTop: 14}}>
        <Icon d="M6 5h2v14H6zM20 5v14L9 12z" />
        <div style={{transform: `scale(${press})`, display: 'grid', placeItems: 'center'}}>
          <Icon size={32} d={pausing ? 'M7 4v16l13-8z' : 'M6 5h4v14H6zM14 5h4v14h-4z'} />
        </div>
        <Icon d="M16 5h2v14h-2zM4 5v14l11-7z" />
      </div>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
