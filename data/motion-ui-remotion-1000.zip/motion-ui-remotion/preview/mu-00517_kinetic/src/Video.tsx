import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#0b0b0c', bg2: '#222223', fg: '#f4f4f0', accent: '#f4f4f0', acc2: '#ff3b1f',
  muted: '#80807e', card: '#1c1c1d', line: '#2c2c2c', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

// piecewise keyframes: stops t[i]→v[i] with an easing function per segment
const kf = (ph: number, ts: number[], vs: number[], es: ((t: number) => number)[]) => {
  for (let i = 0; i < ts.length - 1; i++) {
    if (ph <= ts[i + 1]) {
      const k = (ph - ts[i]) / (ts[i + 1] - ts[i]);
      return vs[i] + (vs[i + 1] - vs[i]) * es[i](Math.min(1, Math.max(0, k)));
    }
  }
  return vs[vs.length - 1];
};
const WORD = 'REEL';
const P = 126, STAGGER = 1; // loop length and per-letter delay in frames
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const ease = Easing.bezier(.34,1.56,.64,1);
  const size = Math.min(width * 0.15, height * 0.26);
  const capOp = kf(((frame % P) / P), [0, 0.15, 0.3, 0.75, 1], [0, 0, 1, 1, 0], [(t) => t, (t) => t, (t) => t, (t) => t]);
  return (
    <div>
      <div style={{display: 'flex', fontSize: size, fontWeight: 700, letterSpacing: '-0.045em', lineHeight: 1, perspective: 700}}>
        {WORD.split('').map((ch, i) => {
          const local = frame - i * STAGGER;
          const ph = local < 0 ? 0 : (local % P) / P;
          const s = kf(ph, [0, 0.25, 0.75, 1], [0.2, 1, 1, 1.6], [ease, (t) => t, ease]);
          const o = kf(ph, [0, 0.25, 0.75, 1], [0, 1, 1, 0], [ease, (t) => t, ease]);
          const style: React.CSSProperties = {transform: `scale(${s})`, opacity: o};
          const mask: React.CSSProperties = {};
          return (
            <div key={i} style={mask}>
              <span style={{display: 'inline-block', transformOrigin: '50% 100%', ...style}}>{ch}</span>
            </div>
          );
        })}
      </div>
      <div style={{marginTop: 22, textAlign: 'center', font: `500 ${size * 0.07}px ${MONO}`, letterSpacing: '0.4em', color: C.muted, opacity: capOp}}>SHOWREEL 2026</div>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
  </Stage>
);
