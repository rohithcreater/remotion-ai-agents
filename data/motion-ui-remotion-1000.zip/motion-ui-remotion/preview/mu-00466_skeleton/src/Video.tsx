import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#16181d', bg2: '#2b2d32', fg: '#e8eaf0', accent: '#6ee7b7', acc2: '#60a5fa',
  muted: '#7f8186', card: '#26282d', line: '#33353b', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};
const seg = (f: number, a: number, b: number, easing: (t: number) => number = Easing.inOut(Easing.cubic)) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const LOAD = 51, CYCLE = 138;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(.22,1,.36,1);
  const local = frame % CYCLE;
  const reveal = ease(seg(local, LOAD, LOAD + 21, (x) => x));
  const sweep = ((frame % 42) / 42) * -300; // shimmer position, 1.4s period
  const sk: React.CSSProperties = {background: `linear-gradient(90deg, ${C.muted}26 25%, ${C.muted}55 50%, ${C.muted}26 75%)`, backgroundSize: '300% 100%', backgroundPosition: `${sweep}% 0`, borderRadius: 10};
  return (
    <div style={{position: 'relative', width: 340, height: 150, borderRadius: 24, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 24px 60px ${C.sh}`, overflow: 'hidden'}}>
      <div style={{position: 'absolute', inset: 0, padding: 24, display: 'flex', gap: 16, alignItems: 'center', opacity: 1 - reveal, transform: `translateY(${-14 * reveal}px)`}}>
        <div style={{...sk, width: 64, height: 64, borderRadius: '50%', flex: 'none'}} />
        <div style={{flex: 1}}>
          <div style={{...sk, height: 14, margin: '8px 0', width: '70%'}} />
          <div style={{...sk, height: 14, margin: '8px 0', width: '45%'}} />
          <div style={{...sk, height: 14, margin: '8px 0', width: '85%'}} />
        </div>
      </div>
      <div style={{position: 'absolute', inset: 0, padding: 24, display: 'flex', gap: 16, alignItems: 'center', opacity: reveal, transform: `translateY(${14 * (1 - reveal)}px)`}}>
        <div style={{width: 64, height: 64, borderRadius: '50%', flex: 'none', background: 'linear-gradient(135deg, #84fab0, #8fd3f4, #a18cd1)'}} />
        <div>
          <div style={{fontSize: 19, fontWeight: 700, letterSpacing: '-0.02em'}}>Noah Reed</div>
          <div style={{fontSize: 13, color: C.muted}}>Motion Artist</div>
          <div style={{display: 'inline-block', marginTop: 10, font: `600 11px ${MONO}`, padding: '5px 10px', borderRadius: 99, background: C.line}}>Available</div>
        </div>
      </div>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
