import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#eeeeea', bg2: '#f9f9f8', fg: '#0a0a0a', accent: '#0a0a0a', acc2: '#ff3b1f',
  muted: '#7c7c7a', card: '#fbfbfa', line: '#cececb', on: '#ffffff', sh: '#0000001f', sh2: '#00000033',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const clamp01 = (x: number) => Math.min(1, Math.max(0, x));

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const SPOTS = [[0.5, 0.5], [0.22, 0.4], [0.78, 0.65]]; // normalised click positions
const EVERY = 51;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const W = 280, H = 66;
  const idx = Math.floor(frame / EVERY);
  const local = frame - idx * EVERY;
  const ripples = [idx - 1, idx].filter((i) => i >= 0).map((i) => ({i, t: (frame - i * EVERY) / 27}));
  const press = local < 12 ? 1 - 0.04 * Math.sin((local / 12) * Math.PI) + 0.012 * Math.sin((local / 12) * Math.PI * 2) : 1;
  return (
    <div style={{position: 'relative', overflow: 'hidden', width: W, height: H, display: 'grid', placeItems: 'center', borderRadius: 28, background: `linear-gradient(135deg, ${C.accent}, ${C.acc2})`, color: C.on, fontSize: 19, fontWeight: 700, letterSpacing: '-0.02em', boxShadow: `0 18px 44px ${C.sh2}`, transform: `scale(${press})`}}>
      {'Try it free'}
      {ripples.map(({i, t}) => {
        const [sx, sy] = SPOTS[i % SPOTS.length];
        const k = Easing.bezier(0.2, 0.7, 0.2, 1)(clamp01(t));
        const size = W;
        return <div key={i} style={{position: 'absolute', width: size, height: size, left: sx * W - size / 2, top: sy * H - size / 2, borderRadius: '50%', background: '#ffffff66', transform: `scale(${3.2 * k})`, opacity: 1 - k}} />;
      })}
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
