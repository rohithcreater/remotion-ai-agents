import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#0f0b1f', bg2: '#262235', fg: '#f1edff', accent: '#7c5cff', acc2: '#ff6adf',
  muted: '#807c8f', card: '#201c2f', line: '#2f2b3e', on: '#ffffff', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const clamp01 = (x: number) => Math.min(1, Math.max(0, x));

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};
const seg = (f: number, a: number, b: number, easing: (t: number) => number = Easing.inOut(Easing.cubic)) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const FILL = 102; // frames to fill the ring
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const k = clamp01(frame / FILL);
  const e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
  const R = 46, circ = 2 * Math.PI * R;
  const done = seg(frame - FILL, 0, 18, Easing.bezier(0.34, 1.56, 0.64, 1));
  const check = seg(frame - FILL, 4, 22, Easing.out(Easing.cubic));
  return (
    <div style={{position: 'relative', width: 196, height: 196}}>
      <svg viewBox="0 0 100 100" style={{width: '100%', height: '100%', transform: 'rotate(-90deg)', overflow: 'visible'}}>
        <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={C.accent} /><stop offset="1" stopColor={C.acc2} /></linearGradient></defs>
        <circle cx="50" cy="50" r={R} fill="none" stroke={C.line} strokeWidth={8 * 0.5} />
        <circle cx="50" cy="50" r={R} fill="none" stroke="url(#g)" strokeWidth={8 * 0.5} strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={circ * (1 - e)} style={{filter: `drop-shadow(0 0 10px ${C.accent}66)`}} />
      </svg>
      <div style={{position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', fontSize: 54, fontWeight: 700, letterSpacing: '-0.04em', fontVariantNumeric: 'tabular-nums', opacity: 1 - done, transform: `scale(${1 + 0.4 * done})`}}>
        {Math.round(e * 100)}%
      </div>
      <div style={{position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', opacity: done, transform: `scale(${0.4 + 0.6 * done})`}}>
        <svg viewBox="0 0 24 24" width="42%" height="42%" fill="none" stroke={C.accent} strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
          <path d="M5 12.5l4.5 4.5L19 7.5" pathLength={1} strokeDasharray="1" strokeDashoffset={1 - check} />
        </svg>
      </div>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
