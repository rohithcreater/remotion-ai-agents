import {Composition} from 'remotion';
import {Video} from './Video';

export const RemotionRoot = () => {
  return (
    <Composition id="Main" component={Video} durationInFrames={165} fps={30} width={1080} height={1080} />
  );
};
