import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#16181d', bg2: '#2b2d32', fg: '#e8eaf0', accent: '#6ee7b7', acc2: '#60a5fa',
  muted: '#7f8186', card: '#26282d', line: '#33353b', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};
const seg = (f: number, a: number, b: number, easing: (t: number) => number = Easing.inOut(Easing.cubic)) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const LABELS = ['Publish', 'Publishing…', 'Published'];
// timeline (frames): idle → press 20 → loading 30-90 → success 90-135 → idle
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(.16,1,.3,1);
  const stage = frame < 30 ? 0 : frame < 90 ? 1 : frame < 135 ? 2 : 0;
  const swapAt = [30, 90, 135];
  const lastSwap = Math.max(...swapAt.filter((s) => frame >= s), -100);
  const sw = seg(frame - lastSwap, 0, 14, ease); // text blur-swap progress
  const press = frame >= 20 && frame < 32 ? 1 - 0.04 * Math.sin(((frame - 20) / 12) * Math.PI) : 1;
  const hover = frame < 20 ? seg(frame, 0, 20, ease) : 0.0;
  const shimmer = stage === 1 ? (((frame - 30) % 30) / 30) * 200 - 100 : -100;
  return (
    <div style={{position: 'relative', overflow: 'hidden', padding: '20px 46px', borderRadius: 22, background: C.accent, color: C.on, fontSize: 20, fontWeight: 600, letterSpacing: '-0.02em', transform: `translateY(${-2 * hover}px) scale(${press * (1 + 0.03 * hover)})`, boxShadow: `0 1px 0 #ffffff33 inset, ${14 + 8 * hover}px ${14 + 8 * hover}px 36px ${C.sh2}`}}>
      {stage === 1 && <div style={{position: 'absolute', inset: 0, transform: `translateX(${shimmer}%)`, background: 'linear-gradient(100deg, transparent 30%, #ffffff44 50%, transparent 70%)'}} />}
      <span style={{display: 'inline-block', opacity: frame - lastSwap > 14 ? 1 : sw < 0.5 ? 1 - sw * 2 : sw * 2 - 1, filter: `blur(${frame - lastSwap > 14 ? 0 : (sw < 0.5 ? sw * 2 : 2 - sw * 2) * 4}px)`, transform: `translateY(${sw < 0.5 ? -10 * sw * 2 : 0}px)`}}>
        {LABELS[stage]}
      </span>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
