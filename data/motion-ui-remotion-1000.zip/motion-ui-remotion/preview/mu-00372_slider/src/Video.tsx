import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#06121c', bg2: '#1c2833', fg: '#e6f3ff', accent: '#38bdf8', acc2: '#a78bfa',
  muted: '#76828e', card: '#17232c', line: '#25323c', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';
const clamp01 = (x: number) => Math.min(1, Math.max(0, x));

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(.4,0,.2,1);
  const ph = (frame / 150) * Math.PI * 2;
  const val = 0.5 + 0.4 * Math.sin(ph);
  // smooth the hover state so the track grows and the thumb scales in
  const k = ease(clamp01((Math.sin(ph) - 0.05) / 0.5));
  const H = 14 + 6 * k;
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 16, padding: '16px 22px', borderRadius: 999, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 18px 50px ${C.sh}`, width: 360}}>
      <svg viewBox="0 0 24 24" width={20} height={20} fill={C.fg}><path d="M3 9v6h4l5 4V5L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 8v8a4.5 4.5 0 0 0 2.5-4z" /></svg>
      <div style={{position: 'relative', flex: 1, height: H, borderRadius: 99, background: C.line}}>
        <div style={{height: '100%', width: `${val * 100}%`, borderRadius: 'inherit', background: `linear-gradient(90deg, ${C.accent}, ${C.acc2})`, boxShadow: `0 0 18px ${C.accent}66`}} />
        <div style={{position: 'absolute', top: '50%', left: `${val * 100}%`, width: 20, height: 20, margin: '-10px 0 0 -10px', borderRadius: '50%', background: C.fg, boxShadow: `0 3px 10px ${C.sh2}`, transform: `scale(${k})`}} />
      </div>
      <span style={{font: `600 13px ${MONO}`, width: 30, textAlign: 'right', color: C.muted}}>{Math.round(val * 100)}</span>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
