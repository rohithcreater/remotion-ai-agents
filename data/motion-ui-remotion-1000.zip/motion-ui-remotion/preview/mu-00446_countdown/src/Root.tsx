import {Composition} from 'remotion';
import {Video} from './Video';

export const RemotionRoot = () => {
  return (
    <Composition id="Main" component={Video} durationInFrames={120} fps={30} width={1920} height={1080} />
  );
};
