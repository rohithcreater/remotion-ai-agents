import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#eef6f2', bg2: '#f9fcfa', fg: '#0b1f19', accent: '#12b886', acc2: '#0b1f19',
  muted: '#7c8a86', card: '#fbfdfc', line: '#ced8d4', on: '#0a0a0a', sh: '#0000001f', sh2: '#00000033',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

// piecewise keyframes: stops t[i]→v[i] with an easing function per segment
const kf = (ph: number, ts: number[], vs: number[], es: ((t: number) => number)[]) => {
  for (let i = 0; i < ts.length - 1; i++) {
    if (ph <= ts[i + 1]) {
      const k = (ph - ts[i]) / (ts[i + 1] - ts[i]);
      return vs[i] + (vs[i + 1] - vs[i]) * es[i](Math.min(1, Math.max(0, k)));
    }
  }
  return vs[vs.length - 1];
};
const SEQ = ['3', '2', '1', 'GO'];
const P = 120, FS = 280;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(.22,1,.36,1);
  const ph = (frame % P) / P;
  // digits slide up through a clipped window; each hold is followed by an eased step
  const y = kf(ph, [0, 0.16, 0.24, 0.41, 0.49, 0.66, 0.74, 1], [0, 0, -FS, -FS, -2 * FS, -2 * FS, -3 * FS, -3 * FS], [(t) => t, ease, (t) => t, ease, (t) => t, ease, (t) => t]);
  const R = 46, circ = 2 * Math.PI * R;
  const prog = kf(ph, [0, 0.74, 1], [0, 1, 1], [(t) => t, (t) => t]);
  const ringOp = kf(ph, [0, 0.74, 1], [1, 1, 0.2], [(t) => t, (t) => t]);
  const S = FS * 1.9;
  return (
    <div style={{position: 'relative', display: 'grid', placeItems: 'center', width: S, height: S}}>
      <svg viewBox="0 0 100 100" style={{position: 'absolute', inset: 0, width: '100%', height: '100%', transform: 'rotate(-90deg)'}}>
        <circle cx="50" cy="50" r={R} fill="none" stroke={C.line} strokeWidth={1.5} />
        <circle cx="50" cy="50" r={R} fill="none" stroke={C.accent} strokeWidth={1.5} strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={circ * (1 - prog)} opacity={ringOp} />
      </svg>
      <div style={{height: FS, overflow: 'hidden', fontSize: FS, fontWeight: 900, letterSpacing: '-0.06em', lineHeight: `${FS}px`, textAlign: 'center'}}>
        <div style={{transform: `translateY(${y}px)`}}>
          {SEQ.map((s, i) => <div key={s} style={{height: FS, color: i === 3 ? C.accent : C.fg}}>{s}</div>)}
        </div>
      </div>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
  </Stage>
);
