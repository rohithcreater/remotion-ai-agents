import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#16181d', bg2: '#2b2d32', fg: '#e8eaf0', accent: '#6ee7b7', acc2: '#60a5fa',
  muted: '#7f8186', card: '#26282d', line: '#33353b', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};
const seg = (f: number, a: number, b: number, easing: (t: number) => number = Easing.inOut(Easing.cubic)) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const ROWS = ["Sync", "Offline", "Haptics"];
const STEP = 33; // a new switch flips every STEP frames
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(.22,1,.36,1);
  const n = ROWS.length;
  return (
    <div style={{width: 340, borderRadius: 24, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 28px 70px ${C.sh}`, padding: 8}}>
      {ROWS.map((label, i) => {
        // switch i flips at frame i*STEP (turn on) and again at (i+n)*STEP (turn off)
        const onAt = i * STEP, offAt = (i + n) * STEP;
        const flipOn = ease(seg(frame - onAt, 0, 18, (x) => x));
        const flipOff = ease(seg(frame - offAt, 0, 18, (x) => x));
        const t = frame < offAt ? flipOn : 1 - flipOff;
        const stretch = frame >= onAt && frame < onAt + 18 || frame >= offAt && frame < offAt + 18 ? 8 : 0;
        return (
          <div key={label} style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 18px', fontWeight: 600, letterSpacing: '-0.01em', borderTop: i ? `1px solid ${C.line}` : 'none'}}>
            <span>{label}</span>
            <div style={{position: 'relative', width: 54, height: 32, borderRadius: 99, background: t > 0.5 ? C.accent : C.line}}>
              <div style={{position: 'absolute', top: 3, left: 3 + 22 * t - stretch * t, width: 26 + stretch, height: 26, borderRadius: 99, background: '#fff', boxShadow: '0 2px 6px #0004'}} />
            </div>
          </div>
        );
      })}
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
