import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#16181d', bg2: '#2b2d32', fg: '#e8eaf0', accent: '#6ee7b7', acc2: '#60a5fa',
  muted: '#7f8186', card: '#26282d', line: '#33353b', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const Hud: React.FC<{label: string}> = ({label}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const s = Math.floor(frame / fps), f = frame % fps;
  const tc = `TC 00:00:${String(s % 60).padStart(2, '0')}:${String(f).padStart(2, '0')}`;
  const u = Math.min(width, height) / 1080;
  const corner = (pos: React.CSSProperties): React.CSSProperties => ({position: 'absolute', width: 36 * u, height: 36 * u, border: `${3 * u}px solid ${C.fg}`, ...pos});
  const txt: React.CSSProperties = {position: 'absolute', fontFamily: MONO, fontSize: 20 * u, letterSpacing: '0.14em', textTransform: 'uppercase', color: C.fg};
  const m = 40 * u;
  return (
    <AbsoluteFill style={{opacity: 0.7, pointerEvents: 'none'}}>
      <div style={corner({top: m, left: m, borderRight: 0, borderBottom: 0})} />
      <div style={corner({top: m, right: m, borderLeft: 0, borderBottom: 0})} />
      <div style={corner({bottom: m, left: m, borderRight: 0, borderTop: 0})} />
      <div style={corner({bottom: m, right: m, borderLeft: 0, borderTop: 0})} />
      <div style={{...txt, top: m + 10 * u, left: m + 56 * u}}>Claude / Motion Reel</div>
      <div style={{...txt, top: m + 10 * u, right: m + 56 * u}}>{width}×{height} · {fps}P</div>
      <div style={{...txt, bottom: m + 10 * u, left: m + 56 * u}}>{tc}</div>
      <div style={{...txt, bottom: m + 10 * u, right: m + 56 * u}}>{label}</div>
    </AbsoluteFill>
  );
};

// piecewise keyframes: stops t[i]→v[i] with an easing function per segment
const kf = (ph: number, ts: number[], vs: number[], es: ((t: number) => number)[]) => {
  for (let i = 0; i < ts.length - 1; i++) {
    if (ph <= ts[i + 1]) {
      const k = (ph - ts[i]) / (ts[i + 1] - ts[i]);
      return vs[i] + (vs[i + 1] - vs[i]) * es[i](Math.min(1, Math.max(0, k)));
    }
  }
  return vs[vs.length - 1];
};
const WORD = 'CLAUDE', SUB = 'BRAND FILM';
const P = 180, BLINK = 4; // loop length; number of dot blinks per loop
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const ease = Easing.bezier(0.22, 1, 0.36, 1);
  const size = Math.min(width * 0.16, height * 0.3);
  const reveal = (delay: number, extra = '') => {
    const ph = (((frame - delay) % P) + P) % P / P;
    const o = kf(ph, [0, 0.16, 0.82, 1], [0, 1, 1, 0], [ease, (t) => t, ease]);
    const bl = kf(ph, [0, 0.16, 0.82, 1], [18, 0, 0, 18], [ease, (t) => t, ease]);
    const y = kf(ph, [0, 0.16, 0.82, 1], [26, 0, 0, -18], [ease, (t) => t, ease]);
    const s = kf(ph, [0, 0.16, 0.82, 1], [0.97, 1, 1, 1], [ease, (t) => t, ease]);
    return {opacity: o, filter: `blur(${bl}px)`, transform: `${extra} translateY(${y}px) scale(${s})`.trim()};
  };
  const blink = 0.5 + 0.5 * Math.cos((frame / P) * BLINK * Math.PI * 2); // 1 → 0 → 1
  return (
    <div style={{position: 'relative'}}>
      <div style={{position: 'absolute', width: '150%', height: '34%', left: '-25%', top: '30%', border: `1.5px solid ${C.line}`, borderRadius: '50%', ...reveal(3, 'rotate(-8deg)')}} />
      <div style={{display: 'flex', alignItems: 'center', fontSize: size, fontWeight: 900, letterSpacing: '-0.05em', lineHeight: 1, textShadow: `0 0 60px ${C.acc2}55, 0 0 14px ${C.fg}33`, ...reveal(0)}}>
        {WORD}
        <i style={{display: 'inline-block', width: '0.15em', height: '0.15em', borderRadius: '50%', background: C.acc2, marginLeft: '0.07em', marginTop: '0.5em', boxShadow: `0 0 34px ${C.acc2}`, opacity: 0.25 + 0.75 * blink, transform: `scale(${0.8 + 0.2 * blink})`}} />
      </div>
      <div style={{display: 'flex', justifyContent: 'space-between', marginTop: 20, paddingTop: 14, borderTop: `1.5px solid ${C.line}`, font: `500 ${size * 0.07}px ${MONO}`, letterSpacing: '0.32em', color: C.muted, ...reveal(5)}}>
        <span>{SUB}</span><span>SHOWREEL 2026</span>
      </div>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
      <Hud label="08 — TITLE" />
  </Stage>
);
