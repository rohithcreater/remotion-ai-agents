import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#eef6f2', bg2: '#f9fcfa', fg: '#0b1f19', accent: '#12b886', acc2: '#0b1f19',
  muted: '#7c8a86', card: '#fbfdfc', line: '#ced8d4', on: '#0a0a0a', sh: '#0000001f', sh2: '#00000033',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';
const rnd = (seed: number) => { const s = Math.sin(seed * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Hud: React.FC<{label: string}> = ({label}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const s = Math.floor(frame / fps), f = frame % fps;
  const tc = `TC 00:00:${String(s % 60).padStart(2, '0')}:${String(f).padStart(2, '0')}`;
  const u = Math.min(width, height) / 1080;
  const corner = (pos: React.CSSProperties): React.CSSProperties => ({position: 'absolute', width: 36 * u, height: 36 * u, border: `${3 * u}px solid ${C.fg}`, ...pos});
  const txt: React.CSSProperties = {position: 'absolute', fontFamily: MONO, fontSize: 20 * u, letterSpacing: '0.14em', textTransform: 'uppercase', color: C.fg};
  const m = 40 * u;
  return (
    <AbsoluteFill style={{opacity: 0.7, pointerEvents: 'none'}}>
      <div style={corner({top: m, left: m, borderRight: 0, borderBottom: 0})} />
      <div style={corner({top: m, right: m, borderLeft: 0, borderBottom: 0})} />
      <div style={corner({bottom: m, left: m, borderRight: 0, borderTop: 0})} />
      <div style={corner({bottom: m, right: m, borderLeft: 0, borderTop: 0})} />
      <div style={{...txt, top: m + 10 * u, left: m + 56 * u}}>Claude / Motion Reel</div>
      <div style={{...txt, top: m + 10 * u, right: m + 56 * u}}>{width}×{height} · {fps}P</div>
      <div style={{...txt, bottom: m + 10 * u, left: m + 56 * u}}>{tc}</div>
      <div style={{...txt, bottom: m + 10 * u, right: m + 56 * u}}>{label}</div>
    </AbsoluteFill>
  );
};

const N = 500, SPEED = 0.03 * 2;
const WIDTH = 1920, HEIGHT = 1080;
const DUR = 240;
// cumulative travel distance so speed can breathe while each frame stays a pure function of its index
const TRAVEL: number[] = (() => { const a = [0]; for (let f = 1; f <= DUR + 1; f++) a.push(a[f - 1] + SPEED * (1.2 + Math.sin(((f / 30) * 1000) / 1800) * 0.9)); return a; })();
const depth = (i: number, f: number) => { const z = rnd(i * 3 + 3) - TRAVEL[f]; return ((z % 1) + 1) % 1; };
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ref = React.useRef<HTMLCanvasElement | null>(null);
  React.useEffect(() => {
    const c = ref.current; if (!c) return;
    const x = c.getContext('2d'); if (!x) return;
    x.clearRect(0, 0, WIDTH, HEIGHT);
    x.lineCap = 'round';
    const f = Math.min(frame, DUR), k = Math.min(WIDTH, HEIGHT) * 0.25;
    for (let i = 0; i < N; i++) {
      const sx = (rnd(i * 3 + 1) - 0.5) * 2, sy = (rnd(i * 3 + 2) - 0.5) * 2;
      const z = depth(i, f), pz = depth(i, Math.max(0, f - 1) );
      if (z > pz || z < 0.01) continue; // just respawned
      const x1 = WIDTH / 2 + (sx / z) * k, y1 = HEIGHT / 2 + (sy / z) * k;
      const x0 = WIDTH / 2 + (sx / pz) * k, y0 = HEIGHT / 2 + (sy / pz) * k;
      x.strokeStyle = sx * sy > 0.3 ? C.acc2 : C.fg;
      x.globalAlpha = Math.min(1, (1 - z) * 1.4); x.lineWidth = (1 - z) * 3.4;
      x.beginPath(); x.moveTo(x0, y0); x.lineTo(x1, y1); x.stroke();
    }
    x.globalAlpha = 1;
  }, [frame]);
  return <canvas ref={ref} width={WIDTH} height={HEIGHT} style={{position: 'absolute', inset: 0, width: '100%', height: '100%'}} />;
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Hud label="01 — WARP FIELD" />
  </Stage>
);
