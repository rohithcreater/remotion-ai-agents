import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#0f0b1f', bg2: '#262235', fg: '#f1edff', accent: '#7c5cff', acc2: '#ff6adf',
  muted: '#807c8f', card: '#201c2f', line: '#2f2b3e', on: '#ffffff', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};
const seg = (f: number, a: number, b: number, easing: (t: number) => number = Easing.inOut(Easing.cubic)) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const LABELS = ["Day", "Week", "Month"];
const HOLD = 57; // frames each tab stays selected
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(.34,1.56,.64,1);
  const n = LABELS.length;
  const step = Math.floor(frame / HOLD);
  const local = frame - step * HOLD;
  // slide from the previous tab to the current one during the first 20 frames of each hold
  const from = step % n, to = (step + 1) % n;
  const t = ease(seg(local - (HOLD - 20), 0, 20, (x) => x));
  const wrap = to === 0 ? n : to;
  const sel = from + (wrap - from) * t;
  const active = Math.round(sel) % n;
  return (
    <div style={{position: 'relative', display: 'flex', gap: 30, borderBottom: `1px solid ${C.line}`}}>
      {LABELS.map((l, i) => (
        <div key={l} style={{padding: '14px 2px', fontWeight: 600, fontSize: 16, letterSpacing: '-0.01em', color: i === active ? C.fg : C.muted}}>{l}</div>
      ))}
      <div style={{position: 'absolute', bottom: -1, left: 0, height: 2, width: 44, borderRadius: 2, background: C.accent, transform: `translateX(${(sel % n) * 96}px)`}} />
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
