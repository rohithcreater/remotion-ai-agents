import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#ece9e1', bg2: '#f8f7f4', fg: '#111111', accent: '#e5341d', acc2: '#111111',
  muted: '#7e7d79', card: '#fafaf8', line: '#cdcbc4', on: '#ffffff', sh: '#0000001f', sh2: '#00000033',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const clamp01 = (x: number) => Math.min(1, Math.max(0, x));

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const N = 8, DIST = 46, PERIOD = 60;
const COLORS = ['#ff4d6d', '#ffb703'];
const HEART = 'M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z';
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const toggle = Math.floor(frame / PERIOD);       // each period flips liked ↔ unliked
  const liked = toggle % 2 === 1;
  const local = frame - toggle * PERIOD;
  const t = clamp01(local / 21);                   // 0.7s pop at 30fps
  const pop = liked ? (t < 0.5 ? 0.4 + 0.95 * Easing.out(Easing.cubic)(t * 2) : 1.35 - 0.35 * Easing.inOut(Easing.cubic)((t - 0.5) * 2)) : 1;
  const burst = liked ? Easing.bezier(0.2, 0.7, 0.2, 1)(t) : 0;
  const base = 1248 + (liked ? 1 : 0);
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 14, padding: '16px 26px 16px 20px', borderRadius: 99, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 20px 50px ${C.sh}`}}>
      <div style={{position: 'relative', width: 44, height: 44}}>
        <svg viewBox="0 0 24 24" style={{position: 'absolute', inset: 0, width: '100%', height: '100%', fill: liked ? COLORS[0] : C.line, transform: `scale(${pop})`}}><path d={HEART} /></svg>
        {liked && Array.from({length: N}).map((_, k) => (
          <div key={k} style={{position: 'absolute', left: '50%', top: '50%', width: 7, height: 7, margin: -3.5, borderRadius: '50%', background: COLORS[k % 2 ? 0 : 1], opacity: t < 1 ? 1 - burst : 0, transform: `rotate(${(360 / N) * k}deg) translateY(${-(14 + (DIST - 14) * burst)}px) scale(${1 - 0.8 * burst})`}} />
        ))}
      </div>
      <div style={{font: '700 22px Inter, system-ui', letterSpacing: '-0.03em', fontVariantNumeric: 'tabular-nums', minWidth: 60}}>{base.toLocaleString('en-US')}</div>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
