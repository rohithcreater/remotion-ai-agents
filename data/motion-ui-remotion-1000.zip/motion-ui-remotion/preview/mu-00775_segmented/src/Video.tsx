import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#16181d', bg2: '#2b2d32', fg: '#e8eaf0', accent: '#6ee7b7', acc2: '#60a5fa',
  muted: '#7f8186', card: '#26282d', line: '#33353b', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};
const seg = (f: number, a: number, b: number, easing: (t: number) => number = Easing.inOut(Easing.cubic)) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const LABELS = ["Day", "Week", "Month"];
const HOLD = 57; // frames each tab stays selected
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(.7,0,.2,1);
  const n = LABELS.length;
  const step = Math.floor(frame / HOLD);
  const local = frame - step * HOLD;
  // slide from the previous tab to the current one during the first 12 frames of each hold
  const from = step % n, to = (step + 1) % n;
  const t = ease(seg(local - (HOLD - 12), 0, 12, (x) => x));
  const wrap = to === 0 ? n : to;
  const sel = from + (wrap - from) * t;
  const active = Math.round(sel) % n;
  return (
    <div style={{position: 'relative', display: 'grid', gridTemplateColumns: `repeat(${n}, 1fr)`, padding: 6, borderRadius: 999, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 14px 40px ${C.sh}`, width: n * 112}}>
      <div style={{position: 'absolute', top: 6, bottom: 6, left: 6, width: `calc((100% - 12px) / ${n})`, borderRadius: 999, background: C.accent, boxShadow: `0 6px 18px ${C.sh2}`, transform: `translateX(${(sel % n) * 100}%)`}} />
      {LABELS.map((l, i) => (
        <div key={l} style={{position: 'relative', zIndex: 1, textAlign: 'center', padding: '12px 0', fontWeight: 600, fontSize: 15, letterSpacing: '-0.01em', color: i === active ? C.on : C.muted}}>{l}</div>
      ))}
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
