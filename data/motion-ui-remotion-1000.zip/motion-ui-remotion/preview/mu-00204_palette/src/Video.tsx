import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#16181d', bg2: '#2b2d32', fg: '#e8eaf0', accent: '#6ee7b7', acc2: '#60a5fa',
  muted: '#7f8186', card: '#26282d', line: '#33353b', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};
const seg = (f: number, a: number, b: number, easing: (t: number) => number = Easing.inOut(Easing.cubic)) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const ITEMS = ["Frame rate \u00b7 60fps", "Every frame is code", "Export as MP4", "Frame selection", "New project"];
const QUERY = "fram";
const EVERY = 3; // frames per typed character
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const n = Math.min(QUERY.length, Math.floor(frame / EVERY));
  const typed = QUERY.slice(0, n);
  const matches = ITEMS.filter((i) => i.toLowerCase().includes(typed.toLowerCase()));
  const caretOn = Math.floor(frame / 15) % 2 === 0;
  return (
    <div style={{width: 400, borderRadius: 22, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 30px 80px ${C.sh}`, overflow: 'hidden'}}>
      <div style={{display: 'flex', gap: 12, alignItems: 'center', padding: '18px 20px', borderBottom: `1px solid ${C.line}`}}>
        <svg viewBox="0 0 24 24" width={18} height={18} fill="none" stroke={C.muted} strokeWidth={2} strokeLinecap="round"><circle cx="11" cy="11" r="7" /><path d="M20 20l-3.5-3.5" /></svg>
        <div style={{flex: 1, fontSize: 17, letterSpacing: '-0.01em'}}>{typed}</div>
        <div style={{width: 2, height: 20, background: C.accent, opacity: caretOn ? 1 : 0}} />
        <div style={{font: `600 11px ${MONO}`, padding: '4px 7px', borderRadius: 7, background: C.line, color: C.muted}}>⌘K</div>
      </div>
      <div style={{padding: 8, minHeight: 150}}>
        {matches.length === 0 && <div style={{padding: '12px 14px', fontSize: 14.5, color: C.muted}}>No results</div>}
        {matches.map((m, k) => {
          const appear = seg(frame - n * EVERY, 0, 10, Easing.out(Easing.cubic));
          return (
            <div key={m} style={{display: 'flex', alignItems: 'center', padding: '12px 14px', borderRadius: 13, fontSize: 14.5, background: k === 0 ? C.line : 'transparent', opacity: 0.4 + 0.6 * appear, transform: `translateY(${(1 - appear) * 6}px)`}}>
              {k === 0 && <div style={{width: 3, height: 16, borderRadius: 2, background: C.accent, marginRight: 10}} />}
              <span style={{flex: 1}}>{m}</span>
              {k === 0 && <div style={{font: `600 11px ${MONO}`, padding: '4px 7px', borderRadius: 7, background: C.line, color: C.muted}}>↵</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
