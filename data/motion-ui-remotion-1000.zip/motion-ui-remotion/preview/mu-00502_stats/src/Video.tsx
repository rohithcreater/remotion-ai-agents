import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#fff1f0', bg2: '#fffafa', fg: '#2a0f12', accent: '#ff4d6d', acc2: '#ffb703',
  muted: '#948081', card: '#fffcfb', line: '#e1d1d1', on: '#ffffff', sh: '#0000001f', sh2: '#00000033',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};
const seg = (f: number, a: number, b: number, easing: (t: number) => number = Easing.inOut(Easing.cubic)) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const TABS = ["Day", "Week", "Month"];
const TOTALS = [1284, 4636, 170343];
const PATHS = ["M0.0,78.1 C11.5,78.1 11.5,74.2 23.1,74.2 C34.6,74.2 34.6,73.1 46.2,73.1 C57.7,73.1 57.7,69.6 69.2,69.6 C80.8,69.6 80.8,76.7 92.3,76.7 C103.8,76.7 103.8,83.0 115.4,83.0 C126.9,83.0 126.9,89.6 138.5,89.6 C150.0,89.6 150.0,89.1 161.5,89.1 C173.1,89.1 173.1,97.3 184.6,97.3 C196.2,97.3 196.2,94.8 207.7,94.8 C219.2,94.8 219.2,97.3 230.8,97.3 C242.3,97.3 242.3,101.4 253.8,101.4 C265.4,101.4 265.4,98.5 276.9,98.5 C288.5,98.5 288.5,98.0 300.0,98.0", "M0.0,62.8 C11.5,62.8 11.5,58.7 23.1,58.7 C34.6,58.7 34.6,65.9 46.2,65.9 C57.7,65.9 57.7,61.6 69.2,61.6 C80.8,61.6 80.8,65.5 92.3,65.5 C103.8,65.5 103.8,61.1 115.4,61.1 C126.9,61.1 126.9,66.9 138.5,66.9 C150.0,66.9 150.0,71.4 161.5,71.4 C173.1,71.4 173.1,80.5 184.6,80.5 C196.2,80.5 196.2,81.7 207.7,81.7 C219.2,81.7 219.2,90.2 230.8,90.2 C242.3,90.2 242.3,86.9 253.8,86.9 C265.4,86.9 265.4,83.1 276.9,83.1 C288.5,83.1 288.5,82.7 300.0,82.7", "M0.0,70.9 C11.5,70.9 11.5,74.7 23.1,74.7 C34.6,74.7 34.6,69.5 46.2,69.5 C57.7,69.5 57.7,66.3 69.2,66.3 C80.8,66.3 80.8,69.1 92.3,69.1 C103.8,69.1 103.8,70.9 115.4,70.9 C126.9,70.9 126.9,64.8 138.5,64.8 C150.0,64.8 150.0,59.6 161.5,59.6 C173.1,59.6 173.1,62.0 184.6,62.0 C196.2,62.0 196.2,64.9 207.7,64.9 C219.2,64.9 219.2,59.6 230.8,59.6 C242.3,59.6 242.3,65.2 253.8,65.2 C265.4,65.2 265.4,62.5 276.9,62.5 C288.5,62.5 288.5,65.1 300.0,65.1"];
const HOLD = 84;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(.34,1.56,.64,1);
  const i = Math.floor(frame / HOLD) % 3;
  const local = frame % HOLD;
  const slide = ease(seg(local, 0, 14, (x) => x));
  const prev = (i + 2) % 3;
  const pillX = (i === 0 && frame >= HOLD ? prev + (3 - prev) * slide : prev + (i - prev) * slide) % 3;
  const count = Math.round(TOTALS[i] * (1 - Math.pow(1 - seg(local, 0, 36, (x) => x), 4)));
  const draw = ease(seg(local, 0, 39, (x) => x));
  const area = seg(local, 15, 39, (x) => x);
  const colW = 64;
  return (
    <div style={{width: 380, padding: '24px 26px 26px', borderRadius: 28, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 30px 70px ${C.sh}`}}>
      <div style={{position: 'relative', display: 'flex', gap: 4, padding: 4, borderRadius: 99, background: C.line, width: 'max-content', margin: '0 auto 22px'}}>
        <div style={{position: 'absolute', top: 4, bottom: 4, left: 4, width: colW - 4, borderRadius: 99, background: C.accent, transform: `translateX(${pillX * colW}px)`}} />
        {TABS.map((t, k) => (
          <div key={t} style={{position: 'relative', zIndex: 1, width: colW - 4, textAlign: 'center', padding: '7px 0', fontSize: 12, fontWeight: 600, color: k === i ? C.on : C.muted}}>{t}</div>
        ))}
      </div>
      <div style={{fontSize: 56, fontWeight: 700, letterSpacing: '-0.04em', fontVariantNumeric: 'tabular-nums', lineHeight: 1}}>{count.toLocaleString('en-US')}</div>
      <div style={{fontSize: 13, color: C.muted, margin: '6px 0 14px'}}>total views</div>
      <svg viewBox="0 0 300 140" style={{width: '100%', overflow: 'visible'}}>
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={C.accent} stopOpacity={0.28} /><stop offset="1" stopColor={C.accent} stopOpacity={0} /></linearGradient>
        </defs>
        <path d={PATHS[i] + ' L300,140 L0,140 Z'} fill="url(#g)" opacity={area} />
        <path d={PATHS[i]} pathLength={1} fill="none" stroke={C.accent} strokeWidth={2.5} strokeLinecap="round" strokeDasharray="1" strokeDashoffset={1 - draw} />
      </svg>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
