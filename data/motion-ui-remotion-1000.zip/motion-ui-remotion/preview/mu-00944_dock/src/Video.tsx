import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#2b3cff', bg2: '#4050ff', fg: '#ffffff', accent: '#ffffff', acc2: '#ffd23f',
  muted: '#959eff', card: '#3a4aff', line: '#4957ff', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const ICONS = [{"l": "A", "g": ["#43e97b", "#38f9d7", "#2b6cff"]}, {"l": "B", "g": ["#00c6ff", "#7b5cff", "#ff4d9d"]}, {"l": "C", "g": ["#ff6a88", "#ff99ac", "#ffd1a1"]}, {"l": "D", "g": ["#00c6ff", "#7b5cff", "#ff4d9d"]}, {"l": "E", "g": ["#84fab0", "#8fd3f4", "#a18cd1"]}, {"l": "F", "g": ["#ff9a44", "#ff4d6d", "#7b5cff"]}, {"l": "G", "g": ["#fa709a", "#fee140", "#ff9a44"]}];
const S = 54, GAP = 12, MAXZ = 0.7, R = 70; // base size, gap, extra magnification, gaussian radius
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const n = ICONS.length;
  const W = n * (S + GAP) - GAP;
  // simulated cursor sweeps left↔right once per loop
  const px = W / 2 + Math.sin((frame / durationInFrames) * Math.PI * 2) * W * 0.62;
  const sizes = ICONS.map((_, i) => {
    const cx = i * (S + GAP) + S / 2;
    return S * (1 + MAXZ * Math.exp(-Math.pow((cx - px) / R, 2)));
  });
  return (
    <div style={{display: 'flex', gap: GAP, alignItems: 'flex-end', padding: '10px 14px', height: 111, borderRadius: 28, transform: 'scale(0.82)', background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 30px 70px ${C.sh}`}}>
      {ICONS.map((ic, i) => (
        <div key={ic.l} style={{width: sizes[i], height: sizes[i], borderRadius: '24%', display: 'grid', placeItems: 'center', fontWeight: 800, color: '#fff', fontSize: 18 * (sizes[i] / S), textShadow: '0 1px 3px #0005', background: `linear-gradient(135deg, ${ic.g[0]}, ${ic.g[1]}, ${ic.g[2]})`, boxShadow: '0 8px 18px #0003, 0 1px 0 #ffffff55 inset'}}>
          {ic.l}
        </div>
      ))}
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scaled><Scene /></Scaled>
      <Grain />
  </Stage>
);
