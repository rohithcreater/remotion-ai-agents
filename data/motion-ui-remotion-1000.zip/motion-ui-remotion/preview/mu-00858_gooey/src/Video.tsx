import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#2b3cff', bg2: '#4050ff', fg: '#ffffff', accent: '#ffffff', acc2: '#ffd23f',
  muted: '#959eff', card: '#3a4aff', line: '#4957ff', on: '#0a0a0a', sh: '#00000066', sh2: '#00000099',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const BLOBS = [{"d": 200, "l": 535, "t": 345, "m": 1, "off": 0.0, "x0": -29, "y0": 20, "s0": 0.7, "x1": 59, "y1": -117, "s1": 1.12}, {"d": 227, "l": 400, "t": 62, "m": 1, "off": 0.167, "x0": -26, "y0": -106, "s0": 0.68, "x1": 33, "y1": 95, "s1": 1.27}, {"d": 330, "l": 416, "t": 398, "m": 2, "off": 0.333, "x0": -73, "y0": 26, "s0": 0.66, "x1": -33, "y1": 11, "s1": 1.28}, {"d": 257, "l": 150, "t": 112, "m": 1, "off": 0.5, "x0": 29, "y0": 42, "s0": 0.77, "x1": 106, "y1": -53, "s1": 1.26}, {"d": 284, "l": 44, "t": 103, "m": 2, "off": 0.667, "x0": -40, "y0": -86, "s0": 1.0, "x1": -51, "y1": 108, "s1": 1.16}, {"d": 235, "l": 262, "t": 108, "m": 1, "off": 0.833, "x0": -9, "y0": 48, "s0": 0.95, "x1": 15, "y1": -46, "s1": 0.83}];
const L = 420; // loop length in frames; each blob completes m ping-pong cycles per loop
const SIZE = 750;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(0.42, 0, 0.58, 1); // CSS ease-in-out
  return (
    <div style={{position: 'relative', width: SIZE, height: SIZE, filter: `url(#goo) drop-shadow(0 30px 40px ${C.sh})`}}>
      <svg width={0} height={0} style={{position: 'absolute'}}>
        <defs>
          <filter id="goo">
            <feGaussianBlur in="SourceGraphic" stdDeviation={20 * 2.2} result="b" />
            <feColorMatrix in="b" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 22 -9" />
          </filter>
        </defs>
      </svg>
      {BLOBS.map((b, i) => {
        const cyc = (frame / L) * b.m + b.off;           // cycles completed
        const tri = Math.abs(((cyc % 1) + 1) % 1 * 2 - 1); // ping-pong 0..1..0
        const t = ease(1 - tri);
        const x = b.x0 + (b.x1 - b.x0) * t, y = b.y0 + (b.y1 - b.y0) * t, s = b.s0 + (b.s1 - b.s0) * t;
        return <div key={i} style={{position: 'absolute', width: b.d, height: b.d, left: b.l, top: b.t, borderRadius: '50%', background: C.accent, transform: `translate(${x}px, ${y}px) scale(${s})`}} />;
      })}
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
  </Stage>
);
