import React from 'react';
import {AbsoluteFill, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

const C = {
  bg: '#ece9e1', bg2: '#f8f7f4', fg: '#111111', accent: '#e5341d', acc2: '#111111',
  muted: '#7e7d79', card: '#fafaf8', line: '#cdcbc4', on: '#ffffff', sh: '#0000001f', sh2: '#00000033',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';

const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);

const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};

const Hud: React.FC<{label: string}> = ({label}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const s = Math.floor(frame / fps), f = frame % fps;
  const tc = `TC 00:00:${String(s % 60).padStart(2, '0')}:${String(f).padStart(2, '0')}`;
  const u = Math.min(width, height) / 1080;
  const corner = (pos: React.CSSProperties): React.CSSProperties => ({position: 'absolute', width: 36 * u, height: 36 * u, border: `${3 * u}px solid ${C.fg}`, ...pos});
  const txt: React.CSSProperties = {position: 'absolute', fontFamily: MONO, fontSize: 20 * u, letterSpacing: '0.14em', textTransform: 'uppercase', color: C.fg};
  const m = 40 * u;
  return (
    <AbsoluteFill style={{opacity: 0.7, pointerEvents: 'none'}}>
      <div style={corner({top: m, left: m, borderRight: 0, borderBottom: 0})} />
      <div style={corner({top: m, right: m, borderLeft: 0, borderBottom: 0})} />
      <div style={corner({bottom: m, left: m, borderRight: 0, borderTop: 0})} />
      <div style={corner({bottom: m, right: m, borderLeft: 0, borderTop: 0})} />
      <div style={{...txt, top: m + 10 * u, left: m + 56 * u}}>Claude / Motion Reel</div>
      <div style={{...txt, top: m + 10 * u, right: m + 56 * u}}>{width}×{height} · {fps}P</div>
      <div style={{...txt, bottom: m + 10 * u, left: m + 56 * u}}>{tc}</div>
      <div style={{...txt, bottom: m + 10 * u, right: m + 56 * u}}>{label}</div>
    </AbsoluteFill>
  );
};

// piecewise keyframes: stops t[i]→v[i] with an easing function per segment
const kf = (ph: number, ts: number[], vs: number[], es: ((t: number) => number)[]) => {
  for (let i = 0; i < ts.length - 1; i++) {
    if (ph <= ts[i + 1]) {
      const k = (ph - ts[i]) / (ts[i + 1] - ts[i]);
      return vs[i] + (vs[i + 1] - vs[i]) * es[i](Math.min(1, Math.max(0, k)));
    }
  }
  return vs[vs.length - 1];
};
const WORD = 'SPARK';
const P = 102, STAGGER = 2; // loop length and per-letter delay in frames
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const ease = Easing.bezier(.22,1,.36,1);
  const size = Math.min(width * 0.15, height * 0.26);
  const capOp = kf(((frame % P) / P), [0, 0.15, 0.3, 0.75, 1], [0, 0, 1, 1, 0], [(t) => t, (t) => t, (t) => t, (t) => t]);
  return (
    <div>
      <div style={{display: 'flex', fontSize: size, fontWeight: 900, letterSpacing: '-0.045em', lineHeight: 1, perspective: 700}}>
        {WORD.split('').map((ch, i) => {
          const local = frame - i * STAGGER;
          const ph = local < 0 ? 0 : (local % P) / P;
          const s = kf(ph, [0, 0.25, 0.75, 1], [0.2, 1, 1, 1.6], [ease, (t) => t, ease]);
          const o = kf(ph, [0, 0.25, 0.75, 1], [0, 1, 1, 0], [ease, (t) => t, ease]);
          const style: React.CSSProperties = {transform: `scale(${s})`, opacity: o};
          const mask: React.CSSProperties = {};
          return (
            <div key={i} style={mask}>
              <span style={{display: 'inline-block', transformOrigin: '50% 100%', ...style}}>{ch}</span>
            </div>
          );
        })}
      </div>
      <div style={{marginTop: 22, textAlign: 'center', font: `500 ${size * 0.07}px ${MONO}`, letterSpacing: '0.4em', color: C.muted, opacity: capOp}}>SHOWREEL 2026</div>
    </div>
  );
};

export const Video: React.FC = () => (
  <Stage>
      <Scene />
      <Grain />
      <Hud label="03 — KINETIC TYPE" />
  </Stage>
);
