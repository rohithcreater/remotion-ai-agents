# Motion UI → Remotion dataset (1000 samples)

Brief → complete Remotion v4 project (5 files). Same record format and system prompt as `remotion-curated`, so the two can be concatenated.

- `dataset/train.jsonl` (950), `val.jsonl` (50, all 32 families), `dataset.jsonl` (all). Fields: id, source, family, palette, messages.
- 32 families: 16 UI micro-interactions (spinner, segmented, slider, player, palette, button, ripple, stats, toggles, toast, dock, ring, like, tilt, skeleton, scramble), 13 motion graphics (kinetic, squash, particles, flow, stars, glitch, pattern, tiles, gooey, orbits, monogram, title, countdown) and 3 WebGL shaders (metaballs, aurora, contours).
- Every animated value is a pure function of `useCurrentFrame()`. Simulations (particles, flow, stars) are precomputed at module load. Most scenes loop seamlessly; those three do not.
- WebGL scenes need `remotion render ... --gl=angle` (already in each package.json).
- `preview/` has 64 runnable projects (`npm i && npm start`). `gallery/` shows 4 frames per family.

## Validation done
- All 1000 pass strict `tsc` against *stub* typings for remotion/react (offline) plus format/forbidden-API checks (`generator/validate_remotion.py`).
- 128 samples mounted in headless Chromium with a mock `remotion` (`generator/runtime_check.py`): no exceptions/NaN/blank frames.
- NOT done: rendering with the real Remotion renderer or real package types. Do a test render before training.

## Regenerate
`cd generator && python make_remotion_dataset.py --n 1000 --seed 7 --out ../out --preview 64`

Limits: 32 templates (~31 samples each); ~1.6M tokens total, so use alongside the larger dataset.
