import json, os, re, shutil, subprocess
from playwright.sync_api import sync_playwright
from PIL import Image, ImageDraw
from validate_remotion import parse
def make(path='out/dataset.jsonl', outdir='out/gallery'):
    rows=[json.loads(l) for l in open(path)]; seen=set(); pick=[]
    for r in rows:
        if r['family'] not in seen: seen.add(r['family']); pick.append(r)
    pick.sort(key=lambda r:r['family']); shutil.rmtree('harness/s',ignore_errors=True); meta={}
    for r in pick:
        _,files=parse(r['messages'][2]['content']); d=f"harness/s/{r['id']}"; os.makedirs(d); open(f'{d}/Video.tsx','w').write(files['src/Video.tsx'])
        m=re.search(r"durationInFrames=\{(\d+)\} fps=\{(\d+)\} width=\{(\d+)\} height=\{(\d+)\}",files['src/Root.tsx']); meta[r['id']]=(r['family'],*map(int,m.groups()))
    subprocess.run(['node','harness/bundle.mjs','harness/s'],check=True); os.makedirs(outdir,exist_ok=True); sheets=[]
    with sync_playwright() as p:
        b=p.chromium.launch(args=['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
        for sid,(fam,dur,fps,W,H) in meta.items():
            pg=b.new_page(viewport={'width':W//2,'height':H//2}); pg.set_content(f'<html><body style="margin:0"><div id="app" style="position:relative;width:{W}px;height:{H}px;overflow:hidden;zoom:.5"></div></body></html>'); pg.add_script_tag(path=f'harness/s/{sid}/bundle.js'); ims=[]
            for k in (.08,.33,.58,.83):
                fr=int(dur*k); pg.evaluate('c=>window.__show(c)',dict(frame=fr,fps=fps,width=W,height=H,durationInFrames=dur)); pg.wait_for_timeout(100)
                pg.screenshot(path='/tmp/g.png',clip=dict(x=0,y=0,width=W//2,height=H//2)); ims.append(Image.open('/tmp/g.png').convert('RGB').resize((400,225 if W!=H else 400)))
            sh=Image.new('RGB',(1600,ims[0].height+16),(40,40,40)); ImageDraw.Draw(sh).text((6,2),f'{fam}  ({W}x{H}, {fps}fps, {dur}f)',fill=(255,255,0))
            for i,im in enumerate(ims): sh.paste(im,(i*400,16))
            sheets.append(sh); pg.close()
        b.close()
    for gi in range(4):
        grp=sheets[gi*8:(gi+1)*8]; H=sum(s.height for s in grp); m=Image.new('RGB',(1600,H)); y=0
        for s in grp: m.paste(s,(0,y)); y+=s.height
        m.save(f'{outdir}/gallery_{gi+1}.png')
if __name__=='__main__': make()
