"""Core for the Remotion port: project scaffold, shared TSX helpers, prompt builder."""
import json, random, re
from make_dataset import PALS, GRADS, WORDS, OPEN, CTX, mix, hx, fill, EASE

SYSTEM = ("You are an expert Remotion v4 + TypeScript motion designer. Given a video brief, reply with one line starting with '// PLAN:' "
          "summarising the motion design, then the complete project as files, each introduced by a line '// ===== FILE: <path> =====' "
          "followed by the file contents. Use only 'remotion' and the dependencies listed in package.json. All animation must be a pure "
          "function of useCurrentFrame() so frames render deterministically.")

PKG = {"name": "", "version": "1.0.0", "private": True,
       "scripts": {"start": "remotion studio src/index.ts", "render": "remotion render src/index.ts Main out/video.mp4 --gl=angle"},
       "dependencies": {"@remotion/cli": "4.0.539", "react": "^18.3.1", "react-dom": "^18.3.1", "remotion": "4.0.539"},
       "devDependencies": {"@types/react": "^18.3.1", "typescript": "^5.4.0"}}
TSC = {"compilerOptions": {"target": "ES2020", "module": "ESNext", "moduleResolution": "Bundler", "jsx": "react-jsx",
       "strict": True, "noEmit": True, "skipLibCheck": True, "lib": ["ES2022", "DOM"]}, "include": ["src"]}
INDEX = "import {registerRoot} from 'remotion';\nimport {RemotionRoot} from './Root';\n\nregisterRoot(RemotionRoot);\n"
ROOT = """import {Composition} from 'remotion';
import {Video} from './Video';

export const RemotionRoot = () => {
  return (
    <Composition id="Main" component={Video} durationInFrames={__DUR__} fps={__FPS__} width={__W__} height={__H__} />
  );
};
"""

# ---- shared TSX prelude: palette tokens, helpers, reel HUD + grain (all pure functions of frame)
THEME = """const C = {
  bg: '__BG__', bg2: '__BG2__', fg: '__FG__', accent: '__ACCENT__', acc2: '__ACC2__',
  muted: '__MUTED__', card: '__CARD__', line: '__LINE__', on: '__ON__', sh: '__SH__', sh2: '__SH2__',
};
const FONT = 'Inter, "SF Pro Display", system-ui, -apple-system, "Helvetica Neue", sans-serif';
const MONO = 'ui-monospace, SFMono-Regular, Menlo, monospace';
const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
const rnd = (seed: number) => { const s = Math.sin(seed * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
"""

STAGE = """const Stage: React.FC<{children: React.ReactNode}> = ({children}) => (
  <AbsoluteFill style={{background: `radial-gradient(110% 90% at 50% 35%, ${C.bg2}, ${C.bg} 72%)`, color: C.fg, fontFamily: FONT, justifyContent: 'center', alignItems: 'center', overflow: 'hidden'}}>
    {children}
  </AbsoluteFill>
);
"""

GRAIN = """const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const dx = (frame * 37) % 160, dy = (frame * 91) % 160;
  return (
    <AbsoluteFill style={{pointerEvents: 'none', opacity: 0.07, mixBlendMode: 'overlay'}}>
      <svg width={width} height={height}>
        <filter id="grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves={2} seed={frame % 24} stitchTiles="stitch" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" transform={`translate(${dx} ${dy})`} />
      </svg>
    </AbsoluteFill>
  );
};
"""

HUD = """const Hud: React.FC<{label: string}> = ({label}) => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const s = Math.floor(frame / fps), f = frame % fps;
  const tc = `TC 00:00:${String(s % 60).padStart(2, '0')}:${String(f).padStart(2, '0')}`;
  const u = Math.min(width, height) / 1080;
  const corner = (pos: React.CSSProperties): React.CSSProperties => ({position: 'absolute', width: 36 * u, height: 36 * u, border: `${3 * u}px solid ${C.fg}`, ...pos});
  const txt: React.CSSProperties = {position: 'absolute', fontFamily: MONO, fontSize: 20 * u, letterSpacing: '0.14em', textTransform: 'uppercase', color: C.fg};
  const m = 40 * u;
  return (
    <AbsoluteFill style={{opacity: 0.7, pointerEvents: 'none'}}>
      <div style={corner({top: m, left: m, borderRight: 0, borderBottom: 0})} />
      <div style={corner({top: m, right: m, borderLeft: 0, borderBottom: 0})} />
      <div style={corner({bottom: m, left: m, borderRight: 0, borderTop: 0})} />
      <div style={corner({bottom: m, right: m, borderLeft: 0, borderTop: 0})} />
      <div style={{...txt, top: m + 10 * u, left: m + 56 * u}}>Claude / Motion Reel</div>
      <div style={{...txt, top: m + 10 * u, right: m + 56 * u}}>{width}×{height} · {fps}P</div>
      <div style={{...txt, bottom: m + 10 * u, left: m + 56 * u}}>{tc}</div>
      <div style={{...txt, bottom: m + 10 * u, right: m + 56 * u}}>{label}</div>
    </AbsoluteFill>
  );
};
"""

def theme_block(p):
    return fill(THEME, bg=p["bg"], bg2=p["bg2"], fg=p["fg"], accent=p["accent"], acc2=p["acc2"], muted=p["muted"],
                card=p["card"], line=p["line"], on=p["on"], sh=p["sh"], sh2=p["sh2"])

def video_file(imports, p, body, hud=None, grain=True):
    """Assemble src/Video.tsx. `body` defines `Scene` (the family content) using C / helpers."""
    names = sorted(set(["AbsoluteFill", "useCurrentFrame", "useVideoConfig"] + imports))
    parts = [f"import React from 'react';\nimport {{{', '.join(names)}}} from 'remotion';\n", theme_block(p), STAGE]
    if grain: parts.append(GRAIN)
    if hud: parts.append(HUD)
    parts.append(body.strip() + "\n")
    layers = "      <Scene />\n" + ("      <Grain />\n" if grain else "") + (f"      <Hud label=\"{hud}\" />\n" if hud else "")
    parts.append("export const Video: React.FC = () => (\n  <Stage>\n" + layers + "  </Stage>\n);\n")
    return "\n".join(parts)

def project(sid, files_video, W, H, fps, dur):
    pk = dict(PKG); pk["name"] = sid
    return {"package.json": json.dumps(pk, indent=2) + "\n", "tsconfig.json": json.dumps(TSC, indent=2) + "\n",
            "src/index.ts": INDEX, "src/Root.tsx": fill(ROOT, dur=dur, fps=fps, w=W, h=H), "src/Video.tsx": files_video}

def assemble(plan, files):
    order = ["package.json", "tsconfig.json", "src/index.ts", "src/Root.tsx", "src/Video.tsx"]
    return plan.replace("\n", " ") + "\n\n" + "\n\n".join(f"// ===== FILE: {k} =====\n{files[k].rstrip()}" for k in order) + "\n"

def tsx(_tpl, **kw):
    """fill __KEY__ placeholders; JSON for lists/dicts"""
    return fill(_tpl, **{k: (json.dumps(v) if isinstance(v, (list, dict)) else v) for k, v in kw.items()})

SCALED = """const Scaled: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {width, height} = useVideoConfig();
  const k = Math.min(width, height) / 540;
  return <div style={{transform: `scale(${k})`, transformOrigin: 'center center'}}>{children}</div>;
};
const seg = (f: number, a: number, b: number, easing: (t: number) => number = Easing.inOut(Easing.cubic)) =>
  interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});
"""

def ez(name):
    m = re.match(r"cubic-bezier\(([^)]*)\)", EASE[name]); return "Easing.bezier(" + m.group(1) + ")"

def video_file(imports, p, body, hud=None, grain=True, scaled=True):   # noqa: F811
    th = theme_block(p)
    allsrc = body + (HUD if hud else "")
    for helper in ("clamp01", "rnd", "MONO"):
        if not re.search(r"\b" + helper + r"\b", allsrc):
            th = "\n".join(l for l in th.split("\n") if not l.startswith(f"const {helper} "))
    parts = [th, STAGE]
    if scaled: parts.append(SCALED if re.search(r"\bseg\(", body) else SCALED.split("const seg")[0])
    if grain: parts.append(GRAIN)
    if hud: parts.append(HUD)
    parts.append(body.strip() + "\n")
    scene = "      <Scaled><Scene /></Scaled>\n" if scaled else "      <Scene />\n"
    layers = scene + ("      <Grain />\n" if grain else "") + (f"      <Hud label=\"{hud}\" />\n" if hud else "")
    parts.append("export const Video: React.FC = () => (\n  <Stage>\n" + layers + "  </Stage>\n);\n")
    code = "\n".join(parts)
    pats = {"AbsoluteFill": r"<AbsoluteFill", "Easing": r"\bEasing\.", "Sequence": r"<Sequence", "interpolate": r"\binterpolate\(",
            "random": r"[^.\w]random\(", "spring": r"\bspring\(", "useCurrentFrame": r"\buseCurrentFrame\(", "useVideoConfig": r"\buseVideoConfig\("}
    names = [n for n, pt in pats.items() if re.search(pt, code)]
    return f"import React from 'react';\nimport {{{', '.join(names)}}} from 'remotion';\n\n" + code

def fam(r, p, desc, plan, body, imports, W, H, fps, dur, hud=None, grain=True, scaled=True):
    return dict(desc=desc, plan=plan, video=video_file(imports, p, body, hud, grain, scaled), W=W, H=H, fps=fps, dur=dur)

def hudlabel(r, name, chance=.6):
    return f"{r.randint(1, 9):02d} — {name.upper()}" if r.random() < chance else None
