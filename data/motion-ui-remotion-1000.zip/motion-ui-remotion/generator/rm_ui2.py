import json, math
from rm_core import *

def g_palette(r, p):
    q, items = r.choice([("fram", ["Frame rate · 60fps", "Every frame is code", "Export as MP4", "Frame selection", "New project"]),
                         ("exp", ["Export as PNG", "Export as MP4", "Explore templates", "Open settings", "Share link"]),
                         ("new", ["New file", "New folder", "New window", "Open recent", "Save all"]),
                         ("them", ["Theme: Dark", "Theme: Light", "Change theme color", "Toggle sidebar", "Zoom in"])])
    sp = r.choice([3, 4, 5]); fps = 30; hold = 54; dur = (len(q) + 1) * sp + hold
    b = tsx("""const ITEMS = __ITEMS__;
const QUERY = __Q__;
const EVERY = __SP__; // frames per typed character
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const n = Math.min(QUERY.length, Math.floor(frame / EVERY));
  const typed = QUERY.slice(0, n);
  const matches = ITEMS.filter((i) => i.toLowerCase().includes(typed.toLowerCase()));
  const caretOn = Math.floor(frame / 15) % 2 === 0;
  return (
    <div style={{width: 400, borderRadius: 22, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 30px 80px ${C.sh}`, overflow: 'hidden'}}>
      <div style={{display: 'flex', gap: 12, alignItems: 'center', padding: '18px 20px', borderBottom: `1px solid ${C.line}`}}>
        <svg viewBox="0 0 24 24" width={18} height={18} fill="none" stroke={C.muted} strokeWidth={2} strokeLinecap="round"><circle cx="11" cy="11" r="7" /><path d="M20 20l-3.5-3.5" /></svg>
        <div style={{flex: 1, fontSize: 17, letterSpacing: '-0.01em'}}>{typed}</div>
        <div style={{width: 2, height: 20, background: C.accent, opacity: caretOn ? 1 : 0}} />
        <div style={{font: `600 11px ${MONO}`, padding: '4px 7px', borderRadius: 7, background: C.line, color: C.muted}}>⌘K</div>
      </div>
      <div style={{padding: 8, minHeight: 150}}>
        {matches.length === 0 && <div style={{padding: '12px 14px', fontSize: 14.5, color: C.muted}}>No results</div>}
        {matches.map((m, k) => {
          const appear = seg(frame - n * EVERY, 0, 10, Easing.out(Easing.cubic));
          return (
            <div key={m} style={{display: 'flex', alignItems: 'center', padding: '12px 14px', borderRadius: 13, fontSize: 14.5, background: k === 0 ? C.line : 'transparent', opacity: 0.4 + 0.6 * appear, transform: `translateY(${(1 - appear) * 6}px)`}}>
              {k === 0 && <div style={{width: 3, height: 16, borderRadius: 2, background: C.accent, marginRight: 10}} />}
              <span style={{flex: 1}}>{m}</span>
              {k === 0 && <div style={{font: `600 11px ${MONO}`, padding: '4px 7px', borderRadius: 7, background: C.line, color: C.muted}}>↵</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
};""", items=items, q=json.dumps(q), sp=sp)
    desc = r.choice([f"a ⌘K command palette that types '{q}' and live-filters results with a highlighted row, {p['desc']} theme",
                     "a Spotlight-style search box with auto-typing, keyboard hints and animated result rows",
                     f"a command menu with blinking caret, one character every {sp} frames, soft glass card and kbd chips"])
    plan = f"// PLAN: command palette; the query '{q}' is typed one character per {sp} frames, then holds ~{hold} frames; results are re-filtered from the typed prefix each frame, caret blinks every 15 frames; {dur} frames at {fps} fps."
    return fam(r, p, desc, plan, b, ["Easing"], 1080, 1080, fps, dur)

def g_button(r, p):
    a, bb, c = r.choice([("Generate", "Generating…", "Done"), ("Send", "Sending…", "Sent"), ("Deploy", "Deploying…", "Live"),
                         ("Save", "Saving…", "Saved"), ("Publish", "Publishing…", "Published")])
    ez_ = r.choice(list(EASE)); rad = r.choice([14, 22, 999]); fps = 30; dur = 165
    b = tsx("""const LABELS = ['__A__', '__B__', '__C__'];
// timeline (frames): idle → press 20 → loading 30-90 → success 90-135 → idle
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = __E__;
  const stage = frame < 30 ? 0 : frame < 90 ? 1 : frame < 135 ? 2 : 0;
  const swapAt = [30, 90, 135];
  const lastSwap = Math.max(...swapAt.filter((s) => frame >= s), -100);
  const sw = seg(frame - lastSwap, 0, 14, ease); // text blur-swap progress
  const press = frame >= 20 && frame < 32 ? 1 - 0.04 * Math.sin(((frame - 20) / 12) * Math.PI) : 1;
  const hover = frame < 20 ? seg(frame, 0, 20, ease) : 0.0;
  const shimmer = stage === 1 ? (((frame - 30) % 30) / 30) * 200 - 100 : -100;
  return (
    <div style={{position: 'relative', overflow: 'hidden', padding: '20px 46px', borderRadius: __R__, background: C.accent, color: C.on, fontSize: 20, fontWeight: 600, letterSpacing: '-0.02em', transform: `translateY(${-2 * hover}px) scale(${press * (1 + 0.03 * hover)})`, boxShadow: `0 1px 0 #ffffff33 inset, ${14 + 8 * hover}px ${14 + 8 * hover}px 36px ${C.sh2}`}}>
      {stage === 1 && <div style={{position: 'absolute', inset: 0, transform: `translateX(${shimmer}%)`, background: 'linear-gradient(100deg, transparent 30%, #ffffff44 50%, transparent 70%)'}} />}
      <span style={{display: 'inline-block', opacity: sw < 0.5 ? 1 - sw * 2 : sw * 2 - 1, filter: `blur(${(sw < 0.5 ? sw * 2 : 2 - sw * 2) * 4}px)`, transform: `translateY(${sw < 0.5 ? -10 * sw * 2 : 0}px)`}}>
        {LABELS[stage]}
      </span>
    </div>
  );
};""", a=a, b=bb, c=c, e=ez(ez_), r=rad)
    b = b.replace("opacity: sw < 0.5 ? 1 - sw * 2 : sw * 2 - 1,", "opacity: frame - lastSwap > 14 ? 1 : sw < 0.5 ? 1 - sw * 2 : sw * 2 - 1,")
    b = b.replace("filter: `blur(${(sw < 0.5 ? sw * 2 : 2 - sw * 2) * 4}px)`", "filter: `blur(${frame - lastSwap > 14 ? 0 : (sw < 0.5 ? sw * 2 : 2 - sw * 2) * 4}px)`")
    desc = r.choice([f"a '{a}' call-to-action button with idle, loading shimmer and success states, {p['desc']}",
                     f"a button that morphs {a} → {bb} → {c} with blur-swap text, {ez_} easing and press feedback",
                     f"an animated primary button ({rad}px radius) with hover lift, press squash and inner highlight"])
    plan = f"// PLAN: button state machine on a {dur}-frame timeline: idle→press (f20)→loading shimmer (f30-90)→success (f90-135)→idle, label blur-swaps over 14 frames with {ez_} easing."
    return fam(r, p, desc, plan, b, ["Easing"], 1080, 1080, fps, dur)

def g_ripple(r, p):
    label = r.choice(["Get started", "Try it free", "Continue", "Book a demo", "Download"]); rad = r.choice([16, 28, 999]); fps = 30; every = 51; dur = every * 3
    b = tsx("""const SPOTS = [[0.5, 0.5], [0.22, 0.4], [0.78, 0.65]]; // normalised click positions
const EVERY = __EV__;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const W = 280, H = 66;
  const idx = Math.floor(frame / EVERY);
  const local = frame - idx * EVERY;
  const ripples = [idx - 1, idx].filter((i) => i >= 0).map((i) => ({i, t: (frame - i * EVERY) / 27}));
  const press = local < 12 ? 1 - 0.04 * Math.sin((local / 12) * Math.PI) + 0.012 * Math.sin((local / 12) * Math.PI * 2) : 1;
  return (
    <div style={{position: 'relative', overflow: 'hidden', width: W, height: H, display: 'grid', placeItems: 'center', borderRadius: __R__, background: `linear-gradient(135deg, ${C.accent}, ${C.acc2})`, color: C.on, fontSize: 19, fontWeight: 700, letterSpacing: '-0.02em', boxShadow: `0 18px 44px ${C.sh2}`, transform: `scale(${press})`}}>
      {'__LABEL__'}
      {ripples.map(({i, t}) => {
        const [sx, sy] = SPOTS[i % SPOTS.length];
        const k = Easing.bezier(0.2, 0.7, 0.2, 1)(clamp01(t));
        const size = W;
        return <div key={i} style={{position: 'absolute', width: size, height: size, left: sx * W - size / 2, top: sy * H - size / 2, borderRadius: '50%', background: '#ffffff66', transform: `scale(${3.2 * k})`, opacity: 1 - k}} />;
      })}
    </div>
  );
};""", ev=every, r=rad, label=label)
    desc = r.choice([f"a gradient '{label}' button with a Material-style ripple and a springy press, {p['desc']}",
                     f"a CTA button that emits expanding ripples from the touch point, one every {every} frames",
                     f"a {rad}px-radius button with ripple feedback and squash-bounce on click"])
    plan = f"// PLAN: gradient CTA; three scripted tap points, a ripple every {every} frames scales to 3.2x with bezier(.2,.7,.2,1) while fading; the button squashes for 12 frames on each tap; loop {dur} frames at {fps} fps."
    return fam(r, p, desc, plan, b, ["Easing"], 1080, 1080, fps, dur)

def _path(pts):
    d = f"M{pts[0][0]:.1f},{pts[0][1]:.1f}"
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        mx = (x0 + x1) / 2; d += f" C{mx:.1f},{y0:.1f} {mx:.1f},{y1:.1f} {x1:.1f},{y1:.1f}"
    return d

def g_stats(r, p):
    label = r.choice(["total views", "active users", "revenue", "signups", "sessions"]); tabs = r.choice([["Day", "Week", "Month"], ["24h", "7d", "30d"]])
    n = r.choice([10, 12, 14]); ez_ = r.choice(list(EASE)); series, totals, paths = [], [], []
    for k in range(3):
        y, ys = r.uniform(.5, .8), []
        for _ in range(n): y = min(.95, max(.08, y - r.uniform(-.1, .14) * .6)); ys.append(round(y, 3))
        series.append(ys); totals.append(r.choice([1284, 12904, 84320, 2318, 56781, 140225]) * (k + 1))
        paths.append(_path([(i * 300 / (n - 1), 20 + (1 - v) * 110) for i, v in enumerate(ys)]))
    fps = 30; hold = 84; dur = hold * 3
    b = tsx("""const TABS = __TABS__;
const TOTALS = __TOT__;
const PATHS = __PATHS__;
const HOLD = __HOLD__;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = __E__;
  const i = Math.floor(frame / HOLD) % 3;
  const local = frame % HOLD;
  const slide = ease(seg(local, 0, 14, (x) => x));
  const prev = (i + 2) % 3;
  const pillX = (i === 0 && frame >= HOLD ? prev + (3 - prev) * slide : prev + (i - prev) * slide) % 3;
  const count = Math.round(TOTALS[i] * (1 - Math.pow(1 - seg(local, 0, 36, (x) => x), 4)));
  const draw = ease(seg(local, 0, 39, (x) => x));
  const area = seg(local, 15, 39, (x) => x);
  const colW = 64;
  return (
    <div style={{width: 380, padding: '24px 26px 26px', borderRadius: 28, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 30px 70px ${C.sh}`}}>
      <div style={{position: 'relative', display: 'flex', gap: 4, padding: 4, borderRadius: 99, background: C.line, width: 'max-content', margin: '0 auto 22px'}}>
        <div style={{position: 'absolute', top: 4, bottom: 4, left: 4, width: colW - 4, borderRadius: 99, background: C.accent, transform: `translateX(${pillX * colW}px)`}} />
        {TABS.map((t, k) => (
          <div key={t} style={{position: 'relative', zIndex: 1, width: colW - 4, textAlign: 'center', padding: '7px 0', fontSize: 12, fontWeight: 600, color: k === i ? C.on : C.muted}}>{t}</div>
        ))}
      </div>
      <div style={{fontSize: 56, fontWeight: 700, letterSpacing: '-0.04em', fontVariantNumeric: 'tabular-nums', lineHeight: 1}}>{count.toLocaleString('en-US')}</div>
      <div style={{fontSize: 13, color: C.muted, margin: '6px 0 14px'}}>__LABEL__</div>
      <svg viewBox="0 0 300 140" style={{width: '100%', overflow: 'visible'}}>
        <defs>
          <linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={C.accent} stopOpacity={0.28} /><stop offset="1" stopColor={C.accent} stopOpacity={0} /></linearGradient>
        </defs>
        <path d={PATHS[i] + ' L300,140 L0,140 Z'} fill="url(#g)" opacity={area} />
        <path d={PATHS[i]} pathLength={1} fill="none" stroke={C.accent} strokeWidth={2.5} strokeLinecap="round" strokeDasharray="1" strokeDashoffset={1 - draw} />
      </svg>
    </div>
  );
};""", tabs=tabs, tot=totals, paths=paths, hold=hold, e=ez(ez_), label=label)
    desc = r.choice([f"a stats card with {'/'.join(tabs)} tabs: switching redraws a smooth area chart and counts the {label} up",
                     f"an analytics widget ({p['desc']}): sliding tab pill, big tabular number, gradient sparkline that redraws per tab",
                     f"a dashboard KPI card with animated counter, gradient-filled trend line and auto-cycling tabs, {ez_} easing"])
    plan = f"// PLAN: KPI card cycling 3 tabs every {hold} frames; the pill slides, the counter eases up with a quartic-out over 36 frames, and the sparkline draws via strokeDashoffset (pathLength=1) while the area fades in; {dur} frames at {fps} fps."
    return fam(r, p, desc, plan, b, ["Easing", "interpolate"], 1080, 1080, fps, dur)

def g_toggles(r, p):
    rows = r.choice([["Wi-Fi", "Bluetooth", "Airplane mode"], ["Notifications", "Dark mode", "Auto-save", "Analytics"], ["Sync", "Offline", "Haptics"]]); ez_ = r.choice(["springy", "smooth", "snappy"])
    fps = 30; step = 33; dur = step * len(rows) * 2
    b = tsx("""const ROWS = __ROWS__;
const STEP = __STEP__; // a new switch flips every STEP frames
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = __E__;
  const n = ROWS.length;
  return (
    <div style={{width: 340, borderRadius: 24, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 28px 70px ${C.sh}`, padding: 8}}>
      {ROWS.map((label, i) => {
        // switch i flips at frame i*STEP (turn on) and again at (i+n)*STEP (turn off)
        const onAt = i * STEP, offAt = (i + n) * STEP;
        const flipOn = ease(seg(frame - onAt, 0, 18, (x) => x));
        const flipOff = ease(seg(frame - offAt, 0, 18, (x) => x));
        const t = frame < offAt ? flipOn : 1 - flipOff;
        const stretch = frame >= onAt && frame < onAt + 18 || frame >= offAt && frame < offAt + 18 ? 8 : 0;
        return (
          <div key={label} style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '16px 18px', fontWeight: 600, letterSpacing: '-0.01em', borderTop: i ? `1px solid ${C.line}` : 'none'}}>
            <span>{label}</span>
            <div style={{position: 'relative', width: 54, height: 32, borderRadius: 99, background: t > 0.5 ? C.accent : C.line}}>
              <div style={{position: 'absolute', top: 3, left: 3 + 22 * t - stretch * t, width: 26 + stretch, height: 26, borderRadius: 99, background: '#fff', boxShadow: '0 2px 6px #0004'}} />
            </div>
          </div>
        );
      })}
    </div>
  );
};""", rows=rows, step=step, e=ez(ez_))
    desc = r.choice([f"an iOS-style settings list with {len(rows)} toggle switches ({', '.join(rows)}) whose knob stretches on press, {ez_} easing",
                     f"animated switch toggles with a squash-stretch knob and sequential auto-demo, {p['desc']}",
                     f"a settings card: {', '.join(rows)} toggles with spring motion"])
    plan = f"// PLAN: settings card; switch i turns on at frame i*{step} and off {len(rows)*step} frames later, knob travel eased over 18 frames and stretched 8px while moving; {dur} frames at {fps} fps."
    return fam(r, p, desc, plan, b, ["Easing", "interpolate"], 1080, 1080, fps, dur)

def g_toast(r, p):
    msgs = r.choice([[("Payment received", "$248.00 from Acme Inc."), ("New comment", "Maya replied to your post"), ("Deploy finished", "main → production in 42s"), ("Reminder", "Standup starts in 5 min")],
                     [("Export complete", "reel_final.mp4 · 48 MB"), ("Render queued", "3 jobs ahead of you"), ("Sync done", "All changes saved"), ("Invite accepted", "Sam joined the project")],
                     [("Message sent", "Delivered to 4 people"), ("Upload finished", "12 files · 2.1 GB"), ("Low battery", "18% remaining"), ("Meeting soon", "Design review at 3:00")],
                     [("Order shipped", "Arrives Thursday"), ("New follower", "@motionlab followed you"), ("Backup complete", "Last run 2 min ago"), ("Update ready", "Version 4.2 is available")]])
    W = r.choice([320, 340, 380]); rad = r.choice([14, 20, 28]); gap = r.choice([14, 18, 22]); dur_s = r.choice([2.6, 3.6, 4.6]); ez_ = r.choice(["springy", "smooth", "snappy"]); every = r.choice([1.3, 1.5, 1.9])
    fps = 30; ev = round(every * fps); life = round(dur_s * fps); dur = ev * len(msgs) * 2
    b = tsx("""const MSGS = __M__;
const EVERY = __EV__, LIFE = __LIFE__, GAP = __GAP__;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = __E__;
  const newest = Math.floor(frame / EVERY);
  const stack = [0, 1, 2, 3].map((k) => newest - k).filter((i) => i >= 0);
  return (
    <div style={{position: 'relative', width: __W__, height: 230}}>
      {stack.map((i, k) => {
        const age = frame - i * EVERY;
        const enter = ease(seg(age, 0, 18, (x) => x));
        // slot position eases when a newer toast arrives
        const slot = k === 0 ? 0 : k - 1 + ease(seg(age - k * EVERY + EVERY, 0, 18, (x) => x)) * 0 + ease(seg((frame - (i + k) * EVERY), 0, 18, (x) => x));
        const depth = Math.min(3, slot);
        const m = MSGS[i % MSGS.length];
        const life = clamp01(1 - age / LIFE);
        return (
          <div key={i} style={{position: 'absolute', top: 0, left: 0, right: 0, zIndex: 10 - k, padding: '16px 18px 18px', borderRadius: __RAD__, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 20px 50px ${C.sh}`, overflow: 'hidden', transformOrigin: '50% 0', transform: `translateY(${depth * GAP - (1 - enter) * 34}px) scale(${(1 - depth * 0.05) * (0.96 + 0.04 * enter)})`, opacity: enter * (1 - Math.min(3, depth) * 0.28)}}>
            <div style={{fontSize: 15, fontWeight: 700, letterSpacing: '-0.01em'}}>{m[0]}</div>
            <div style={{fontSize: 13, color: C.muted}}>{m[1]}</div>
            <div style={{position: 'absolute', left: 0, bottom: 0, height: 3, width: '100%', background: C.accent, transformOrigin: 'left', transform: `scaleX(${life})`}} />
          </div>
        );
      })}
    </div>
  );
};""", m=msgs, ev=ev, life=life, gap=gap, e=ez(ez_), w=W, rad=rad)
    # simplify the slot expression (kept readable for the model)
    b = b.replace("const slot = k === 0 ? 0 : k - 1 + ease(seg(age - k * EVERY + EVERY, 0, 18, (x) => x)) * 0 + ease(seg((frame - (i + k) * EVERY), 0, 18, (x) => x));",
                  "const slot = k === 0 ? 0 : k - 1 + ease(seg(frame - newest * EVERY, 0, 18, (x) => x));")
    desc = r.choice([f"a stacked notification toast system ({W}px wide): new toasts slide in from the top while older ones scale down and fade, with a {dur_s}s countdown bar",
                     f"animated toast notifications ({p['desc']}) with depth stacking and a countdown line",
                     f"an iOS-like notification stack that cascades every {every}s"])
    plan = f"// PLAN: toast stack; a new toast every {ev} frames enters with {ez_} easing while older ones shift down {gap}px, scale by 5% per level and fade; each has a {life}-frame countdown bar; {dur} frames at {fps} fps."
    return fam(r, p, desc, plan, b, ["Easing", "interpolate"], 1080, 1080, fps, dur)
