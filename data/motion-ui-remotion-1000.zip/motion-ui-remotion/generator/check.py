"""Type-check generated Video.tsx/Root.tsx files in batches with tsc against stub typings."""
import os, shutil, subprocess, sys, json, collections
def check(items, tag="p"):
    """items: {key: files-dict}. returns {key: [errors]}"""
    d = f"tc/{tag}"; shutil.rmtree(d, ignore_errors=True)
    for k, files in items.items():
        for path, c in files.items():
            if path.startswith("src/"):
                fp = f"{d}/{k}/{path}"; os.makedirs(os.path.dirname(fp), exist_ok=True); open(fp, "w").write(c)
    ts = {"compilerOptions": {"target": "ES2020", "module": "ESNext", "moduleResolution": "bundler", "jsx": "react-jsx", "strict": True,
          "noEmit": True, "skipLibCheck": True, "esModuleInterop": True, "lib": ["DOM", "ES2020"], "types": [], "noUnusedLocals": True, "noUnusedParameters": False},
          "include": [f"{tag}/**/src/*.ts*"]}
    json.dump(ts, open(f"tc/tsconfig.{tag}.json", "w"))
    r = subprocess.run(["tsc", "-p", f"tsconfig.{tag}.json"], cwd="tc", capture_output=True, text=True)
    errs = collections.defaultdict(list)
    for line in (r.stdout + r.stderr).splitlines():
        if line.startswith(f"{tag}/"): errs[line.split("/")[1]].append(line[:240])
    shutil.rmtree(d, ignore_errors=True)
    return errs
