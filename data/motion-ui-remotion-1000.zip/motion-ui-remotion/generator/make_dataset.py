#!/usr/bin/env python3
"""
Polished prompt -> code dataset generator (v2).
32 scene families (UI micro-interactions, motion graphics, WebGL shaders), 12 palettes,
reel HUD overlay, film grain, soft lighting. Every sample = one self-contained HTML file.

  python make_dataset.py --n 1000 --seed 7 --out dataset --preview 32
"""
import argparse, hashlib, json, math, os, random, re

SYSTEM = ("You are an expert creative technologist and motion designer. Given a request, reply with one "
          "complete, self-contained HTML file (CSS + vanilla JS, or raw WebGL) that renders polished, "
          "minimal motion design with careful easing, depth and typography. Return only the code.")

# ------------------------------------------------------------------ color helpers
def hx(h): h = h.lstrip("#"); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))
def mix(a, b, t):
    A, B = hx(a), hx(b); return "#%02x%02x%02x" % tuple(round(A[i] + (B[i] - A[i]) * t) for i in range(3))
def lum(h): r, g, b = [v / 255 for v in hx(h)]; return .2126 * r + .7152 * g + .0722 * b
def v3(h): return "vec3(%.3f,%.3f,%.3f)" % tuple(v / 255 for v in hx(h))
def mk(name, bg, fg, acc, acc2, desc):
    dark = lum(bg) < .4
    return dict(name=name, bg=bg, fg=fg, accent=acc, acc2=acc2, dark=dark, desc=desc,
                bg2=mix(bg, fg, .10) if dark else mix(bg, "#ffffff", .65),
                muted=mix(fg, bg, .5), card=mix(bg, "#ffffff", .07) if dark else mix(bg, "#ffffff", .75),
                line=mix(fg, bg, .86), on="#0a0a0a" if lum(acc) > .5 else "#ffffff",
                sh="#00000066" if dark else "#0000001f", sh2="#00000099" if dark else "#00000033")

PALS = [
 mk("paper",   "#eeeeea", "#0a0a0a", "#0a0a0a", "#ff3b1f", "monochrome paper with a red spark"),
 mk("ink",     "#0b0b0c", "#f4f4f0", "#f4f4f0", "#ff3b1f", "ink black and off-white"),
 mk("signal",  "#0d0d0d", "#f5f5f0", "#ff3b1f", "#ffffff", "black with signal red"),
 mk("cream",   "#ece9e1", "#111111", "#e5341d", "#111111", "warm cream with a red accent"),
 mk("electric","#2b3cff", "#ffffff", "#ffffff", "#ffd23f", "electric blue and white"),
 mk("violet",  "#0f0b1f", "#f1edff", "#7c5cff", "#ff6adf", "deep violet with neon accents"),
 mk("mint",    "#eef6f2", "#0b1f19", "#12b886", "#0b1f19", "soft mint light"),
 mk("sunset",  "#140a0a", "#fff1e8", "#ff7a45", "#ffd166", "dark with sunset orange"),
 mk("acid",    "#0c0f08", "#eef5d8", "#c6ff3d", "#ffffff", "near-black with acid lime"),
 mk("ocean",   "#06121c", "#e6f3ff", "#38bdf8", "#a78bfa", "deep ocean blue with violet"),
 mk("rose",    "#fff1f0", "#2a0f12", "#ff4d6d", "#ffb703", "blush light with rose and amber"),
 mk("graphite","#16181d", "#e8eaf0", "#6ee7b7", "#60a5fa", "graphite with mint and sky"),
]
EASE = {"smooth": "cubic-bezier(.22,1,.36,1)", "snappy": "cubic-bezier(.16,1,.3,1)",
        "springy": "cubic-bezier(.34,1.56,.64,1)", "standard": "cubic-bezier(.4,0,.2,1)",
        "expo": "cubic-bezier(.7,0,.2,1)"}
GRADS = [("#ff9a44", "#ff4d6d", "#7b5cff"), ("#43e97b", "#38f9d7", "#2b6cff"),
         ("#fddb92", "#f093fb", "#5b8cff"), ("#ff6a88", "#ff99ac", "#ffd1a1"),
         ("#00c6ff", "#7b5cff", "#ff4d9d"), ("#f6d365", "#fda085", "#f857a6"),
         ("#84fab0", "#8fd3f4", "#a18cd1"), ("#fa709a", "#fee140", "#ff9a44")]
WORDS = ["FRAME", "MOTION", "DECISION", "REEL", "SIGNAL", "RHYTHM", "VELOCITY", "CRAFT", "FLOW", "PULSE",
         "BOLD", "SHIFT", "FOCUS", "DRIFT", "SPARK", "LAUNCH", "CLARITY", "BEYOND", "ORBIT", "KINETIC", "SCALE", "NOVA"]
OPEN = ["Create", "Build", "Write", "Code", "Design and code", "Make", "Generate", "Craft", "Produce"]
CONS = ["Single self-contained HTML file, no libraries.", "Use only CSS and vanilla JavaScript.",
        "No external dependencies.", "It should loop seamlessly.", "Respect prefers-reduced-motion.",
        "Keep the visual style minimal and premium.", "Use refined easing, no linear motion unless intended.",
        "Make it feel like a high-end product demo.", "Add subtle depth with soft shadows."]
CTX = ["for a SaaS landing page hero", "as a portfolio piece", "for a product launch video", "as a loading state in a mobile app",
       "for a creative-agency showreel", "for a design-system documentation page", "as a background for a title sequence", ""]

def fill(tpl, **kw):
    for k, v in kw.items(): tpl = tpl.replace(f"__{k.upper()}__", str(v))
    return tpl
def F(tpl, p, **kw): return fill(tpl, **{**p, **kw})

PAGE = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title>
<style>
*{box-sizing:border-box;margin:0}
html,body{height:100%}
body{display:grid;place-items:center;background:radial-gradient(110% 90% at 50% 35%,__BG2__,__BG__ 72%);color:__FG__;font-family:Inter,"SF Pro Display",system-ui,-apple-system,"Helvetica Neue",sans-serif;-webkit-font-smoothing:antialiased;overflow:hidden}
@media (prefers-reduced-motion:reduce){*{animation-duration:.001s!important;animation-iteration-count:1!important;transition-duration:.001s!important}}
__EXTRA__
__CSS__
</style></head><body>
__BODY__
__HUD__
<script>
__JS__
</script></body></html>"""

GRAIN = '''body::after{content:"";position:fixed;inset:0;pointer-events:none;opacity:.07;mix-blend-mode:overlay;z-index:9;background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>")}'''
HUD_CSS = """.hud{position:fixed;inset:20px;pointer-events:none;z-index:8;font:500 10px/1 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.14em;text-transform:uppercase;color:__FG__;opacity:.7}
.hud i{position:absolute;width:18px;height:18px;border:1.5px solid currentColor}
.hud .hx-tl{top:0;left:0;border-right:0;border-bottom:0}.hud .hx-tr{top:0;right:0;border-left:0;border-bottom:0}
.hud .hx-bl{bottom:0;left:0;border-right:0;border-top:0}.hud .hx-br{bottom:0;right:0;border-left:0;border-top:0}
.hud span{position:absolute;font:inherit;color:inherit;letter-spacing:inherit}.hud .hx-a{top:5px;left:28px}.hud .hx-b{top:5px;right:28px}.hud .hx-c{bottom:5px;left:28px}.hud .hx-d{bottom:5px;right:28px}"""

def page(title, p, css, body, js="", hud=None, grain=True):
    hud_html = ""
    if hud:
        hud_html = ('<div class="hud"><i class="hx-tl"></i><i class="hx-tr"></i><i class="hx-bl"></i><i class="hx-br"></i>'
                    f'<span class="hx-a">Claude / Motion Reel</span><span class="hx-b">1920×1080 · 60P · 120 BPM</span>'
                    f'<span class="hx-c" id="tc">TC 00:00:00:00</span><span class="hx-d">{hud}</span></div>')
        js += ("\n(function(){const tc=document.getElementById('tc');(function f(t){const s=t/1000;"
               "tc.textContent='TC 00:00:'+String(Math.floor(s)%60).padStart(2,'0')+':'+String(Math.floor(s%1*60)).padStart(2,'0');"
               "requestAnimationFrame(f)})(0)})();")
    extra = (GRAIN if grain else "") + (fill(HUD_CSS, fg=p["fg"]) if hud else "")
    return fill(PAGE, title=title, bg=p["bg"], bg2=p["bg2"], fg=p["fg"], extra=extra,
                css=css.strip(), body=body.strip(), hud=hud_html, js=js.strip())

def hudlabel(r, name, chance=.6):
    return f"{r.randint(1, 9):02d} — {name.upper()}" if r.random() < chance else None

# =================================================================== UI MICRO-INTERACTIONS
def g_spinner(r, p):
    kind = r.choice(["ring", "dots", "pulse", "bars", "orbit", "morph"]); S = r.choice([44, 56, 64, 80, 96])
    W = r.choice([4, 5, 6, 8]); T = r.choice([.8, 1, 1.2, 1.6]); ez = r.choice(list(EASE))
    if kind == "ring":
        css = F(".s{width:__S__px;height:__S__px;border-radius:50%;background:conic-gradient(from 0deg,#0000 0 18%,__ACCENT__);-webkit-mask:radial-gradient(farthest-side,#0000 calc(100% - __W__px),#000 calc(100% - __W__px + 1px));mask:radial-gradient(farthest-side,#0000 calc(100% - __W__px),#000 calc(100% - __W__px + 1px));animation:sp __T__s linear infinite}@keyframes sp{to{transform:rotate(1turn)}}", p, s=S, w=W, t=T)
        body = '<div class="s" role="status" aria-label="Loading"></div>'
    elif kind == "dots":
        css = F(".d{display:flex;gap:__G__px}.d i{width:__D__px;height:__D__px;border-radius:50%;background:__ACCENT__;animation:b __T__s __E__ infinite}.d i:nth-child(2){animation-delay:__D2__s}.d i:nth-child(3){animation-delay:__D3__s}@keyframes b{0%,100%{transform:translateY(0) scale(.8);opacity:.35}50%{transform:translateY(-__H__px) scale(1);opacity:1}}", p, g=S // 6, d=S // 4, t=T, e=EASE[ez], d2=f"{T/6:.2f}", d3=f"{T/3:.2f}", h=S // 3)
        body = '<div class="d" role="status" aria-label="Loading"><i></i><i></i><i></i></div>'
    elif kind == "pulse":
        css = F(".p{position:relative;width:__S__px;height:__S__px}.p::before,.p::after{content:'';position:absolute;inset:0;border-radius:50%;background:__ACCENT__;animation:pl __T__s __E__ infinite}.p::after{animation-delay:__H__s}@keyframes pl{0%{transform:scale(.2);opacity:.9}100%{transform:scale(1.15);opacity:0}}", p, s=S, t=T * 1.6, e=EASE[ez], h=f"{T*.8:.2f}")
        body = '<div class="p" role="status" aria-label="Loading"></div>'
    elif kind == "bars":
        delays = "".join(f".b i:nth-child({k+1}){{animation-delay:{k*T/9:.2f}s}}" for k in range(5))
        css = F(".b{display:flex;gap:__G__px;align-items:center;height:__S__px}.b i{width:__W__px;height:100%;border-radius:99px;background:__ACCENT__;animation:eq __T__s __E__ infinite}@keyframes eq{0%,100%{transform:scaleY(.25)}50%{transform:scaleY(1)}}", p, g=W, s=S, w=W + 2, t=T, e=EASE["standard"]) + delays
        body = '<div class="b" role="status" aria-label="Loading"><i></i><i></i><i></i><i></i><i></i></div>'
    elif kind == "orbit":
        D = W + 6
        css = F(".o{position:relative;width:__S__px;height:__S__px;animation:sp __T__s linear infinite}.o::before{content:'';position:absolute;inset:0;border-radius:50%;border:1px solid __LINE__}.o i{position:absolute;top:-__HD__px;left:50%;width:__D__px;height:__D__px;margin-left:-__HD__px;border-radius:50%;background:__ACCENT__;box-shadow:0 0 22px __ACCENT__}@keyframes sp{to{transform:rotate(1turn)}}", p, s=S, t=T * 1.4, d=D, hd=D // 2)
        body = '<div class="o" role="status" aria-label="Loading"><i></i></div>'
    else:
        css = F(".m{width:__S__px;height:__S__px;background:__ACCENT__;animation:mo __T__s __E__ infinite;box-shadow:0 14px 40px __SH__}@keyframes mo{0%{border-radius:50%;transform:rotate(0)}50%{border-radius:22%;transform:rotate(180deg) scale(.78)}100%{border-radius:50%;transform:rotate(360deg)}}", p, s=S, t=T * 1.8, e=EASE["expo"])
        body = '<div class="m" role="status" aria-label="Loading"></div>'
    desc = r.choice([f"a {kind} loading indicator, {S}px, {T}s cycle, {p['desc']} palette",
                     f"a minimal {kind}-style spinner with a {ez} feel on a {p['desc']} background",
                     f"a premium {kind} loader with soft depth, {p['desc']}"])
    return desc, page("Spinner", p, css, body)

def g_segmented(r, p):
    labels = r.choice([["Day", "Week", "Month"], ["Monthly", "Yearly"], ["List", "Grid", "Board"], ["Light", "Dark", "System"],
                       ["Overview", "Activity", "Settings", "Billing"], ["Design", "Code", "Preview"]])
    n = len(labels); ez = r.choice(list(EASE)); dur = r.choice([.3, .4, .5, .65]); style = r.choice(["pill", "underline"])
    if style == "pill":
        css = F(""".seg{position:relative;display:grid;grid-template-columns:repeat(__N__,1fr);padding:6px;border-radius:999px;background:__CARD__;box-shadow:0 1px 0 __LINE__ inset,0 14px 40px __SH__;width:__W__px}
.seg button{all:unset;position:relative;z-index:1;text-align:center;padding:12px 0;font-weight:600;font-size:15px;letter-spacing:-.01em;color:__MUTED__;cursor:pointer;transition:color __D__s}
.seg button[aria-selected=true]{color:__ON__}
.pill{position:absolute;top:6px;bottom:6px;left:6px;width:calc((100% - 12px)/__N__);border-radius:999px;background:__ACCENT__;box-shadow:0 6px 18px __SH2__;transition:transform __D__s __E__}""", p, n=n, w=n * 112, d=dur, e=EASE[ez])
        btns = "".join(f'<button role="tab" aria-selected="false">{l}</button>' for l in labels)
        body = f'<div class="seg" role="tablist"><span class="pill"></span>{btns}</div>'
        js = fill("""const tabs=[...document.querySelectorAll('.seg button')],pill=document.querySelector('.pill');
function sel(i){tabs.forEach((t,j)=>t.setAttribute('aria-selected',j===i));pill.style.transform=`translateX(${i*100}%)`}
tabs.forEach((t,i)=>t.onclick=()=>{k=i;sel(i)});
let k=0;sel(0);setInterval(()=>sel(k=(k+1)%__N__),1900);""", n=n)
    else:
        css = F(""".seg{position:relative;display:flex;gap:30px;border-bottom:1px solid __LINE__}
.seg button{all:unset;padding:14px 2px;font-weight:600;font-size:16px;letter-spacing:-.01em;color:__MUTED__;cursor:pointer;transition:color __D__s}
.seg button[aria-selected=true]{color:__FG__}
.ul{position:absolute;bottom:-1px;left:0;height:2px;width:10px;border-radius:2px;background:__ACCENT__;transition:transform __D__s __E__,width __D__s __E__}""", p, d=dur, e=EASE[ez])
        btns = "".join(f'<button role="tab" aria-selected="false">{l}</button>' for l in labels)
        body = f'<div class="seg" role="tablist">{btns}<span class="ul"></span></div>'
        js = fill("""const tabs=[...document.querySelectorAll('.seg button')],ul=document.querySelector('.ul');
function sel(i){tabs.forEach((t,j)=>t.setAttribute('aria-selected',j===i));ul.style.width=tabs[i].offsetWidth+'px';ul.style.transform=`translateX(${tabs[i].offsetLeft}px)`}
tabs.forEach((t,i)=>t.onclick=()=>{k=i;sel(i)});
let k=0;sel(0);setInterval(()=>sel(k=(k+1)%__N__),1900);""", n=n)
    desc = r.choice([f"a {style} segmented control with options {', '.join(labels)} ({ez} easing, {dur}s)",
                     f"an animated tab switcher ({' / '.join(labels)}) with a gliding {'pill' if style=='pill' else 'underline'}, {p['desc']} theme",
                     f"a {style}-style tab bar: {', '.join(labels)}; auto-cycles and is clickable"])
    return desc, page("Segmented control", p, css, body, js)

def g_slider(r, p):
    label = r.choice(["Volume", "Brightness", "Speed", "Intensity"]); h = r.choice([8, 10, 14]); ez = r.choice(list(EASE))
    css = F(""".s{display:flex;align-items:center;gap:16px;padding:16px 22px;border-radius:999px;background:__CARD__;box-shadow:0 1px 0 __LINE__ inset,0 18px 50px __SH__;width:360px}
svg{width:20px;height:20px;fill:__FG__;flex:none}
.t{position:relative;flex:1;height:__H__px;border-radius:99px;background:__LINE__;cursor:pointer;touch-action:none;transition:height .35s __E__}
.t:hover,.t.on{height:__H2__px}
.f{height:100%;width:calc(var(--v,.6)*100%);border-radius:inherit;background:linear-gradient(90deg,__ACCENT__,__ACC2__);box-shadow:0 0 18px __ACCENT__66}
.th{position:absolute;top:50%;left:calc(var(--v,.6)*100%);width:20px;height:20px;margin:-10px 0 0 -10px;border-radius:50%;background:__FG__;box-shadow:0 3px 10px __SH2__;transform:scale(0);transition:transform .3s __E__}
.t:hover .th,.t.on .th{transform:scale(1)}
.v{font:600 13px ui-monospace,monospace;width:30px;text-align:right;color:__MUTED__}""", p, h=h, h2=h + 6, e=EASE[ez])
    body = f'<div class="s"><svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 4V5L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 8v8a4.5 4.5 0 0 0 2.5-4z"/></svg><div class="t" id="t" aria-label="{label}"><div class="f"></div><div class="th"></div></div><span class="v" id="v">60</span></div>'
    js = """const t=document.getElementById('t'),v=document.getElementById('v');
let val=.6,drag=false,auto=true;
function set(x){val=Math.min(1,Math.max(0,x));t.style.setProperty('--v',val);v.textContent=Math.round(val*100)}
function pos(e){const b=t.getBoundingClientRect();set((e.clientX-b.left)/b.width)}
t.addEventListener('pointerdown',e=>{drag=true;auto=false;t.classList.add('on');t.setPointerCapture(e.pointerId);pos(e)});
t.addEventListener('pointermove',e=>drag&&pos(e));
t.addEventListener('pointerup',()=>{drag=false;t.classList.remove('on')});
const s=performance.now();(function loop(n){if(auto){set(.5+.4*Math.sin((n-s)/1000));t.classList.toggle('on',Math.sin((n-s)/1000)>.2)}requestAnimationFrame(loop)})(s);"""
    desc = r.choice([f"a draggable {label.lower()} slider pill with a gradient fill and a thumb that appears on hover, {p['desc']}",
                     f"an interactive {label.lower()} control: glassy pill, speaker icon, live readout, auto-animates until touched",
                     f"a {h}px-track {label.lower()} slider with pointer-drag support and a {ez} height transition"])
    return desc, page("Slider", p, css, body, js)

def g_player(r, p):
    g = r.choice(GRADS); title = r.choice(["motion study 02", "midnight loop", "kinetic sketch", "slow signal", "frame by frame", "blue hour"])
    sub = r.choice(["made in code", "generative", "ambient · 2:40", "live session", "demo reel"]); total = r.choice([150, 180, 200, 240])
    css = F(""".c{width:350px;padding:18px;border-radius:30px;background:__CARD__;box-shadow:0 1px 0 __LINE__ inset,0 30px 70px __SH__}
.top{display:flex;gap:14px;align-items:center}
.art{width:68px;height:68px;border-radius:18px;background:linear-gradient(135deg,__G1__,__G2__,__G3__);background-size:220% 220%;animation:sh 7s ease-in-out infinite;box-shadow:0 10px 24px __G2__66}
@keyframes sh{50%{background-position:100% 100%}}
.t b{display:block;font-size:16px;letter-spacing:-.02em}.t span{font-size:13px;color:__MUTED__}
.bar{margin:20px 0 8px;height:5px;border-radius:9px;background:__LINE__;cursor:pointer;position:relative}
.bar i{display:block;height:100%;border-radius:inherit;background:__ACCENT__;position:relative}
.bar i::after{content:'';position:absolute;right:-6px;top:50%;width:12px;height:12px;margin-top:-6px;border-radius:50%;background:__ACCENT__;box-shadow:0 2px 8px __SH2__}
.tm{display:flex;justify-content:space-between;font:11px ui-monospace,monospace;color:__MUTED__}
.ct{display:flex;justify-content:center;align-items:center;gap:32px;margin-top:14px}
.ct button{all:unset;cursor:pointer;display:grid;place-items:center;transition:transform .25s __E__}.ct button:active{transform:scale(.86)}
svg{width:22px;height:22px;fill:__FG__}""", p, g1=g[0], g2=g[1], g3=g[2], e=EASE["springy"])
    body = f"""<div class="c"><div class="top"><div class="art"></div><div class="t"><b>{title}</b><span>{sub}</span></div></div>
<div class="bar" id="bar"><i id="fill"></i></div><div class="tm"><span id="cur">0:00</span><span id="rem">-0:00</span></div>
<div class="ct"><button aria-label="Previous"><svg viewBox="0 0 24 24"><path d="M6 5h2v14H6zM20 5v14L9 12z"/></svg></button>
<button id="pp" aria-label="Play/Pause"><svg viewBox="0 0 24 24" style="width:32px;height:32px"><path id="ic" d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg></button>
<button aria-label="Next"><svg viewBox="0 0 24 24"><path d="M16 5h2v14h-2zM4 5v14l11-7z"/></svg></button></div></div>"""
    js = fill("""const T=__T__,fill=document.getElementById('fill'),cur=document.getElementById('cur'),rem=document.getElementById('rem'),ic=document.getElementById('ic');
let pos=T*.3,playing=true,last=performance.now();
const f=s=>Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');
document.getElementById('pp').onclick=()=>{playing=!playing;ic.setAttribute('d',playing?'M6 5h4v14H6zM14 5h4v14h-4z':'M7 4v16l13-8z')};
document.getElementById('bar').onclick=e=>{const b=e.currentTarget.getBoundingClientRect();pos=T*(e.clientX-b.left)/b.width};
(function tick(n){const dt=(n-last)/1000;last=n;if(playing)pos=(pos+dt)%T;fill.style.width=pos/T*100+'%';cur.textContent=f(pos);rem.textContent='-'+f(T-pos);requestAnimationFrame(tick)})(last);""", t=total)
    desc = r.choice([f"a compact music player card titled '{title}' with animated gradient art, scrubber, time labels and play/pause",
                     f"a now-playing widget ({p['desc']}) with a click-to-seek progress bar and springy transport buttons",
                     f"a media player UI card, {total}s track, soft shadows and a clean typographic hierarchy"])
    return desc, page("Player", p, css, body, js)

def g_palette(r, p):
    q, items = r.choice([("fram", ["Frame rate · 60fps", "Every frame is code", "Export as MP4", "Frame selection", "New project"]),
                         ("exp", ["Export as PNG", "Export as MP4", "Explore templates", "Open settings", "Share link"]),
                         ("new", ["New file", "New folder", "New window", "Open recent", "Save all"]),
                         ("them", ["Theme: Dark", "Theme: Light", "Change theme color", "Toggle sidebar", "Zoom in"])])
    sp = r.choice([90, 120, 160])
    css = F(""".w{width:400px;border-radius:22px;background:__CARD__;box-shadow:0 1px 0 __LINE__ inset,0 30px 80px __SH__;overflow:hidden}
.in{display:flex;gap:12px;align-items:center;padding:18px 20px;border-bottom:1px solid __LINE__}
.in svg{width:18px;height:18px;stroke:__MUTED__;fill:none;stroke-width:2;stroke-linecap:round}
.in input{all:unset;flex:1;font-size:17px;letter-spacing:-.01em}
.caret{width:2px;height:20px;background:__ACCENT__;animation:bl 1s steps(1) infinite}@keyframes bl{50%{opacity:0}}
kbd{font:600 11px ui-monospace,monospace;padding:4px 7px;border-radius:7px;background:__LINE__;color:__MUTED__}
ul{list-style:none;padding:8px;min-height:150px}
li{display:flex;justify-content:space-between;align-items:center;padding:12px 14px;border-radius:13px;font-size:14.5px;animation:in .4s __E__ both}
li.on{background:__LINE__}li.on::before{content:'';width:3px;height:16px;border-radius:2px;background:__ACCENT__;margin-right:10px}li span{flex:1}
li.empty{color:__MUTED__}@keyframes in{from{opacity:0;transform:translateY(8px)}}""", p, e=EASE["smooth"])
    body = '<div class="w"><div class="in"><svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg><input id="q" readonly><span class="caret"></span><kbd>⌘K</kbd></div><ul id="l"></ul></div>'
    js = fill("""const items=__ITEMS__,q=__Q__,inp=document.getElementById('q'),list=document.getElementById('l');
function render(s){const m=items.filter(i=>i.toLowerCase().includes(s.toLowerCase()));list.innerHTML=m.map((i,k)=>`<li class="${k?'':'on'}"><span>${i}</span>${k?'':'<kbd>↵</kbd>'}</li>`).join('')||'<li class="empty">No results</li>'}
let n=0;(function type(){inp.value=q.slice(0,n);render(q.slice(0,n));n=n>=q.length?0:n+1;setTimeout(type,n===0?1800:__SP__)})();""", items=json.dumps(items), q=json.dumps(q), sp=sp)
    desc = r.choice([f"a ⌘K command palette that types '{q}' and live-filters results with a highlighted row, {p['desc']} theme",
                     f"a Spotlight-style search box with auto-typing, keyboard hints and animated result rows",
                     f"a command menu with blinking caret, typing every {sp}ms, soft glass card and kbd chips"])
    return desc, page("Command palette", p, css, body, js)

def g_button(r, p):
    a, b, c = r.choice([("Generate", "Generating…", "Done"), ("Send", "Sending…", "Sent"), ("Deploy", "Deploying…", "Live"),
                        ("Save", "Saving…", "Saved"), ("Publish", "Publishing…", "Published")])
    ez = r.choice(list(EASE)); rad = r.choice([14, 22, 999])
    css = F(""".b{all:unset;cursor:pointer;position:relative;overflow:hidden;padding:20px 46px;border-radius:__R__px;background:__ACCENT__;color:__ON__;font-size:20px;font-weight:600;letter-spacing:-.02em;transition:transform .4s __E__,box-shadow .4s __E__;box-shadow:0 1px 0 #ffffff33 inset,0 14px 36px __SH2__}
.b:hover{transform:translateY(-2px) scale(1.03);box-shadow:0 1px 0 #ffffff33 inset,0 22px 50px __SH2__}.b:active{transform:scale(.96)}
.b.load::after{content:'';position:absolute;inset:0;background:linear-gradient(100deg,transparent 30%,#ffffff44 50%,transparent 70%);animation:sw 1s linear infinite}
@keyframes sw{from{transform:translateX(-100%)}to{transform:translateX(100%)}}
.b span{display:inline-block;transition:transform .4s __E__,opacity .25s,filter .25s}.b span.out{transform:translateY(-10px);opacity:0;filter:blur(4px)}""", p, r=rad, e=EASE[ez])
    body = f'<button class="b" id="b"><span id="s">{a}</span></button>'
    js = fill("""const b=document.getElementById('b'),s=document.getElementById('s'),L=['__A__','__B__','__C__'];let busy=false;
const to=(t,c)=>new Promise(res=>{s.classList.add('out');setTimeout(()=>{s.textContent=t;s.classList.remove('out');b.classList.toggle('load',c);res()},220)});
async function run(){if(busy)return;busy=true;await to(L[1],true);await new Promise(r=>setTimeout(r,1400));await to(L[2],false);await new Promise(r=>setTimeout(r,1200));await to(L[0],false);busy=false}
b.onclick=run;setInterval(run,5400);setTimeout(run,800);""", a=a, b=b, c=c)
    desc = r.choice([f"a '{a}' call-to-action button with idle, loading shimmer and success states, {p['desc']}",
                     f"a button that morphs {a} → {b} → {c} with blur-swap text, {ez} easing and press feedback",
                     f"an animated primary button ({rad}px radius) with hover lift, active squash and inner highlight"])
    return desc, page("Button", p, css, body, js)

def g_ripple(r, p):
    label = r.choice(["Get started", "Try it free", "Continue", "Book a demo", "Download"]); rad = r.choice([16, 28, 999])
    css = F(""".b{all:unset;cursor:pointer;position:relative;overflow:hidden;padding:20px 48px;border-radius:__R__px;background:linear-gradient(135deg,__ACCENT__,__ACC2__);color:__ON__;font-size:19px;font-weight:700;letter-spacing:-.02em;box-shadow:0 18px 44px __SH2__}
.rp{position:absolute;border-radius:50%;background:#ffffff66;transform:scale(0);animation:rp .9s cubic-bezier(.2,.7,.2,1) forwards;pointer-events:none}
@keyframes rp{to{transform:scale(3.2);opacity:0}}""", p, r=rad)
    body = f'<button class="b" id="b">{label}</button>'
    js = """const b=document.getElementById('b');
function ripple(x,y){const d=document.createElement('span'),s=Math.max(b.offsetWidth,b.offsetHeight);d.className='rp';d.style.cssText=`width:${s}px;height:${s}px;left:${x-s/2}px;top:${y-s/2}px`;b.appendChild(d);setTimeout(()=>d.remove(),900);
b.animate([{transform:'scale(1)'},{transform:'scale(.96)'},{transform:'scale(1)'}],{duration:380,easing:'cubic-bezier(.34,1.56,.64,1)'})}
b.addEventListener('click',e=>{const r=b.getBoundingClientRect();ripple(e.clientX-r.left,e.clientY-r.top)});
setInterval(()=>ripple(Math.random()*b.offsetWidth,Math.random()*b.offsetHeight),1700);setTimeout(()=>ripple(b.offsetWidth/2,b.offsetHeight/2),400);"""
    desc = r.choice([f"a gradient '{label}' button with a Material-style ripple and a springy press, {p['desc']}",
                     f"a CTA button that emits expanding ripples from the touch point (auto-demo every 1.7s)",
                     f"a {rad}px-radius button with ripple feedback and squash-bounce on click"])
    return desc, page("Ripple button", p, css, body, js)

def _smooth(pts):
    d = f"M{pts[0][0]:.1f},{pts[0][1]:.1f}"
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        mx = (x0 + x1) / 2; d += f" C{mx:.1f},{y0:.1f} {mx:.1f},{y1:.1f} {x1:.1f},{y1:.1f}"
    return d

def g_stats(r, p):
    label = r.choice(["total views", "active users", "revenue", "signups", "sessions"]); tabs = r.choice([["Day", "Week", "Month"], ["24h", "7d", "30d"]])
    n = r.choice([10, 12, 14]); ez = r.choice(list(EASE)); series, totals = [], []
    for k in range(3):
        y, ys = r.uniform(.5, .8), []
        for _ in range(n): y = min(.95, max(.08, y - r.uniform(-.1, .14) * .6)); ys.append(round(y, 3))
        series.append(ys); totals.append(r.choice([1284, 12904, 84320, 2318, 56781, 140225]) * (k + 1))
    css = F(""".c{width:380px;padding:24px 26px 26px;border-radius:28px;background:__CARD__;box-shadow:0 1px 0 __LINE__ inset,0 30px 70px __SH__}
.tb{display:flex;gap:4px;padding:4px;border-radius:99px;background:__LINE__;width:max-content;margin:0 auto 22px;position:relative}
.tb button{all:unset;position:relative;z-index:1;padding:7px 16px;font-size:12px;font-weight:600;color:__MUTED__;cursor:pointer;transition:color .3s}
.tb button.on{color:__ON__}.pl{position:absolute;top:4px;bottom:4px;left:4px;border-radius:99px;background:__ACCENT__;transition:transform .5s __E__,width .5s __E__}
.n{font-size:56px;font-weight:700;letter-spacing:-.04em;font-variant-numeric:tabular-nums;line-height:1}.k{font-size:13px;color:__MUTED__;margin:6px 0 14px}
svg{width:100%;height:auto;overflow:visible}
.ln{fill:none;stroke:__ACCENT__;stroke-width:2.5;stroke-linecap:round;stroke-dasharray:1;stroke-dashoffset:1}
.ln.go{animation:dr 1.3s __E__ forwards}.ar{fill:url(#g);opacity:0;transition:opacity .8s .5s}.ar.go{opacity:1}
@keyframes dr{to{stroke-dashoffset:0}}""", p, e=EASE[ez])
    btn = "".join(f'<button>{t}</button>' for t in tabs)
    body = f"""<div class="c"><div class="tb"><span class="pl"></span>{btn}</div><div class="n" id="n">0</div><div class="k">{label}</div>
<svg viewBox="0 0 300 140"><defs><linearGradient id="g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="{p['accent']}" stop-opacity=".28"/><stop offset="1" stop-color="{p['accent']}" stop-opacity="0"/></linearGradient></defs>
<path class="ar" id="ar"/><path class="ln" id="ln" pathLength="1"/></svg></div>"""
    js = fill("""const S=__S__,TOT=__TOT__,n=document.getElementById('n'),ln=document.getElementById('ln'),ar=document.getElementById('ar'),bs=[...document.querySelectorAll('.tb button')],pl=document.querySelector('.pl');let cur=0,raf;
function path(v){const pts=v.map((y,i)=>[i*300/(v.length-1),20+(1-y)*110]);let d=`M${pts[0][0]},${pts[0][1]}`;for(let i=1;i<pts.length;i++){const mx=(pts[i-1][0]+pts[i][0])/2;d+=` C${mx},${pts[i-1][1]} ${mx},${pts[i][1]} ${pts[i][0]},${pts[i][1]}`}return d}
function show(i){cur=i;bs.forEach((b,j)=>b.classList.toggle('on',j===i));pl.style.width=bs[i].offsetWidth+'px';pl.style.transform=`translateX(${bs[i].offsetLeft-4}px)`;
const d=path(S[i]);ln.setAttribute('d',d);ar.setAttribute('d',d+' L300,140 L0,140 Z');ln.classList.remove('go');ar.classList.remove('go');void ln.getBoundingClientRect();ln.classList.add('go');ar.classList.add('go');
cancelAnimationFrame(raf);const s=performance.now();(function f(t){const k=Math.min(1,(t-s)/1200),e=1-Math.pow(1-k,4);n.textContent=Math.round(TOT[i]*e).toLocaleString();if(k<1)raf=requestAnimationFrame(f)})(s)}
bs.forEach((b,i)=>b.onclick=()=>show(i));show(0);setInterval(()=>show((cur+1)%3),2800);""", s=json.dumps(series), tot=json.dumps(totals))
    desc = r.choice([f"a stats card with {'/'.join(tabs)} tabs: switching redraws a smooth area chart and counts the {label} up",
                     f"an analytics widget ({p['desc']}): sliding tab pill, big tabular number, gradient sparkline that redraws per tab",
                     f"a dashboard KPI card with animated counter, gradient-filled trend line and auto-cycling tabs, {ez} easing"])
    return desc, page("Stats card", p, css, body, js)

def g_toggles(r, p):
    rows = r.choice([["Wi-Fi", "Bluetooth", "Airplane mode"], ["Notifications", "Dark mode", "Auto-save", "Analytics"], ["Sync", "Offline", "Haptics"]]); ez = r.choice(["springy", "smooth", "snappy"])
    css = F(""".l{width:340px;border-radius:24px;background:__CARD__;box-shadow:0 1px 0 __LINE__ inset,0 28px 70px __SH__;padding:8px}
.r{display:flex;justify-content:space-between;align-items:center;padding:16px 18px;font-weight:600;letter-spacing:-.01em}.r+.r{border-top:1px solid __LINE__}
.sw{position:relative;width:54px;height:32px;border-radius:99px;background:__LINE__;transition:background .4s __E__;cursor:pointer}
.sw::after{content:'';position:absolute;top:3px;left:3px;width:26px;height:26px;border-radius:99px;background:#fff;box-shadow:0 2px 6px #0004;transition:transform .5s __E__,width .25s}
.sw.on{background:__ACCENT__}.sw.on::after{transform:translateX(22px)}.sw.p::after{width:34px}.sw.on.p::after{transform:translateX(14px)}""", p, e=EASE[ez])
    body = '<div class="l">' + "".join(f'<div class="r"><span>{x}</span><div class="sw"></div></div>' for x in rows) + '</div>'
    js = """const sw=[...document.querySelectorAll('.sw')];sw.forEach(s=>{s.onclick=()=>tog(s)});
function tog(s){s.classList.add('p');setTimeout(()=>{s.classList.toggle('on');s.classList.remove('p')},140)}
let i=0;setInterval(()=>tog(sw[i++%sw.length]),1100);"""
    desc = r.choice([f"an iOS-style settings list with {len(rows)} toggle switches ({', '.join(rows)}) whose knob stretches on press, {ez} easing",
                     f"animated switch toggles with a squash-stretch knob and sequential auto-demo, {p['desc']}",
                     f"a settings card: {', '.join(rows)} toggles with spring motion"])
    return desc, page("Toggles", p, css, body, js)

def g_toast(r, p):
    msgs = r.choice([[("Payment received", "$248.00 from Acme Inc."), ("New comment", "Maya replied to your post"), ("Deploy finished", "main → production in 42s"), ("Reminder", "Standup starts in 5 min")],
                     [("Export complete", "reel_final.mp4 · 48 MB"), ("Render queued", "3 jobs ahead of you"), ("Sync done", "All changes saved"), ("Invite accepted", "Sam joined the project")],
                     [("Message sent", "Delivered to 4 people"), ("Upload finished", "12 files · 2.1 GB"), ("Low battery", "18% remaining"), ("Meeting soon", "Design review at 3:00")],
                     [("Order shipped", "Arrives Thursday"), ("New follower", "@motionlab followed you"), ("Backup complete", "Last run 2 min ago"), ("Update ready", "Version 4.2 is available")]])
    W = r.choice([320, 340, 380]); rad = r.choice([14, 20, 28]); gap = r.choice([14, 18, 22]); dur = r.choice([2.6, 3.6, 4.6]); ez = r.choice(["springy", "smooth", "snappy"]); every = r.choice([1.3, 1.5, 1.9])
    css = F(""".b{position:relative;width:__W__px;height:230px}
.t{position:absolute;top:0;left:0;right:0;padding:16px 18px 18px;border-radius:__RAD__px;background:__CARD__;box-shadow:0 1px 0 __LINE__ inset,0 20px 50px __SH__;overflow:hidden;
transform:translateY(calc(var(--k,0)*__GAP__px)) scale(calc(1 - var(--k,0)*.05));opacity:calc(1 - var(--k,0)*.28);transition:transform .6s __E__,opacity .6s;transform-origin:50% 0}
.t:not(.in){transform:translateY(-34px) scale(.96);opacity:0}.t.out{opacity:0}
.t b{display:block;font-size:15px;letter-spacing:-.01em}.t span{font-size:13px;color:__MUTED__}
.t u{position:absolute;left:0;bottom:0;height:3px;width:100%;background:__ACCENT__;transform-origin:left;animation:pg __DUR__s linear forwards}@keyframes pg{to{transform:scaleX(0)}}""", p, e=EASE[ez], w=W, rad=rad, gap=gap, dur=dur)
    body = '<div class="b" id="b"></div>'
    js = fill("""const box=document.getElementById('b'),M=__M__;let i=0;
function add(){const e=document.createElement('div');e.className='t';const m=M[i++%M.length];e.innerHTML=`<b>${m[0]}</b><span>${m[1]}</span><u></u>`;box.prepend(e);requestAnimationFrame(()=>e.classList.add('in'));
[...box.children].forEach((c,k)=>{c.style.setProperty('--k',k);c.style.zIndex=10-k});
while(box.children.length>4){const o=box.lastElementChild;o.remove()}}
add();setInterval(add,__EV__);""", m=json.dumps(msgs), ev=int(every * 1000))
    desc = r.choice([f"a stacked notification toast system ({W}px wide): new toasts slide in from the top while older ones scale down and fade, with a {dur}s countdown bar",
                     f"animated toast notifications ({p['desc']}) with depth stacking and a countdown line",
                     "an iOS-like notification stack that cascades every 1.5s"])
    return desc, page("Toasts", p, css, body, js)

def g_dock(r, p):
    n = r.choice([5, 6, 7]); S = 54; gap = 12; mx = r.choice([.7, .9, 1.1]); gl = list("ABCDEFG")[:n]; gs = [GRADS[(i + r.randint(0, 3)) % len(GRADS)] for i in range(n)]
    css = F(""".d{display:flex;gap:__GAP__px;align-items:flex-end;padding:10px 14px;height:__DH__px;border-radius:28px;background:__CARD__;box-shadow:0 1px 0 __LINE__ inset,0 30px 70px __SH__}
.i{width:__S__px;height:__S__px;border-radius:24%;display:grid;place-items:center;font-weight:800;color:#fff;text-shadow:0 1px 3px #0005;box-shadow:0 8px 18px #0003,0 1px 0 #ffffff55 inset}""", p, gap=gap, dh=int(S * (1 + mx) + 20), s=S)
    items = "".join(f'<div class="i" style="background:linear-gradient(135deg,{g[0]},{g[1]},{g[2]})">{l}</div>' for l, g in zip(gl, gs))
    body = f'<div class="d" id="d">{items}</div>'
    js = fill("""const d=document.getElementById('d'),it=[...d.children],S=__S__,G=__GAP__,M=__M__,R=70;
(function f(t){const W=it.length*(S+G)-G,px=W/2+Math.sin(t/900)*W*.62;
it.forEach((el,i)=>{const cx=i*(S+G)+S/2,s=1+M*Math.exp(-Math.pow((cx-px)/R,2));const z=S*s;el.style.width=el.style.height=z+'px';el.style.fontSize=(18*s)+'px'});requestAnimationFrame(f)})(0);""", s=S, gap=gap, m=mx)
    desc = r.choice([f"a macOS-style dock with {n} icons that magnify smoothly as a simulated cursor sweeps across (max scale {1+mx:.1f}x)",
                     f"dock magnification effect with gaussian falloff and glass shelf, {p['desc']}",
                     f"an animated app dock: {n} gradient icons growing around a moving pointer"])
    return desc, page("Dock", p, css, body, js)

def g_ring(r, p):
    S = r.choice([140, 170, 200]); W = r.choice([8, 10, 12]); T = r.choice([2.2, 2.8, 3.4]); ez = r.choice(list(EASE))
    css = F(""".w{position:relative;width:__S__px;height:__S__px}svg{width:100%;height:100%;transform:rotate(-90deg);overflow:visible}
circle{fill:none;stroke-width:__W__;stroke-linecap:round}.bg{stroke:__LINE__}.fg{stroke:url(#g);stroke-dasharray:289;stroke-dashoffset:289;filter:drop-shadow(0 0 10px __ACCENT__66)}
.n{position:absolute;inset:0;display:grid;place-items:center;font-size:__FS__px;font-weight:700;letter-spacing:-.04em;font-variant-numeric:tabular-nums;transition:opacity .3s,transform .5s __E__}
.ck{position:absolute;inset:0;display:grid;place-items:center;opacity:0;transform:scale(.4);transition:opacity .3s,transform .6s __E__}.ck svg{width:42%;height:42%;transform:none;fill:none;stroke:__ACCENT__;stroke-width:5;stroke-linecap:round;stroke-linejoin:round}
.w.done .n{opacity:0;transform:scale(1.4)}.w.done .ck{opacity:1;transform:none}""", p, s=S, w=W, fs=int(S * .28), e=EASE["springy"])
    body = f"""<div class="w" id="w"><svg viewBox="0 0 100 100"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="{p['accent']}"/><stop offset="1" stop-color="{p['acc2']}"/></linearGradient></defs>
<circle class="bg" cx="50" cy="50" r="46"/><circle class="fg" id="fg" cx="50" cy="50" r="46"/></svg><div class="n" id="n">0%</div><div class="ck"><svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></div></div>"""
    js = fill("""const fg=document.getElementById('fg'),n=document.getElementById('n'),w=document.getElementById('w');
function run(){w.classList.remove('done');const s=performance.now();(function f(t){const k=Math.min(1,(t-s)/(__T__*1000)),e=k<.5?4*k*k*k:1-Math.pow(-2*k+2,3)/2;fg.style.strokeDashoffset=289*(1-e);n.textContent=Math.round(e*100)+'%';if(k<1)requestAnimationFrame(f);else{w.classList.add('done');setTimeout(run,1800)}})(s)}run();""", t=T)
    desc = r.choice([f"a circular progress ring ({S}px) with a gradient stroke, counting 0→100% and morphing into a drawn checkmark",
                     f"an animated progress ring with eased fill over {T}s, glow, and a success check, {p['desc']}",
                     f"a radial loader that completes with a springy checkmark reveal"])
    return desc, page("Progress ring", p, css, body, js)

def g_like(r, p):
    n = r.choice([8, 10, 12]); dist = r.choice([46, 58, 70]); c1, c2 = r.choice([("#ff4d6d", "#ffb703"), ("#ff3b1f", "#ffd23f"), ("#ff2d95", "#7c5cff")])
    parts = "".join(f'<i style="--a:{360/n*k:.1f}deg;--c:{c1 if k % 2 else c2}"></i>' for k in range(n))
    css = F(""".w{position:relative;display:flex;align-items:center;gap:14px;padding:16px 26px 16px 20px;border-radius:99px;background:__CARD__;box-shadow:0 1px 0 __LINE__ inset,0 20px 50px __SH__}
.h{position:relative;width:44px;height:44px;cursor:pointer}.h svg{position:absolute;inset:0;width:100%;height:100%;fill:__LINE__;transition:fill .2s}
.h.on svg{fill:__C1__;animation:pop .7s cubic-bezier(.34,1.56,.64,1)}@keyframes pop{0%{transform:scale(.4)}50%{transform:scale(1.35)}100%{transform:scale(1)}}
.h i{position:absolute;left:50%;top:50%;width:7px;height:7px;margin:-3.5px;border-radius:50%;background:var(--c);opacity:0}
.h.on i{animation:bs .7s cubic-bezier(.2,.7,.2,1) forwards}@keyframes bs{0%{opacity:1;transform:rotate(var(--a)) translateY(-14px) scale(1)}100%{opacity:0;transform:rotate(var(--a)) translateY(-__D__px) scale(.2)}}
.c{font:700 22px Inter,system-ui;letter-spacing:-.03em;font-variant-numeric:tabular-nums;min-width:60px}""", p, c1=c1, d=dist)
    body = f'<div class="w"><div class="h" id="h"><svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>{parts}</div><div class="c" id="c">1,248</div></div>'
    js = """const h=document.getElementById('h'),c=document.getElementById('c');let n=1248,on=false;
function tog(){on=!on;h.classList.remove('on');void h.offsetWidth;if(on)h.classList.add('on');c.textContent=(on?n+1:n).toLocaleString()}
h.onclick=tog;setInterval(tog,2000);setTimeout(tog,500);"""
    desc = r.choice([f"a like button with a springy heart pop and a {n}-particle radial burst plus a live counter, {p['desc']}",
                     "an animated heart/like micro-interaction: scale overshoot, confetti burst, count increments",
                     "a reaction button with particle burst and eased counter, auto-demo loop"])
    return desc, page("Like burst", p, css, body, js)

def g_tilt(r, p):
    g = r.choice(GRADS); mx = r.choice([10, 14, 18]); title = r.choice(["Aurora", "Nebula", "Prism", "Halo", "Echo"]); chip = r.choice(["LIMITED", "NEW", "PRO", "BETA"])
    css = F(""".st{perspective:900px}.c{position:relative;width:280px;height:360px;border-radius:28px;background:linear-gradient(145deg,__G1__,__G2__ 55%,__G3__);transform-style:preserve-3d;box-shadow:0 40px 80px __SH2__;overflow:hidden;will-change:transform}
.c::after{content:'';position:absolute;inset:0;background:radial-gradient(420px circle at var(--gx,50%) var(--gy,50%),#ffffff66,#fff0 55%);mix-blend-mode:soft-light;pointer-events:none}
.t{position:absolute;left:26px;bottom:60px;font-size:44px;font-weight:800;letter-spacing:-.04em;color:#fff;transform:translateZ(60px);text-shadow:0 8px 24px #0004}
.s{position:absolute;left:26px;bottom:32px;font-size:13px;color:#ffffffcc;transform:translateZ(30px)}
.ch{position:absolute;top:24px;left:26px;font:700 10px ui-monospace,monospace;letter-spacing:.18em;padding:7px 11px;border-radius:99px;background:#00000040;color:#fff;transform:translateZ(40px);backdrop-filter:blur(8px)}""", p, g1=g[0], g2=g[1], g3=g[2])
    body = f'<div class="st"><div class="c" id="c"><span class="ch">{chip}</span><div class="t">{title}</div><div class="s">Collection 2026 · Hover to tilt</div></div></div>'
    js = fill("""const c=document.getElementById('c');(function f(t){const x=Math.sin(t/1100),y=Math.cos(t/1450);c.style.transform=`rotateY(${x*__MX__}deg) rotateX(${-y*__MX__}deg)`;c.style.setProperty('--gx',50+x*45+'%');c.style.setProperty('--gy',50+y*45+'%');requestAnimationFrame(f)})(0);""", mx=mx)
    desc = r.choice([f"a 3D tilt card ('{title}') with parallax text layers and a moving glare, ±{mx}° rotation",
                     "a holographic trading-card style hover effect: perspective tilt, specular glare, floating label layers",
                     f"a premium gradient card that rotates in 3D with depth-separated typography, {p['desc']} backdrop"])
    return desc, page("Tilt card", p, css, body, js)

def g_skeleton(r, p):
    g = r.choice(GRADS); name = r.choice(["Maya Chen", "Leo Park", "Ava Singh", "Noah Reed"]); role = r.choice(["Product Designer", "Motion Artist", "Frontend Engineer", "Creative Director"])
    css = F(""".c{position:relative;width:340px;height:150px;border-radius:24px;background:__CARD__;box-shadow:0 1px 0 __LINE__ inset,0 24px 60px __SH__;overflow:hidden}
.l{position:absolute;inset:0;padding:24px;display:flex;gap:16px;align-items:center;transition:opacity .6s,transform .7s __E__}
.sk{background:linear-gradient(90deg,__MUTED__26 25%,__MUTED__55 50%,__MUTED__26 75%);background-size:300% 100%;animation:sh 1.4s linear infinite;border-radius:10px}@keyframes sh{to{background-position:-300% 0}}
.av{width:64px;height:64px;border-radius:50%;flex:none}.ln{height:14px;margin:8px 0}
.real{opacity:0;transform:translateY(14px)}.real .av{background:linear-gradient(135deg,__G1__,__G2__,__G3__)}
.real b{display:block;font-size:19px;letter-spacing:-.02em}.real span{font-size:13px;color:__MUTED__}.real em{display:inline-block;margin-top:10px;font:600 11px ui-monospace,monospace;padding:5px 10px;border-radius:99px;background:__LINE__;font-style:normal}
.c.loaded .sk-l{opacity:0;transform:translateY(-14px)}.c.loaded .real{opacity:1;transform:none}""", p, g1=g[0], g2=g[1], g3=g[2], e=EASE["smooth"])
    body = f"""<div class="c" id="c"><div class="l sk-l"><div class="av sk"></div><div style="flex:1"><div class="ln sk" style="width:70%"></div><div class="ln sk" style="width:45%"></div><div class="ln sk" style="width:85%"></div></div></div>
<div class="l real"><div class="av"></div><div><b>{name}</b><span>{role}</span><br><em>Available</em></div></div></div>"""
    js = """const c=document.getElementById('c');function run(){c.classList.remove('loaded');setTimeout(()=>c.classList.add('loaded'),1700)}run();setInterval(run,4600);"""
    desc = r.choice(["a skeleton loading card with a shimmer sweep that cross-fades into the real profile content, looping",
                     f"a loading-to-loaded transition: shimmering placeholder lines morph into a {role.lower()} profile card",
                     f"a content skeleton shimmer + staggered reveal, {p['desc']} UI"])
    return desc, page("Skeleton", p, css, body, js)

def g_scramble(r, p):
    words = r.choice([["DECODING", "SIGNAL FOUND", "ACCESS GRANTED", "BUILD 2026"], ["FRAME", "BY FRAME", "IN CODE", "EVERY PIXEL"], ["HELLO", "WORLD", "MOTION", "DESIGN"], ["INITIALIZE", "COMPILE", "RENDER", "SHIP IT"]])
    fs = r.choice([52, 64, 80])
    css = F(""".t{font:700 clamp(36px,9vw,__FS__px)/1.1 ui-monospace,SFMono-Regular,Menlo,monospace;letter-spacing:.04em;white-space:pre}.t i{font-style:normal;color:__ACCENT__;opacity:.85}.cur{display:inline-block;width:.5em;height:.9em;background:__ACCENT__;vertical-align:-.1em;animation:b 1s steps(1) infinite}@keyframes b{50%{opacity:0}}""", p, fs=fs)
    body = f'<div><span class="t" id="t">{words[0]}</span><span class="cur"></span></div>'
    js = fill("""const words=__W__,el=document.getElementById('t'),ch='█▓▒░/[]{}=+*^?#_';let i=0;
function scramble(to){const from=el.textContent,L=Math.max(from.length,to.length),q=[];for(let k=0;k<L;k++){const s=Math.floor(Math.random()*18),e=s+8+Math.floor(Math.random()*18);q.push({f:from[k]||'',t:to[k]||'',s,e})}let fr=0;
return new Promise(res=>{(function up(){let out='',done=0;for(const o of q){if(fr>=o.e){done++;out+=o.t}else if(fr>=o.s){if(!o.c||Math.random()<.3)o.c=ch[Math.floor(Math.random()*ch.length)];out+='<i>'+o.c+'</i>'}else out+=o.f}el.innerHTML=out;if(done===q.length)res();else{fr++;requestAnimationFrame(up)}})()})}
(async function loop(){while(1){await scramble(words[(i++)%words.length]);await new Promise(r=>setTimeout(r,1300))}})();""", w=json.dumps(words))
    desc = r.choice([f"a text-scramble decode effect cycling {', '.join(words)} in monospace with accent glyphs",
                     "a hacker-style text decoder: characters shuffle through block glyphs before settling, then the next phrase",
                     f"typographic scramble transition in {p['desc']} with a blinking block cursor"])
    return desc, page("Text scramble", p, css, body, js, hud=hudlabel(r, "text scramble"))

# =================================================================== MOTION GRAPHICS
def g_kinetic(r, p):
    w = r.choice(WORDS); style = r.choice(["rise", "flip", "scale", "blur", "wave"]); stg = r.choice([.04, .06, .08]); T = r.choice([2.8, 3.4, 4.2])
    ez = r.choice(["smooth", "snappy", "springy"]); wt = r.choice([700, 800, 900]); cap = r.choice(["MOTION DESIGN", "SHOWREEL 2026", "MADE IN CODE", "EVERY FRAME"])
    INS = {"rise": ("0%{transform:translateY(115%)}", "transform:translateY(-115%)"),
           "flip": ("0%{transform:translateY(60%) rotateX(-90deg)}", "transform:translateY(-60%) rotateX(90deg)"),
           "scale": ("0%{transform:scale(.2);opacity:0}", "transform:scale(1.6);opacity:0"),
           "blur": ("0%{filter:blur(26px);opacity:0;transform:translateY(24px)}", "filter:blur(26px);opacity:0;transform:translateY(-24px)")}
    if style == "wave":
        anim = F(".m span{display:inline-block;animation:wv __H__s ease-in-out infinite alternate}@keyframes wv{from{transform:translateY(.14em)}to{transform:translateY(-.14em)}}", p, h=T / 2)
        mask = ""
    else:
        i, o = INS[style]
        anim = F(".m span{display:inline-block;animation:k __T__s __E__ infinite both;transform-origin:50% 100%}", p, t=T, e=EASE[ez]) + "@keyframes k{" + i + ";25%{transform:none;opacity:1;filter:none}75%{transform:none;opacity:1;filter:none}100%{" + o + "}}"
        mask = ".m{overflow:hidden;padding:.06em .01em}" if style in ("rise", "flip") else ""
    css = F(".w{display:flex;font-size:clamp(56px,15vw,180px);font-weight:__WT__;letter-spacing:-.045em;line-height:1;perspective:700px}.cap{margin-top:22px;text-align:center;font:500 12px ui-monospace,monospace;letter-spacing:.4em;color:__MUTED__;animation:cp __T__s ease infinite}@keyframes cp{0%,15%{opacity:0}30%,75%{opacity:1}100%{opacity:0}}", p, wt=wt, t=T) + mask + anim
    spans = "".join(f'<div class="m"><span style="animation-delay:{i*stg:.2f}s">{ch}</span></div>' for i, ch in enumerate(w))
    body = f'<div><div class="w" aria-label="{w}">{spans}</div><div class="cap">{cap}</div></div>'
    desc = r.choice([f"kinetic typography: '{w}' revealing letter by letter ({style}, {stg}s stagger), weight {wt}, with a mono caption, {p['desc']}",
                     f"a motion-design title: per-letter {style} animation of {w} with {ez} easing on a {T}s loop",
                     f"bold kinetic type card spelling {w} with staggered {style} and a spaced-out subtitle"])
    return desc, page("Kinetic type", p, css, body, hud=hudlabel(r, "kinetic type"))

def g_squash(r, p):
    D = r.choice([140, 180, 220]); size = r.choice([56, 72, 90]); T = r.choice([1.0, 1.2, 1.5]); sq = r.choice([1.3, 1.45, 1.6])
    css = F(""".st{position:relative;height:__H__px;width:260px}
.ball{position:absolute;left:50%;bottom:24px;width:__S__px;height:__S__px;margin-left:-__HS__px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#ffffffaa,#fff0 38%),__ACCENT__;box-shadow:0 -6px 18px #0002 inset;transform-origin:50% 100%;animation:bn __T__s infinite}
.sh{position:absolute;left:50%;bottom:8px;width:__S__px;height:14px;margin-left:-__HS__px;border-radius:50%;background:#000;opacity:.25;filter:blur(6px);animation:sd __T__s infinite}
.fl{position:absolute;left:0;right:0;bottom:20px;height:1px;background:__LINE__}
@keyframes bn{0%{transform:translateY(-__D__px) scale(.94,1.06);animation-timing-function:cubic-bezier(.55,0,1,.45)}
47%{transform:translateY(0) scale(.88,1.14);animation-timing-function:ease-out}
50%{transform:translateY(0) scale(__SQ__,.6);animation-timing-function:cubic-bezier(0,.55,.45,1)}
58%{transform:translateY(-__D40__px) scale(.9,1.12)}100%{transform:translateY(-__D__px) scale(.94,1.06)}}
@keyframes sd{0%,100%{transform:scale(.45);opacity:.1}50%{transform:scale(__SQ__,1);opacity:.38}}""", p, h=D + size + 50, s=size, hs=size // 2, t=T, d=D, d40=int(D * .45), sq=sq)
    body = '<div class="st"><div class="fl"></div><div class="sh"></div><div class="ball"></div></div>'
    desc = r.choice([f"a squash-and-stretch bouncing ball ({size}px, {T}s cycle) with a glossy highlight and synced contact shadow, {p['desc']}",
                     f"classic animation-principles demo: a ball that stretches on the fall and squashes {sq}x on impact with a soft floor line",
                     "a bouncing sphere with anticipation, squash on landing and a blurred ground shadow"])
    return desc, page("Squash and stretch", p, css, body, hud=hudlabel(r, "squash & stretch"))

def g_particles(r, p):
    n = r.choice([1400, 2000, 2800]); pull = r.choice([80, 120, 180]); trail = r.choice([.1, .16, .24])
    cols = r.choice([[p["accent"], p["fg"]], [p["accent"], p["acc2"], p["fg"]], [p["accent"], p["acc2"], p["muted"]]])
    js = fill("""const c=document.getElementById('c'),x=c.getContext('2d');let W,H;
function rs(){W=c.width=innerWidth*devicePixelRatio;H=c.height=innerHeight*devicePixelRatio}rs();addEventListener('resize',rs);
const cols=__COLS__,P=Array.from({length:__N__},()=>({x:Math.random()*W,y:Math.random()*H,vx:0,vy:0,c:cols[(Math.random()*cols.length)|0]}));
function frame(t){x.fillStyle='rgba(__BGRGB__,__TR__)';x.fillRect(0,0,W,H);
const ax=W/2+Math.cos(t/1100)*W*.25,ay=H/2+Math.sin(t/1700)*H*.25;
for(const p of P){const dx=ax-p.x,dy=ay-p.y,d=Math.hypot(dx,dy)+30,f=__PULL__/d*.0016;
p.vx=(p.vx+dx*f)*.97;p.vy=(p.vy+dy*f)*.97;p.x+=p.vx;p.y+=p.vy;x.fillStyle=p.c;x.fillRect(p.x,p.y,2*devicePixelRatio,2*devicePixelRatio)}
requestAnimationFrame(frame)}requestAnimationFrame(frame);""", cols=json.dumps(cols), n=n, bgrgb=",".join(map(str, hx(p["bg"]))), tr=trail, pull=pull)
    desc = r.choice([f"a canvas particle swarm of {n} dots orbiting a moving attractor with motion trails, {p['desc']}",
                     f"generative particle system: thousands of pixels pulled toward a Lissajous path (pull {pull})",
                     f"a 2D particle cloud that swirls and clusters, trail fade {trail}, palette-driven colors"])
    return desc, page("Particles", p, "canvas{display:block;width:100vw;height:100vh;position:fixed;inset:0}", '<canvas id="c"></canvas>', js, hud=hudlabel(r, "particle system", .7), grain=False)

def g_flow(r, p):
    n = r.choice([1500, 2200, 3000]); sc = r.choice([.0016, .0024, .0034]); sp = r.choice([1.2, 1.8, 2.4])
    cols = [p["accent"], p["acc2"], p["fg"], p["muted"]][:r.choice([2, 3, 4])]
    js = fill("""const c=document.getElementById('c'),x=c.getContext('2d');let W,H;const D=devicePixelRatio;
function rs(){W=c.width=innerWidth*D;H=c.height=innerHeight*D;x.fillStyle='__BG__';x.fillRect(0,0,W,H)}rs();addEventListener('resize',rs);
const cols=__COLS__,N=__N__,S=__SC__,V=__SP__*D,P=Array.from({length:N},()=>({x:Math.random()*W,y:Math.random()*H,l:Math.random()*200}));
const ang=(px,py,t)=>(Math.sin(px*S/D+t*.00018)+Math.cos(py*S/D*1.3-t*.00014)+Math.sin((px+py)*S/D*.6))*Math.PI*.8;
function frame(t){x.fillStyle='rgba(__BGRGB__,.045)';x.fillRect(0,0,W,H);
for(const p of P){const a=ang(p.x,p.y,t);p.x+=Math.cos(a)*V;p.y+=Math.sin(a)*V;p.l--;
if(p.l<0||p.x<0||p.y<0||p.x>W||p.y>H){p.x=Math.random()*W;p.y=Math.random()*H;p.l=120+Math.random()*160}
x.fillStyle=cols[Math.floor((((a/(Math.PI*2))%1)+1)%1*cols.length)];x.globalAlpha=.8;x.fillRect(p.x,p.y,1.4*D,1.4*D)}x.globalAlpha=1;requestAnimationFrame(frame)}requestAnimationFrame(frame);""",
              cols=json.dumps(cols), n=n, sc=sc, sp=sp, bg=p["bg"], bgrgb=",".join(map(str, hx(p["bg"]))))
    desc = r.choice([f"a generative flow field: {n} particles following a swirling vector field and leaving long soft trails, {p['desc']}",
                     "an organic noise-driven flow-field artwork painting ribbons of light on canvas",
                     f"canvas generative art with sinusoidal flow (scale {sc}) and {len(cols)}-color angle mapping"])
    return desc, page("Flow field", p, "canvas{display:block;width:100vw;height:100vh;position:fixed;inset:0}", '<canvas id="c"></canvas>', js, hud=hudlabel(r, "flow field", .7), grain=False)

def g_stars(r, p):
    n = r.choice([500, 800, 1200]); sp = r.choice([.012, .02, .03])
    js = fill("""const c=document.getElementById('c'),x=c.getContext('2d');let W,H;const D=devicePixelRatio;
function rs(){W=c.width=innerWidth*D;H=c.height=innerHeight*D}rs();addEventListener('resize',rs);
const N=__N__,S=Array.from({length:N},()=>({x:(Math.random()-.5)*2,y:(Math.random()-.5)*2,z:Math.random()}));
function frame(t){const v=__SP__*(1.2+Math.sin(t/1800)*.9);x.fillStyle='rgba(__BGRGB__,.28)';x.fillRect(0,0,W,H);x.lineCap='round';
for(const s of S){const pz=s.z;s.z-=v;if(s.z<=.01){s.x=(Math.random()-.5)*2;s.y=(Math.random()-.5)*2;s.z=1;continue}
const k=Math.min(W,H)*.5,x1=W/2+s.x/s.z*k*.5,y1=H/2+s.y/s.z*k*.5,x0=W/2+s.x/pz*k*.5,y0=H/2+s.y/pz*k*.5;
x.strokeStyle=s.x*s.y>.3?'__ACC2__':'__FG__';x.globalAlpha=Math.min(1,(1-s.z)*1.4);x.lineWidth=(1-s.z)*2.6*D;x.beginPath();x.moveTo(x0,y0);x.lineTo(x1,y1);x.stroke()}x.globalAlpha=1;requestAnimationFrame(frame)}requestAnimationFrame(frame);""",
              n=n, sp=sp, bgrgb=",".join(map(str, hx(p["bg"]))), acc2=p["acc2"], fg=p["fg"])
    desc = r.choice([f"a hyperspace starfield with {n} stars streaking from the center, speed pulsing, {p['desc']}",
                     "a warp-speed starfield on canvas: radial streaks with perspective and breathing velocity",
                     "an infinite tunnel of stars rushing toward the viewer with motion-blur trails"])
    return desc, page("Starfield", p, "canvas{display:block;width:100vw;height:100vh;position:fixed;inset:0}", '<canvas id="c"></canvas>', js, hud=hudlabel(r, "warp field", .7), grain=False)

def g_glitch(r, p):
    w = r.choice(WORDS); T = r.choice([2.2, 3, 4]); off = r.choice([3, 4, 6]); c1, c2 = r.choice([("#ff2a55", "#22e6ff"), ("#ff3b1f", "#3b7bff"), ("#ff00aa", "#00ffd5")])
    def kf(name):
        s = ""
        for pct in sorted(r.sample(range(0, 100, 5), 9)):
            a = r.randint(0, 80); b = r.randint(0, 100 - a - 5)
            s += f"{pct}%{{clip-path:inset({a}% 0 {b}% 0);transform:translate({r.choice([-1,1])*r.randint(2,12)}px,0)}}"
        return f"@keyframes {name}{{{s}100%{{clip-path:inset(0);transform:none}}}}"
    css = F(""".g{position:relative;font-size:clamp(60px,16vw,200px);font-weight:900;letter-spacing:-.045em;animation:j __T__s steps(1) infinite}
.g::before,.g::after{content:attr(data-t);position:absolute;inset:0;mix-blend-mode:screen}
.g::before{color:__C1__;left:-__O__px;animation:a __T__s steps(1) infinite}
.g::after{color:__C2__;left:__O__px;animation:b __T__s steps(1) infinite}
.sc{position:fixed;inset:0;background:repeating-linear-gradient(0deg,#0000 0 2px,#0000001f 2px 3px);pointer-events:none;z-index:7}
@keyframes j{0%,88%{transform:none}90%{transform:skewX(8deg)}93%{transform:skewX(-6deg) translateX(6px)}96%{transform:none}}
__KA__ __KB__""", p, t=T, c1=c1, c2=c2, o=off, ka=kf("a"), kb=kf("b"))
    desc = r.choice([f"a digital glitch title for '{w}': RGB channel split, random clip slices, skew jitter and CRT scanlines",
                     f"glitch text with chromatic aberration ({c1}/{c2}) on a {p['desc']} background",
                     f"a VHS-style glitching word {w}, {T}s loop, pure CSS"])
    return desc, page("Glitch", p, css, f'<div class="g" data-t="{w}">{w}</div><div class="sc"></div>', hud=hudlabel(r, "glitch", .7))

def g_pattern(r, p):
    w = r.choice(WORDS); rows = r.choice([7, 9, 11]); rot = r.choice([-14, -10, -8, 8, 12]); T = r.choice([14, 20, 28])
    css = F(""".bg{position:fixed;inset:-30%;display:flex;flex-direction:column;justify-content:center;transform:rotate(__ROT__deg)}
.row{display:flex;white-space:nowrap;font-size:clamp(48px,9vw,120px);font-weight:900;letter-spacing:-.03em;line-height:.95;animation:m __T__s linear infinite}
.row:nth-child(even){animation-direction:reverse}
.row span{padding-right:.35em;color:transparent;-webkit-text-stroke:2px __FG__}
.row:nth-child(3n) span{color:__ACCENT__;-webkit-text-stroke:0}
@keyframes m{to{transform:translateX(-50%)}}
.c{position:relative;z-index:1;padding:.1em .35em;background:__BG__;color:__FG__;font-size:clamp(40px,8vw,100px);font-weight:900;letter-spacing:-.03em;box-shadow:0 0 0 14px __BG__}""", p, rot=rot, t=T)
    row = "".join(f"<span>{w}</span>" for _ in range(10))
    body = '<div class="bg">' + "".join(f'<div class="row">{row}{row}</div>' for _ in range(rows)) + f'</div><div class="c">{w.title()}</div>'
    desc = r.choice([f"a tilted typographic wall of the word {w}: outlined and solid rows scrolling in opposite directions with a centered label",
                     f"bold repeating-text poster ({rows} rows, {rot}° rotation) in a {p['desc']} palette",
                     f"kinetic marquee pattern featuring {w} with contrasting outline and fill rows"])
    return desc, page("Text pattern", p, css, body, hud=hudlabel(r, "typographic pattern", .5))

def g_tiles(r, p):
    cols = r.choice([16, 20, 24]); rows = r.choice([9, 12, 14]); rot = r.choice([(35, -8), (45, 0), (30, 12)]); sp = r.choice([.0012, .0018, .0026])
    css = F(""".g{display:grid;grid-template-columns:repeat(__C__,1fr);gap:10px;width:min(130vw,1500px);transform:perspective(900px) rotateX(__RX__deg) rotateZ(__RZ__deg)}
.g i{aspect-ratio:1;border-radius:3px;background:__FG__;will-change:transform}
.g i:nth-child(5n){background:__ACCENT__}""", p, c=cols, rx=rot[0], rz=rot[1])
    js = fill("""const g=document.getElementById('g'),C=__C__,R=__R__,cells=[];
for(let i=0;i<C*R;i++){const e=document.createElement('i');g.appendChild(e);cells.push(e)}
(function f(t){for(let i=0;i<cells.length;i++){const cx=i%C-C/2,cy=((i/C)|0)-R/2,d=Math.hypot(cx,cy),w=Math.sin(d*.6-t*__SP__*2);
cells[i].style.transform=`scale(${.25+.75*(w*.5+.5)})`;cells[i].style.opacity=.3+.7*(w*.5+.5)}requestAnimationFrame(f)})(0);""", c=cols, r=rows, sp=sp)
    desc = r.choice([f"a perspective grid of {cols}x{rows} squares pulsing in a radial wave, {p['desc']}",
                     "a tilted tile field where each square scales with a ripple moving outward from the center",
                     f"a 3D-tilted pixel grid wave animation (rotateX {rot[0]}°), JS-driven at 60fps"])
    return desc, page("Tile wave", p, css, '<div class="g" id="g"></div>', js, hud=hudlabel(r, "grid wave", .7))

def g_gooey(r, p):
    n = r.choice([3, 4, 5, 6]); blur = r.choice([12, 16, 20]); T = r.choice([5, 7, 9])
    css = F(""".g{position:relative;width:340px;height:340px;filter:url(#goo) drop-shadow(0 30px 40px __SH__)}
.g i{position:absolute;border-radius:50%;background:__ACCENT__;animation:mv __T__s ease-in-out infinite alternate}
@keyframes mv{from{transform:translate(var(--x0),var(--y0)) scale(var(--s0))}to{transform:translate(var(--x1),var(--y1)) scale(var(--s1))}}""", p, t=T)
    blobs = ""
    for k in range(n):
        d = r.randint(90, 150); L = 340 - d
        blobs += (f'<i style="width:{d}px;height:{d}px;left:{r.randint(0, L)}px;top:{r.randint(0, L)}px;animation-delay:-{k*T/n:.2f}s;animation-duration:{T*r.uniform(.7,1.3):.1f}s;'
                  f'--x0:{r.randint(-55,55)}px;--y0:{r.randint(-55,55)}px;--s0:{r.uniform(.6,1):.2f};--x1:{r.randint(-55,55)}px;--y1:{r.randint(-55,55)}px;--s1:{r.uniform(.8,1.3):.2f}"></i>')
    body = f"""<svg width="0" height="0" style="position:absolute"><defs><filter id="goo"><feGaussianBlur in="SourceGraphic" stdDeviation="{blur}" result="b"/>
<feColorMatrix in="b" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 22 -9"/></filter></defs></svg><div class="g">{blobs}</div>"""
    desc = r.choice([f"a gooey metaball animation with {n} circles merging and splitting (SVG goo filter, blur {blur}), {p['desc']}",
                     f"organic liquid blobs that fuse together smoothly, {n} orbs, {T}s drift",
                     "smooth-union style metaballs built from an SVG filter, with a soft drop shadow"])
    return desc, page("Metaballs", p, css, body, hud=hudlabel(r, "gooey blobs", .6))

def g_orbits(r, p):
    n = r.choice([3, 4, 5, 6]); tilt = r.choice([.32, .4, .5]); rot = r.choice([-25, -15, 15, 25]); base = r.choice([50, 60, 70]); step = r.choice([26, 32, 38])
    rings = ""
    for k in range(n):
        rx = base + k * step; ry = rx * tilt; dur = r.choice([8, 11, 14, 18]) + k * 2; col = p["accent"] if k % 2 == 0 else p["acc2"]
        path = f"M{rx},0 a{rx},{ry} 0 1,0 {-2*rx},0 a{rx},{ry} 0 1,0 {2*rx},0"
        rings += (f'<ellipse rx="{rx}" ry="{ry:.1f}" fill="none" stroke="{p["line"]}" stroke-width="1.2"/>'
                  f'<circle r="{r.choice([4,5,6])}" fill="{col}"><animateMotion dur="{dur}s" begin="-{r.randint(0,dur)}s" repeatCount="indefinite" path="{path}"/></circle>')
    css = F(".o{width:min(86vmin,640px);height:min(86vmin,640px);overflow:visible}@keyframes pu{50%{r:__CR__}}.core{animation:pu 3s ease-in-out infinite;filter:drop-shadow(0 0 20px __ACCENT__)}", p, cr=r.choice([16, 20, 24]))
    body = f'<svg class="o" viewBox="-300 -300 600 600"><g transform="rotate({rot})">{rings}<circle class="core" r="12" fill="{p["accent"]}"/></g></svg>'
    desc = r.choice([f"an orbital system: {n} tilted elliptical rings with dots orbiting at different speeds and a glowing core, {p['desc']}",
                     "an SVG orbit diagram with animateMotion planets, rotated 3D-feel ellipses and a pulsing nucleus",
                     f"minimal orbit animation ({n} rings, {rot}° tilt) in a {p['desc']} palette"])
    return desc, page("Orbits", p, css, body, hud=hudlabel(r, "orbits", .6))

def g_monogram(r, p):
    n = r.choice([5, 6, 7, 8, 9, 10]); ratio = r.choice([.38, .46, .55]); layers = r.choice([2, 3, 4]); T = r.choice([4.5, 5.5, 6.5])
    def poly(R, rot):
        pts = []
        for i in range(n * 2):
            rad = R if i % 2 == 0 else R * ratio; a = math.pi * i / n + rot
            pts.append((rad * math.cos(a), rad * math.sin(a)))
        return "M" + " L".join(f"{x:.1f},{y:.1f}" for x, y in pts) + " Z"
    paths = ""
    for k in range(layers):
        col = p["accent"] if k % 2 == 0 else p["acc2"]
        paths += f'<path pathLength="1" class="pa" style="animation-delay:{k*.35:.2f}s" d="{poly(150-k*28, k*.18)}" fill="{col}" stroke="{col}"/>'
    css = F(""".m{width:min(78vmin,520px);height:min(78vmin,520px);overflow:visible;animation:rt __RT__s linear infinite}@keyframes rt{to{transform:rotate(1turn)}}
.pa{fill-opacity:0;stroke-width:2;stroke-dasharray:1;stroke-dashoffset:1;stroke-linejoin:round;animation:dw __T__s cubic-bezier(.65,0,.35,1) infinite}
@keyframes dw{0%{stroke-dashoffset:1;fill-opacity:0}40%{stroke-dashoffset:0;fill-opacity:0}60%{fill-opacity:.16;stroke-dashoffset:0}85%{fill-opacity:.16;stroke-dashoffset:0;opacity:1}100%{stroke-dashoffset:-1;fill-opacity:0;opacity:.2}}""", p, t=T, rt=T * 6)
    body = f'<svg class="m" viewBox="-170 -170 340 340">{paths}</svg>'
    desc = r.choice([f"a line-drawing monogram: {layers} nested {n}-point stars that draw on, fill softly, then erase, while slowly rotating, {p['desc']}",
                     "an SVG stroke-dash logo reveal with layered star polygons and eased draw-on",
                     f"generative geometric mark ({n} points, inner ratio {ratio}) drawn with stroke-dashoffset"])
    return desc, page("Monogram draw", p, css, body, hud=hudlabel(r, "line draw", .6))

def g_title(r, p):
    w = r.choice(["CLAUDE", "AURORA", "VECTOR", "NORTH", "ATLAS", "HALO", "MERIDIAN", "KINETIC"]); a = r.choice(["MOTION DESIGN", "CREATIVE CODE", "VISUAL SYSTEMS", "BRAND FILM"]); T = r.choice([5, 6, 7])
    css = F(""".t{font-size:clamp(64px,16vw,210px);font-weight:900;letter-spacing:-.05em;line-height:1;text-shadow:0 0 60px __ACC2__55,0 0 14px __FG__33;animation:in __T__s __E__ infinite;display:flex;align-items:center}
.dot{display:inline-block;width:.15em;height:.15em;border-radius:50%;background:__ACC2__;margin-left:.07em;margin-top:.5em;box-shadow:0 0 34px __ACC2__;animation:bk 1.4s ease-in-out infinite}
@keyframes bk{50%{opacity:.25;transform:scale(.8)}}
.sub{display:flex;justify-content:space-between;margin-top:20px;padding-top:14px;border-top:1px solid __LINE__;font:500 12px ui-monospace,monospace;letter-spacing:.32em;color:__MUTED__;animation:in __T__s __E__ infinite;animation-delay:.18s}
.ring{position:absolute;width:150%;height:34%;left:-25%;top:30%;border:1px solid __LINE__;border-radius:50%;transform:rotate(-8deg);pointer-events:none;animation:in __T__s __E__ infinite;animation-delay:.1s}
@keyframes in{0%{opacity:0;filter:blur(18px);transform:translateY(26px) scale(.97)}16%,82%{opacity:1;filter:none;transform:none}100%{opacity:0;filter:blur(18px);transform:translateY(-18px)}}""", p, t=T, e=EASE["smooth"])
    body = f'<div style="position:relative"><div class="ring"></div><div class="t">{w}<i class="dot"></i></div><div class="sub"><span>{a}</span><span>SHOWREEL 2026</span></div></div>'
    desc = r.choice([f"a cinematic title card: '{w}' with a glowing blinking dot, orbit ring and mono subtitle row ({a} / SHOWREEL 2026), {p['desc']}",
                     f"a motion-reel end card: heavy wordmark {w} blurring in, soft glow, thin divider and spaced caption, {T}s loop",
                     f"a premium brand outro with the wordmark {w}, accent dot and credits line"])
    return desc, page("Title card", p, css, body, hud=hudlabel(r, "title", .8))

def g_countdown(r, p):
    T = r.choice([4, 5]); ez = r.choice(["expo", "snappy", "smooth"]); fs = r.choice([140, 180, 220])
    seq = ["3", "2", "1", "GO"]
    css = F(""".w{position:relative;display:grid;place-items:center;width:min(70vmin,420px);height:min(70vmin,420px)}
.win{height:__FS__px;overflow:hidden;font-size:__FS__px;font-weight:900;letter-spacing:-.06em;line-height:__FS__px;text-align:center}
.col{animation:cd __T__s infinite}.col div{height:__FS__px}.col div:last-child{color:__ACCENT__}
@keyframes cd{0%,16%{transform:translateY(0);animation-timing-function:__E__}24%,41%{transform:translateY(-__FS__px);animation-timing-function:__E__}49%,66%{transform:translateY(-__FS2__px);animation-timing-function:__E__}74%,100%{transform:translateY(-__FS3__px)}}
svg{position:absolute;inset:0;width:100%;height:100%;transform:rotate(-90deg)}circle{fill:none;stroke-width:3}.b{stroke:__LINE__}.f{stroke:__ACCENT__;stroke-dasharray:289;stroke-dashoffset:289;animation:pr __T__s linear infinite;stroke-linecap:round}
@keyframes pr{0%{stroke-dashoffset:289}74%{stroke-dashoffset:0}100%{stroke-dashoffset:0;opacity:.2}}""", p, fs=fs, fs2=fs * 2, fs3=fs * 3, t=T, e=EASE[ez])
    body = '<div class="w"><svg viewBox="0 0 100 100"><circle class="b" cx="50" cy="50" r="46"/><circle class="f" cx="50" cy="50" r="46"/></svg><div class="win"><div class="col">' + "".join(f"<div>{s}</div>" for s in seq) + "</div></div></div>"
    desc = r.choice([f"a 3-2-1-GO countdown where digits slide up through a mask with {ez} easing and a progress ring draws around them, {p['desc']}",
                     "a title-sequence countdown: stacked numerals translating in a clipped window, accent GO, circular timer",
                     f"an animated countdown ({T}s loop, {fs}px numerals) with rolling digits and a ring"])
    return desc, page("Countdown", p, css, body, hud=hudlabel(r, "countdown", .8))

# =================================================================== WEBGL SHADERS
GL_JS = """const c=document.getElementById('c'),gl=c.getContext('webgl');
function sh(t,s){const o=gl.createShader(t);gl.shaderSource(o,s);gl.compileShader(o);if(!gl.getShaderParameter(o,gl.COMPILE_STATUS))console.error(gl.getShaderInfoLog(o));return o}
const pr=gl.createProgram();gl.attachShader(pr,sh(gl.VERTEX_SHADER,'attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}'));
gl.attachShader(pr,sh(gl.FRAGMENT_SHADER,FS));gl.linkProgram(pr);gl.useProgram(pr);
const b=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,b);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
const l=gl.getAttribLocation(pr,'p');gl.enableVertexAttribArray(l);gl.vertexAttribPointer(l,2,gl.FLOAT,false,0,0);
const uT=gl.getUniformLocation(pr,'t'),uR=gl.getUniformLocation(pr,'r');
function rs(){const d=Math.min(devicePixelRatio,1.5);c.width=innerWidth*d;c.height=innerHeight*d;gl.viewport(0,0,c.width,c.height)}rs();addEventListener('resize',rs);
(function f(ms){gl.uniform1f(uT,ms/1000);gl.uniform2f(uR,c.width,c.height);gl.drawArrays(gl.TRIANGLES,0,3);requestAnimationFrame(f)})(0);"""
GL_CSS = "canvas{display:block;width:100vw;height:100vh;position:fixed;inset:0}"

def gl_page(title, p, fs, hud):
    js = "const FS=" + json.dumps(fs) + ";\n" + GL_JS
    return page(title, p, GL_CSS, '<canvas id="c"></canvas>', js, hud=hud, grain=True)

def g_gl_metaballs(r, p):
    N = r.choice([3, 4, 5]); S = r.uniform(.45, 1.0); A = r.uniform(.7, 1.05); R = r.uniform(.42, .62); K = r.uniform(.7, 1.3); shift = r.uniform(0, 1)
    fs = fill("""precision highp float;uniform float t;uniform vec2 r;
float smin(float a,float b,float k){float h=max(k-abs(a-b),0.)/k;return min(a,b)-h*h*k*.25;}
float map(vec3 p){float d=1e5;for(int i=0;i<__N__;i++){float fi=float(i);
vec3 c=vec3(sin(t*__S__+fi*2.1)*__A__,cos(t*__S__*.8+fi*1.7)*__A__*.7,sin(t*__S__*.6+fi*1.3)*.45);d=smin(d,length(p-c)-__R__,__K__);}return d;}
vec3 nor(vec3 p){vec2 e=vec2(.002,0.);return normalize(vec3(map(p+e.xyy)-map(p-e.xyy),map(p+e.yxy)-map(p-e.yxy),map(p+e.yyx)-map(p-e.yyx)));}
vec3 pal(float x){return .5+.5*cos(6.28318*(x+vec3(0.,.33,.67)+__SH__));}
void main(){vec2 uv=(gl_FragCoord.xy-.5*r)/r.y;vec3 ro=vec3(0.,0.,-4.),rd=normalize(vec3(uv,1.7));float d=0.,tt=0.;bool hit=false;
for(int i=0;i<72;i++){d=map(ro+rd*tt);if(d<.002){hit=true;break;}tt+=d;if(tt>9.)break;}
vec3 bg=__BG3__;vec3 col=bg+__ACC3__*exp(-length(uv)*1.8)*.14;
if(hit){vec3 p=ro+rd*tt,n=nor(p);float fr=pow(1.+dot(rd,n),3.);vec3 ir=pal(dot(n,vec3(.3,.5,.8))*1.3+t*.04+fr*.7);
vec3 L=normalize(vec3(.6,.8,-.5));float spec=pow(max(dot(reflect(rd,n),L),0.),48.);float dif=.5+.5*dot(n,L);
col=mix(ir*(.35+.4*dif),ir+.35,fr)+spec*.9;col=mix(col,vec3(1.),fr*.12);}
col*=1.-.35*dot(uv,uv);col+=(fract(sin(dot(gl_FragCoord.xy,vec2(12.9898,78.233)))*43758.5453)-.5)*.025;gl_FragColor=vec4(col,1.);}""",
            n=N, s=f"{S:.3f}", a=f"{A:.3f}", r=f"{R:.3f}", k=f"{K:.3f}", sh=f"{shift:.3f}", bg3=v3(p["bg"]), acc3=v3(p["accent"]))
    desc = r.choice([f"a WebGL raymarched smooth-union metaball scene: {N} iridescent chrome-like blobs merging, fresnel rim and specular, on {p['desc']}",
                     "a fragment-shader SDF metaballs animation with thin-film iridescent shading, soft vignette and film grain",
                     f"raw WebGL (no libraries): {N} liquid orbs blended with smooth-min, rainbow fresnel, slow drift"])
    return desc, gl_page("SDF metaballs", p, fs, hudlabel(r, "smooth union / sdf", .8))

def g_gl_aurora(r, p):
    S = r.uniform(1.6, 3.0); SP = r.uniform(.12, .3); c1 = mix(p["bg"], p["accent"], .35); c3 = p["acc2"]
    fs = fill("""precision highp float;uniform float t;uniform vec2 r;
void main(){vec2 uv=gl_FragCoord.xy/r;vec2 q=(uv-.5)*vec2(r.x/r.y,1.)*__S__;
for(int i=1;i<6;i++){float fi=float(i);q+=vec2(.6/fi*sin(fi*q.y+t*__SP__*3.+.3*fi),.6/fi*sin(fi*q.x+t*__SP__*2.7+.3*fi));}
float v=.5+.5*sin(q.x+q.y);vec3 col=mix(__C1__,__C2__,smoothstep(.15,.85,v));
col=mix(col,__C3__,smoothstep(.55,1.,.5+.5*sin(q.x*1.3-t*.2))*.6);
col+=__C2__*pow(1.-abs(sin(q.y*2.1+q.x)),10.)*.22;
col=mix(__BG3__,col,smoothstep(-.1,.8,uv.y*1.1+.18*sin(q.x)));col*=1.-.5*length(uv-.5);
col+=(fract(sin(dot(gl_FragCoord.xy+t,vec2(12.9898,78.233)))*43758.5453)-.5)*.045;gl_FragColor=vec4(col,1.);}""",
            s=f"{S:.3f}", sp=f"{SP:.3f}", c1=v3(c1), c2=v3(p["accent"]), c3=v3(c3), bg3=v3(p["bg"]))
    desc = r.choice([f"a WebGL domain-warped gradient mesh / aurora in {p['desc']} tones, slowly flowing, with grain and vignette",
                     "a fragment shader producing silky flowing color fields via iterated sine warping, minimal and cinematic",
                     "an animated gradient-mesh background in raw WebGL with film grain and a soft falloff"])
    return desc, gl_page("Aurora gradient", p, fs, hudlabel(r, "gradient mesh", .6))

def g_gl_contours(r, p):
    N = r.choice([3, 4, 5]); F_ = r.uniform(7, 13); K = r.choice([3., 4., 5., 6.]); SP = r.uniform(.5, 1.1)
    fs = fill("""precision highp float;uniform float t;uniform vec2 r;
void main(){vec2 uv=(gl_FragCoord.xy-.5*r)/r.y;float v=0.;
for(int i=0;i<__N__;i++){float fi=float(i)+1.;vec2 c=vec2(cos(t*.21*fi+fi*2.),sin(t*.17*fi+fi*3.))*.42;v+=sin(length(uv-c)*__F__-t*__SP__)/fi;}
float w=abs(fract(v*__K__*.25)-.5);float l=smoothstep(.43,.5,w);vec3 line=mix(__ACC3__,__ACC23__,uv.x+.5);
vec3 col=mix(__BG3__,line,l*(.55+.45*smoothstep(.9,.0,length(uv))));col*=1.-.3*dot(uv,uv);gl_FragColor=vec4(col,1.);}""",
            n=N, f=f"{F_:.2f}", k=f"{K:.1f}", sp=f"{SP:.2f}", acc3=v3(p["accent"]), acc23=v3(p["acc2"]), bg3=v3(p["bg"]))
    desc = r.choice([f"a WebGL topographic contour-line animation: {N} wave sources interfering, thin accent lines on {p['desc']}",
                     "generative interference-pattern art as a fragment shader: concentric ripples merge into elegant contour lines",
                     "a minimalist shader of moving isolines with a two-color gradient and vignette"])
    return desc, gl_page("Contour waves", p, fs, hudlabel(r, "interference", .7))

GENS = [g_spinner, g_segmented, g_slider, g_player, g_palette, g_button, g_ripple, g_stats, g_toggles, g_toast, g_dock, g_ring, g_like, g_tilt, g_skeleton, g_scramble,
        g_kinetic, g_squash, g_particles, g_flow, g_stars, g_glitch, g_pattern, g_tiles, g_gooey, g_orbits, g_monogram, g_title, g_countdown,
        g_gl_metaballs, g_gl_aurora, g_gl_contours]

def make_prompt(r, desc):
    ctx = r.choice(CTX); s = f"{r.choice(OPEN)} {desc}{(' ' + ctx) if ctx else ''}. {' '.join(r.sample(CONS, r.randint(1, 2)))}"
    return s[0].lower() + s[1:] if r.random() < .15 else s

def build(n, seed):
    r = random.Random(seed); seen, out = set(), []; pool = list(GENS); fails = {g: 0 for g in GENS}; i = 0
    while len(out) < n and pool:
        g = pool[i % len(pool)]; i += 1
        p = r.choice(PALS); desc, code = g(r, p)
        assert not re.search(r"__[A-Z0-9]+__", code), g.__name__
        h = hashlib.md5(code.encode()).hexdigest()
        if h in seen:
            fails[g] += 1
            if fails[g] > 60: pool.remove(g)
            continue
        fails[g] = 0; seen.add(h)
        out.append({"messages": [{"role": "system", "content": SYSTEM},
                                 {"role": "user", "content": make_prompt(r, desc)},
                                 {"role": "assistant", "content": code}],
                    "meta": {"family": g.__name__[2:], "palette": p["name"]}})
    return out

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=1000); ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", default="dataset"); ap.add_argument("--preview", type=int, default=0)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
    data = build(a.n, a.seed); random.Random(a.seed).shuffle(data)
    k = max(1, int(len(data) * .95))
    for name, rows in (("dataset", data), ("train", data[:k]), ("val", data[k:])):
        with open(f"{a.out}/{name}.jsonl", "w", encoding="utf-8") as f:
            for row in rows: f.write(json.dumps(row, ensure_ascii=False) + "\n")
    if a.preview:
        os.makedirs(f"{a.out}/preview", exist_ok=True); seen_f = {}
        for row in data:
            fam = row["meta"]["family"]
            if seen_f.get(fam, 0) < max(1, a.preview // len(GENS)) and sum(seen_f.values()) < a.preview:
                seen_f[fam] = seen_f.get(fam, 0) + 1
                open(f"{a.out}/preview/{fam}_{seen_f[fam]}.html", "w", encoding="utf-8").write(row["messages"][2]["content"])
    print(f"{len(data)} samples | train {k} | val {len(data)-k} -> {a.out}/")
