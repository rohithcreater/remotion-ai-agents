#!/usr/bin/env python3
"""Validate a Remotion dataset: format, JSON files, forbidden APIs, and tsc (strict) on every project.
   tsc runs against light stub typings for remotion/react in ./tc (offline). For full fidelity, run `npm i` in a preview project and use real types."""
import json, re, sys, collections
import check
ORDER = ["package.json", "tsconfig.json", "src/index.ts", "src/Root.tsx", "src/Video.tsx"]
def parse(a):
    head, *rest = re.split(r"(?m)^// ===== FILE: (.+?) =====\n", a)
    files = dict(zip(rest[0::2], rest[1::2])); return head.strip(), files
def main(path):
    rows = [json.loads(l) for l in open(path)]; bad = collections.defaultdict(list); items = {}
    for row in rows:
        plan, files = parse(row["messages"][2]["content"]); k = row["id"]
        if not plan.startswith("// PLAN:"): bad[k].append("no plan")
        if list(files) != ORDER: bad[k].append(f"files {list(files)}")
        for j in ("package.json", "tsconfig.json"):
            try: json.loads(files[j])
            except Exception as e: bad[k].append(f"{j} json {e}")
        v = files.get("src/Video.tsx", "")
        for pat in (r"Math\.random", r"Date\.now", r"new Date", r"setTimeout|setInterval|requestAnimationFrame", r"localStorage", r"from '(?!remotion'|react')"):
            if re.search(pat, v): bad[k].append(f"forbidden {pat}")
        if "useCurrentFrame" not in v: bad[k].append("no useCurrentFrame")
        items[k] = files
    errs = {}
    ks = list(items)
    for i in range(0, len(ks), 250):
        errs.update(check.check({k: items[k] for k in ks[i:i+250]}, tag=f"v{i}"))
    for k, v in errs.items(): bad[k] += v[:2]
    fam = {r["id"]: r["family"] for r in rows}
    print(f"{len(rows)} samples | format/forbidden problems + tsc errors in {len(bad)}")
    for k, v in list(bad.items())[:10]: print(fam[k], k, v[:2])
    return len(bad)
if __name__ == "__main__": sys.exit(1 if main(sys.argv[1] if len(sys.argv) > 1 else "out/dataset.jsonl") else 0)
