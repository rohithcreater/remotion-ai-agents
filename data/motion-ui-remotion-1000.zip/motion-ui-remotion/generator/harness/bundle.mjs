import {createRequire} from 'module';
const require = createRequire('/opt/npm-tools/package.json');
const esbuild = require('esbuild');
import fs from 'fs';
const dir = process.argv[2];
for (const name of fs.readdirSync(dir)) {
  const f = `${dir}/${name}/Video.tsx`;
  if (!fs.existsSync(f)) continue;
  try {
    await esbuild.build({
      entryPoints: ['/home/claude/rm/harness/entry.tsx'], bundle: true, outfile: `${dir}/${name}/bundle.js`, format: 'iife',
      jsx: 'automatic', nodePaths: ['/home/claude/.npm-global/lib/node_modules', '/opt/npm-tools/node_modules'],
      alias: {remotion: '/home/claude/rm/harness/remotion-mock.tsx', VIDEO: process.cwd() + '/' + f}, logLevel: 'error', define: {'process.env.NODE_ENV': '"production"'},
    });
  } catch (e) { console.error('FAIL', name, String(e).slice(0, 300)); }
}
