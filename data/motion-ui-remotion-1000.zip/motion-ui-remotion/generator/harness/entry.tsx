import * as React from 'react';
import {createRoot} from 'react-dom/client';
// @ts-ignore
import {Video} from 'VIDEO';
let root: any = null;
(window as any).__show = (cfg: any) => {
  window.__cfg = cfg as any;
  const el = document.getElementById('app')!;
  if (!root) root = createRoot(el);
  // flushSync-like: render then wait a tick so effects (canvas / WebGL) run
  root.render(<Video key={cfg.frame} />);
};
