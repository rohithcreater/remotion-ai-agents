import * as React from 'react';
declare global { interface Window { __cfg: {frame: number; fps: number; width: number; height: number; durationInFrames: number}; } }
export const AbsoluteFill: React.FC<any> = ({style, children}) => (
  <div style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, display: 'flex', flexDirection: 'column', ...style}}>{children}</div>
);
export const useCurrentFrame = () => window.__cfg.frame;
export const useVideoConfig = () => ({...window.__cfg, id: 'Main'});
const bez = (x1: number, y1: number, x2: number, y2: number) => (x: number) => {
  if (x <= 0) return 0; if (x >= 1) return 1;
  let lo = 0, hi = 1, t = x;
  for (let i = 0; i < 40; i++) { const cx = 3 * x1 * t * (1 - t) ** 2 + 3 * x2 * t * t * (1 - t) + t ** 3; if (cx < x) lo = t; else hi = t; t = (lo + hi) / 2; }
  return 3 * y1 * t * (1 - t) ** 2 + 3 * y2 * t * t * (1 - t) + t ** 3;
};
export const Easing: any = {
  linear: (t: number) => t, ease: bez(0.42, 0, 1, 1), quad: (t: number) => t * t, cubic: (t: number) => t ** 3, sin: (t: number) => 1 - Math.cos((t * Math.PI) / 2),
  exp: (t: number) => 2 ** (10 * (t - 1)), circle: (t: number) => 1 - Math.sqrt(1 - t * t),
  in: (e: any) => e, out: (e: any) => (t: number) => 1 - e(1 - t), inOut: (e: any) => (t: number) => (t < 0.5 ? e(t * 2) / 2 : 1 - e((1 - t) * 2) / 2),
  bezier: bez,
};
export const interpolate = (x: number, inR: number[], outR: number[], o: any = {}) => {
  let t = (x - inR[0]) / (inR[1] - inR[0]);
  if (o.extrapolateLeft === 'clamp') t = Math.max(0, t); if (o.extrapolateRight === 'clamp') t = Math.min(1, t);
  if (o.easing) t = o.easing(t);
  return outR[0] + (outR[1] - outR[0]) * t;
};
export const spring = () => 1; export const random = (s: any) => Math.abs(Math.sin(Number(s) * 12.9898) * 43758.5453) % 1;
export const registerRoot = () => {}; export const Composition: any = () => null; export const Sequence: any = ({children}: any) => <>{children}</>;
