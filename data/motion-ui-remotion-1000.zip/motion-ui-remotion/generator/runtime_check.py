#!/usr/bin/env python3
"""Mount samples in headless Chromium (mock `remotion`), render first/mid/last frames, flag exceptions, NaN/undefined styles, WebGL errors, blank frames."""
import json, os, re, shutil, subprocess, sys, collections
from playwright.sync_api import sync_playwright
from PIL import Image
import numpy as np
from validate_remotion import parse
def run(path="out/dataset.jsonl", per=3, skip=0):
    rows = [json.loads(l) for l in open(path)]; cnt = collections.Counter(); pick = []
    for r in rows:
        cnt[r["family"]] += 1
        if skip < cnt[r["family"]] <= skip + per: pick.append(r)
    shutil.rmtree("harness/s", ignore_errors=True); meta = {}
    for r in pick:
        _, files = parse(r["messages"][2]["content"]); d = f"harness/s/{r['id']}"; os.makedirs(d); open(f"{d}/Video.tsx", "w").write(files["src/Video.tsx"])
        m = re.search(r"durationInFrames=\{(\d+)\} fps=\{(\d+)\} width=\{(\d+)\} height=\{(\d+)\}", files["src/Root.tsx"]); meta[r["id"]] = (r["family"], *map(int, m.groups()))
    subprocess.run(["node", "harness/bundle.mjs", "harness/s"], check=True)
    problems = []
    with sync_playwright() as p:
        b = p.chromium.launch(args=["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"])
        for sid, (fam, dur, fps, W, H) in meta.items():
            if not os.path.exists(f"harness/s/{sid}/bundle.js"): problems.append((sid, fam, "bundle failed")); continue
            pg = b.new_page(viewport={"width": 480, "height": 270}); errs = []
            pg.on("pageerror", lambda e: errs.append(str(e)[:160])); pg.on("console", lambda m: errs.append(m.text[:160]) if m.type == "error" else None)
            pg.set_content(f'<html><body style="margin:0"><div id="app" style="position:relative;width:{W}px;height:{H}px;overflow:hidden;zoom:{480/W}"></div></body></html>')
            pg.add_script_tag(path=f"harness/s/{sid}/bundle.js")
            for fr in (0, dur // 2, dur - 1):
                pg.evaluate("c=>window.__show(c)", dict(frame=fr, fps=fps, width=W, height=H, durationInFrames=dur)); pg.wait_for_timeout(60)
                html = pg.inner_html("#app")
                if re.search(r"NaN|undefined|Infinity", html): errs.append(f"NaN/undefined in DOM @f{fr}")
                pg.screenshot(path="/tmp/f.png", clip=dict(x=0, y=0, width=480, height=int(480 * H / W)))
                a = np.asarray(Image.open("/tmp/f.png").convert("L")); 
                if a.std() < 1.0 and fam not in ("spinner",): errs.append(f"blank frame @f{fr}")
            if errs: problems.append((sid, fam, errs[:2]))
            pg.close()
        b.close()
    print(f"{len(meta)} samples mounted; problems: {len(problems)}")
    for x in problems[:15]: print(x)
    return problems
if __name__ == "__main__": run(*(sys.argv[1:2] or ["out/dataset.jsonl"]))
