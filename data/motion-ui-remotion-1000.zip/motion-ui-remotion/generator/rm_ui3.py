import json, math
from rm_core import *

def g_dock(r, p):
    n = r.choice([5, 6, 7]); S = 54; gap = 12; mx = r.choice([.7, .9, 1.1]); gl = list("ABCDEFG")[:n]; gs = [GRADS[(i + r.randint(0, 3)) % len(GRADS)] for i in range(n)]
    fps = 30; dur = 188
    b = tsx("""const ICONS = __ICONS__;
const S = __S__, GAP = __GAP__, MAXZ = __MX__, R = 70; // base size, gap, extra magnification, gaussian radius
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const n = ICONS.length;
  const W = n * (S + GAP) - GAP;
  // simulated cursor sweeps left↔right once per loop
  const px = W / 2 + Math.sin((frame / durationInFrames) * Math.PI * 2) * W * 0.62;
  const sizes = ICONS.map((_, i) => {
    const cx = i * (S + GAP) + S / 2;
    return S * (1 + MAXZ * Math.exp(-Math.pow((cx - px) / R, 2)));
  });
  return (
    <div style={{display: 'flex', gap: GAP, alignItems: 'flex-end', padding: '10px 14px', height: __DH__, borderRadius: 28, transform: 'scale(0.82)', background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 30px 70px ${C.sh}`}}>
      {ICONS.map((ic, i) => (
        <div key={ic.l} style={{width: sizes[i], height: sizes[i], borderRadius: '24%', display: 'grid', placeItems: 'center', fontWeight: 800, color: '#fff', fontSize: 18 * (sizes[i] / S), textShadow: '0 1px 3px #0005', background: `linear-gradient(135deg, ${ic.g[0]}, ${ic.g[1]}, ${ic.g[2]})`, boxShadow: '0 8px 18px #0003, 0 1px 0 #ffffff55 inset'}}>
          {ic.l}
        </div>
      ))}
    </div>
  );
};""", icons=[{"l": l, "g": list(g)} for l, g in zip(gl, gs)], s=S, gap=gap, mx=mx, dh=int(S * (1 + mx) + 20))
    desc = r.choice([f"a macOS-style dock with {n} icons that magnify smoothly as a simulated cursor sweeps across (max scale {1+mx:.1f}x)",
                     f"dock magnification effect with gaussian falloff and glass shelf, {p['desc']}",
                     f"an animated app dock: {n} gradient icons growing around a moving pointer"])
    plan = f"// PLAN: dock of {n} icons; a virtual pointer x follows a sine over the whole {dur}-frame loop and each icon scales by 1+{mx}·exp(-((cx-px)/70)^2); sizes are computed per frame, no state."
    return fam(r, p, desc, plan, b, [], 1080, 1080, fps, dur)

def g_ring(r, p):
    S = r.choice([140, 170, 200]) * 1.4; W = r.choice([8, 10, 12]); T = r.choice([2.2, 2.8, 3.4]); fps = 30
    fill_f = round(T * fps); hold_f = 54; dur = fill_f + hold_f + 12
    b = tsx("""const FILL = __FILL__; // frames to fill the ring
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const k = clamp01(frame / FILL);
  const e = k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
  const R = 46, circ = 2 * Math.PI * R;
  const done = seg(frame - FILL, 0, 18, Easing.bezier(0.34, 1.56, 0.64, 1));
  const check = seg(frame - FILL, 4, 22, Easing.out(Easing.cubic));
  return (
    <div style={{position: 'relative', width: __S__, height: __S__}}>
      <svg viewBox="0 0 100 100" style={{width: '100%', height: '100%', transform: 'rotate(-90deg)', overflow: 'visible'}}>
        <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={C.accent} /><stop offset="1" stopColor={C.acc2} /></linearGradient></defs>
        <circle cx="50" cy="50" r={R} fill="none" stroke={C.line} strokeWidth={__W__ * 0.5} />
        <circle cx="50" cy="50" r={R} fill="none" stroke="url(#g)" strokeWidth={__W__ * 0.5} strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={circ * (1 - e)} style={{filter: `drop-shadow(0 0 10px ${C.accent}66)`}} />
      </svg>
      <div style={{position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', fontSize: __FS__, fontWeight: 700, letterSpacing: '-0.04em', fontVariantNumeric: 'tabular-nums', opacity: 1 - done, transform: `scale(${1 + 0.4 * done})`}}>
        {Math.round(e * 100)}%
      </div>
      <div style={{position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', opacity: done, transform: `scale(${0.4 + 0.6 * done})`}}>
        <svg viewBox="0 0 24 24" width="42%" height="42%" fill="none" stroke={C.accent} strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round">
          <path d="M5 12.5l4.5 4.5L19 7.5" pathLength={1} strokeDasharray="1" strokeDashoffset={1 - check} />
        </svg>
      </div>
    </div>
  );
};""", fill=fill_f, s=round(S), w=W, fs=int(S * .28))
    desc = r.choice([f"a circular progress ring ({round(S)}px) with a gradient stroke, counting 0→100% and morphing into a drawn checkmark",
                     f"an animated progress ring with eased fill over {T}s, glow, and a success check, {p['desc']}",
                     "a radial loader that completes with a springy checkmark reveal"])
    plan = f"// PLAN: progress ring; strokeDashoffset eases (cubic in-out) over {fill_f} frames while the percent counts up, then the number scales out and a check draws in with a back-overshoot; {dur} frames at {fps} fps."
    return fam(r, p, desc, plan, b, ["Easing", "interpolate"], 1080, 1080, fps, dur)

def g_like(r, p):
    n = r.choice([8, 10, 12]); dist = r.choice([46, 58, 70]); c1, c2 = r.choice([("#ff4d6d", "#ffb703"), ("#ff3b1f", "#ffd23f"), ("#ff2d95", "#7c5cff")])
    fps = 30; period = 60; dur = period * 4
    b = tsx("""const N = __N__, DIST = __DIST__, PERIOD = __PERIOD__;
const COLORS = ['__C1__', '__C2__'];
const HEART = 'M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z';
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const toggle = Math.floor(frame / PERIOD);       // each period flips liked ↔ unliked
  const liked = toggle % 2 === 1;
  const local = frame - toggle * PERIOD;
  const t = clamp01(local / 21);                   // 0.7s pop at 30fps
  const pop = liked ? (t < 0.5 ? 0.4 + 0.95 * Easing.out(Easing.cubic)(t * 2) : 1.35 - 0.35 * Easing.inOut(Easing.cubic)((t - 0.5) * 2)) : 1;
  const burst = liked ? Easing.bezier(0.2, 0.7, 0.2, 1)(t) : 0;
  const base = 1248 + (liked ? 1 : 0);
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 14, padding: '16px 26px 16px 20px', borderRadius: 99, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 20px 50px ${C.sh}`}}>
      <div style={{position: 'relative', width: 44, height: 44}}>
        <svg viewBox="0 0 24 24" style={{position: 'absolute', inset: 0, width: '100%', height: '100%', fill: liked ? COLORS[0] : C.line, transform: `scale(${pop})`}}><path d={HEART} /></svg>
        {liked && Array.from({length: N}).map((_, k) => (
          <div key={k} style={{position: 'absolute', left: '50%', top: '50%', width: 7, height: 7, margin: -3.5, borderRadius: '50%', background: COLORS[k % 2 ? 0 : 1], opacity: t < 1 ? 1 - burst : 0, transform: `rotate(${(360 / N) * k}deg) translateY(${-(14 + (DIST - 14) * burst)}px) scale(${1 - 0.8 * burst})`}} />
        ))}
      </div>
      <div style={{font: '700 22px Inter, system-ui', letterSpacing: '-0.03em', fontVariantNumeric: 'tabular-nums', minWidth: 60}}>{base.toLocaleString('en-US')}</div>
    </div>
  );
};""", n=n, dist=dist, period=period, c1=c1, c2=c2)
    desc = r.choice([f"a like button with a springy heart pop and a {n}-particle radial burst plus a live counter, {p['desc']}",
                     "an animated heart/like micro-interaction: scale overshoot, particle burst, count increments",
                     "a reaction button with particle burst and eased counter, auto-demo loop"])
    plan = f"// PLAN: like pill that toggles every {period} frames; on like the heart overshoots to 1.35x and settles, {n} particles fly {dist}px outward and fade, the counter increments; {dur} frames at {fps} fps."
    return fam(r, p, desc, plan, b, ["Easing"], 1080, 1080, fps, dur)

def g_tilt(r, p):
    g = r.choice(GRADS); mx = r.choice([10, 14, 18]); title = r.choice(["Aurora", "Nebula", "Prism", "Halo", "Echo"]); chip = r.choice(["LIMITED", "NEW", "PRO", "BETA"]); fps = 30; dur = 210
    b = tsx("""const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const a = (frame / durationInFrames) * Math.PI * 2;
  const x = Math.sin(a), y = Math.cos(a * 1.0 + 0.9);
  const gx = 50 + x * 45, gy = 50 + y * 45;
  return (
    <div style={{perspective: 900}}>
      <div style={{position: 'relative', width: 280, height: 360, borderRadius: 28, background: 'linear-gradient(145deg, __G1__, __G2__ 55%, __G3__)', transformStyle: 'preserve-3d', boxShadow: `0 40px 80px ${C.sh2}`, overflow: 'hidden', transform: `rotateY(${x * __MX__}deg) rotateX(${-y * __MX__}deg)`}}>
        <div style={{position: 'absolute', inset: 0, background: `radial-gradient(420px circle at ${gx}% ${gy}%, #ffffff66, #fff0 55%)`, mixBlendMode: 'soft-light'}} />
        <div style={{position: 'absolute', top: 24, left: 26, font: `700 10px ${MONO}`, letterSpacing: '0.18em', padding: '7px 11px', borderRadius: 99, background: '#00000040', color: '#fff', transform: 'translateZ(40px)'}}>__CHIP__</div>
        <div style={{position: 'absolute', left: 26, bottom: 60, fontSize: 44, fontWeight: 800, letterSpacing: '-0.04em', color: '#fff', transform: `translateZ(60px) translate(${-x * 4}px, ${y * 3}px)`, textShadow: '0 8px 24px #0004'}}>__TITLE__</div>
        <div style={{position: 'absolute', left: 26, bottom: 32, fontSize: 13, color: '#ffffffcc', transform: 'translateZ(30px)'}}>Collection 2026 · Hover to tilt</div>
      </div>
    </div>
  );
};""", g1=g[0], g2=g[1], g3=g[2], mx=mx, chip=chip, title=title)
    desc = r.choice([f"a 3D tilt card ('{title}') with parallax text layers and a moving glare, ±{mx}° rotation",
                     "a holographic trading-card style hover effect: perspective tilt, specular glare, floating label layers",
                     f"a premium gradient card that rotates in 3D with depth-separated typography, {p['desc']} backdrop"])
    plan = f"// PLAN: gradient card in a 900px perspective; rotateY/rotateX = ±{mx}° from sin/cos of the loop phase, the glare gradient centre and text layers shift with the same phase; {dur} frames at {fps} fps."
    return fam(r, p, desc, plan, b, [], 1080, 1080, fps, dur)

def g_skeleton(r, p):
    g = r.choice(GRADS); name = r.choice(["Maya Chen", "Leo Park", "Ava Singh", "Noah Reed"]); role = r.choice(["Product Designer", "Motion Artist", "Frontend Engineer", "Creative Director"])
    ez_ = "smooth"; fps = 30; load = 51; cycle = 138; dur = cycle * 2
    b = tsx("""const LOAD = __LOAD__, CYCLE = __CYCLE__;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = __E__;
  const local = frame % CYCLE;
  const reveal = ease(seg(local, LOAD, LOAD + 21, (x) => x));
  const sweep = ((frame % 42) / 42) * -300; // shimmer position, 1.4s period
  const sk: React.CSSProperties = {background: `linear-gradient(90deg, ${C.muted}26 25%, ${C.muted}55 50%, ${C.muted}26 75%)`, backgroundSize: '300% 100%', backgroundPosition: `${sweep}% 0`, borderRadius: 10};
  return (
    <div style={{position: 'relative', width: 340, height: 150, borderRadius: 24, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 24px 60px ${C.sh}`, overflow: 'hidden'}}>
      <div style={{position: 'absolute', inset: 0, padding: 24, display: 'flex', gap: 16, alignItems: 'center', opacity: 1 - reveal, transform: `translateY(${-14 * reveal}px)`}}>
        <div style={{...sk, width: 64, height: 64, borderRadius: '50%', flex: 'none'}} />
        <div style={{flex: 1}}>
          <div style={{...sk, height: 14, margin: '8px 0', width: '70%'}} />
          <div style={{...sk, height: 14, margin: '8px 0', width: '45%'}} />
          <div style={{...sk, height: 14, margin: '8px 0', width: '85%'}} />
        </div>
      </div>
      <div style={{position: 'absolute', inset: 0, padding: 24, display: 'flex', gap: 16, alignItems: 'center', opacity: reveal, transform: `translateY(${14 * (1 - reveal)}px)`}}>
        <div style={{width: 64, height: 64, borderRadius: '50%', flex: 'none', background: 'linear-gradient(135deg, __G1__, __G2__, __G3__)'}} />
        <div>
          <div style={{fontSize: 19, fontWeight: 700, letterSpacing: '-0.02em'}}>__NAME__</div>
          <div style={{fontSize: 13, color: C.muted}}>__ROLE__</div>
          <div style={{display: 'inline-block', marginTop: 10, font: `600 11px ${MONO}`, padding: '5px 10px', borderRadius: 99, background: C.line}}>Available</div>
        </div>
      </div>
    </div>
  );
};""", load=load, cycle=cycle, e=ez(ez_), g1=g[0], g2=g[1], g3=g[2], name=name, role=role)
    desc = r.choice(["a skeleton loading card with a shimmer sweep that cross-fades into the real profile content, looping",
                     f"a loading-to-loaded transition: shimmering placeholder lines morph into a {role.lower()} profile card",
                     f"a content skeleton shimmer + staggered reveal, {p['desc']} UI"])
    plan = f"// PLAN: profile card; skeleton blocks shimmer (background-position sweep every 42 frames) for {load} frames, then cross-fade and slide into the real content over 21 frames; cycle {cycle} frames, {dur} total at {fps} fps."
    return fam(r, p, desc, plan, b, ["Easing", "interpolate"], 1080, 1080, fps, dur)

def g_scramble(r, p):
    words = r.choice([["DECODING", "SIGNAL FOUND", "ACCESS GRANTED", "BUILD 2026"], ["FRAME", "BY FRAME", "IN CODE", "EVERY PIXEL"], ["HELLO", "WORLD", "MOTION", "DESIGN"], ["INITIALIZE", "COMPILE", "RENDER", "SHIP IT"]])
    fs = r.choice([52, 64, 80]); fs = min(fs, int(480 / (max(len(w) for w in words) * 0.66 + 0.7))); fps = 30; scr = 36; hold = 39; slot = scr + hold; dur = slot * len(words); hud = hudlabel(r, "text scramble")
    b = tsx("""const WORDS = __W__;
const GLYPHS = '█▓▒░/[]{}=+*^?#_';
const SCRAMBLE = __SCR__, HOLD = __HOLD__; // frames
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const slot = SCRAMBLE + HOLD;
  const idx = Math.floor(frame / slot) % WORDS.length;
  const prev = WORDS[(idx + WORDS.length - 1) % WORDS.length];
  const to = WORDS[idx];
  const f = frame % slot;
  const L = Math.max(prev.length, to.length);
  const chars: React.ReactNode[] = [];
  for (let k = 0; k < L; k++) {
    const start = Math.floor(rnd(idx * 101 + k * 7 + 1) * 12);
    const end = start + 8 + Math.floor(rnd(idx * 53 + k * 13 + 2) * 16);
    if (f >= end) chars.push(<span key={k}>{to[k] ?? ''}</span>);
    else if (f >= start) {
      const g = GLYPHS[Math.floor(rnd(frame * 0.5 + k * 3.1 + idx) * GLYPHS.length)];
      chars.push(<span key={k} style={{color: C.accent, opacity: 0.85}}>{g}</span>);
    } else chars.push(<span key={k}>{idx === 0 && frame < slot ? to[k] ?? '' : prev[k] ?? ''}</span>);
  }
  const cursor = Math.floor(frame / 15) % 2 === 0;
  return (
    <div style={{display: 'flex', alignItems: 'center', font: `700 __FS__px/1.1 ${MONO}`, letterSpacing: '0.04em', whiteSpace: 'pre'}}>
      <span>{chars}</span>
      <span style={{display: 'inline-block', width: '0.5em', height: '0.9em', marginLeft: 4, background: C.accent, opacity: cursor ? 1 : 0}} />
    </div>
  );
};""", w=words, scr=scr, hold=hold, fs=fs)
    desc = r.choice([f"a text-scramble decode effect cycling {', '.join(words)} in monospace with accent glyphs",
                     "a hacker-style text decoder: characters shuffle through block glyphs before settling, then the next phrase",
                     f"typographic scramble transition in {p['desc']} with a blinking block cursor"])
    plan = f"// PLAN: monospace decoder cycling {len(words)} phrases; each character gets a seeded start/end frame (rnd of word+index) so scrambling is deterministic; {scr} scramble + {hold} hold frames per phrase, {dur} frames at {fps} fps."
    return fam(r, p, desc, plan, b, [], 1080, 1080, fps, dur, hud=hud)
