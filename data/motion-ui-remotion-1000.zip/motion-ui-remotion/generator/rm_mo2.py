import json, math
from rm_core import *
from rm_mo1 import KF, FPS, W, H

def g_pattern(r, p):
    w = r.choice(WORDS); rows = r.choice([7, 9, 11]); rot = r.choice([-14, -10, -8, 8, 12]); T = r.choice([14, 20, 28]) // 2
    P = T * FPS; dur = P; hud = hudlabel(r, "typographic pattern", .5)
    b = tsx("""const WORD = '__WORD__';
const ROWS = __ROWS__, P = __P__;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {width} = useVideoConfig();
  const ph = (frame % P) / P;
  const size = Math.min(width * 0.0625, 120);
  const set = Array.from({length: 10}).map((_, i) => (
    <span key={i} style={{paddingRight: '0.35em'}}>{WORD}</span>
  ));
  return (
    <>
      <div style={{position: 'absolute', inset: '-30%', display: 'flex', flexDirection: 'column', justifyContent: 'center', transform: 'rotate(__ROT__deg)'}}>
        {Array.from({length: ROWS}).map((_, row) => {
          const shift = row % 2 === 1 ? -50 * (1 - ph) : -50 * ph; // alternate rows run in opposite directions
          const filled = row % 3 === 2;
          return (
            <div key={row} style={{display: 'flex', width: 'max-content', whiteSpace: 'nowrap', fontSize: size, fontWeight: 900, letterSpacing: '-0.03em', lineHeight: 0.95, transform: `translateX(${shift}%)`, color: filled ? C.accent : 'transparent', WebkitTextStroke: filled ? '0px' : `3px ${C.fg}`}}>
              <div style={{display: 'flex'}}>{set}</div>
              <div style={{display: 'flex'}}>{set}</div>
            </div>
          );
        })}
      </div>
      <div style={{position: 'relative', zIndex: 1, padding: '0.1em 0.35em', background: C.bg, color: C.fg, fontSize: size * 0.85, fontWeight: 900, letterSpacing: '-0.03em', boxShadow: `0 0 0 28px ${C.bg}`}}>
        {WORD.charAt(0) + WORD.slice(1).toLowerCase()}
      </div>
    </>
  );
};""", word=w, rows=rows, p=P, rot=rot)
    desc = r.choice([f"a tilted typographic wall of the word {w}: outlined and solid rows scrolling in opposite directions with a centered label",
                     f"bold repeating-text poster ({rows} rows, {rot}° rotation) in a {p['desc']} palette",
                     f"kinetic marquee pattern featuring {w} with contrasting outline and fill rows"])
    plan = f"// PLAN: {rows} marquee rows rotated {rot}° behind a centred label; each row is two copies of the word set so translating by exactly -50% of its width loops seamlessly every {P} frames; odd rows reverse; every third row is solid accent, the rest outlined; {dur} frames at {FPS} fps."
    return fam(r, p, desc, plan, b, [], W, H, FPS, dur, hud=hud, scaled=False)

def g_tiles(r, p):
    cols = r.choice([16, 20, 24]); rows = r.choice([9, 12, 14]); rot = r.choice([(35, -8), (45, 0), (30, 12)]); T = r.choice([2.0, 2.6, 3.4])
    P = round(T * FPS); dur = P * 2; hud = hudlabel(r, "grid wave", .7)
    b = tsx("""const COLS = __C__, ROWS = __R__, P = __P__; // P = frames per wave cycle
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const phase = (frame / P) * Math.PI * 2;
  const cells = [];
  for (let i = 0; i < COLS * ROWS; i++) {
    const cx = (i % COLS) - COLS / 2, cy = Math.floor(i / COLS) - ROWS / 2;
    const d = Math.hypot(cx, cy);
    const w = Math.sin(d * 0.6 - phase) * 0.5 + 0.5; // radial ripple travelling outward
    cells.push(
      <div key={i} style={{aspectRatio: '1', borderRadius: 4, background: i % 5 === 4 ? C.accent : C.fg, transform: `scale(${0.25 + 0.75 * w})`, opacity: 0.3 + 0.7 * w}} />
    );
  }
  return (
    <div style={{display: 'grid', gridTemplateColumns: `repeat(${COLS}, 1fr)`, gap: 14, width: 1500, transform: 'perspective(900px) rotateX(__RX__deg) rotateZ(__RZ__deg)'}}>
      {cells}
    </div>
  );
};""", c=cols, r=rows, p=P, rx=rot[0], rz=rot[1])
    desc = r.choice([f"a perspective grid of {cols}x{rows} squares pulsing in a radial wave, {p['desc']}",
                     "a tilted tile field where each square scales with a ripple moving outward from the center",
                     f"a 3D-tilted pixel grid wave animation (rotateX {rot[0]}°) that loops every {P} frames"])
    plan = f"// PLAN: {cols}x{rows} tile grid in perspective(900px) rotateX({rot[0]}deg); each tile's scale/opacity = sin(distance*0.6 - 2π·frame/{P}) so the ripple loops exactly every {P} frames; {dur} frames at {FPS} fps."
    return fam(r, p, desc, plan, b, [], W, H, FPS, dur, hud=hud, scaled=False)

def g_gooey(r, p):
    n = r.choice([3, 4, 5, 6]); blur = r.choice([12, 16, 20]); T = r.choice([5, 7, 9]); L = T * 2 * FPS; hud = hudlabel(r, "gooey blobs", .6)
    blobs = []
    for k in range(n):
        d = r.randint(90, 150); Lm = 340 - d
        blobs.append(dict(d=round(d * 2.2), l=round(r.randint(0, Lm) * 2.2), t=round(r.randint(0, Lm) * 2.2), m=r.choice([1, 1, 2]), off=round(k / n, 3),
                          x0=round(r.randint(-55, 55) * 2.2), y0=round(r.randint(-55, 55) * 2.2), s0=round(r.uniform(.6, 1), 2),
                          x1=round(r.randint(-55, 55) * 2.2), y1=round(r.randint(-55, 55) * 2.2), s1=round(r.uniform(.8, 1.3), 2)))
    b = tsx("""const BLOBS = __BLOBS__;
const L = __L__; // loop length in frames; each blob completes m ping-pong cycles per loop
const SIZE = 750;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(0.42, 0, 0.58, 1); // CSS ease-in-out
  return (
    <div style={{position: 'relative', width: SIZE, height: SIZE, filter: `url(#goo) drop-shadow(0 30px 40px ${C.sh})`}}>
      <svg width={0} height={0} style={{position: 'absolute'}}>
        <defs>
          <filter id="goo">
            <feGaussianBlur in="SourceGraphic" stdDeviation={__BLUR__ * 2.2} result="b" />
            <feColorMatrix in="b" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 22 -9" />
          </filter>
        </defs>
      </svg>
      {BLOBS.map((b, i) => {
        const cyc = (frame / L) * b.m + b.off;           // cycles completed
        const tri = Math.abs(((cyc % 1) + 1) % 1 * 2 - 1); // ping-pong 0..1..0
        const t = ease(1 - tri);
        const x = b.x0 + (b.x1 - b.x0) * t, y = b.y0 + (b.y1 - b.y0) * t, s = b.s0 + (b.s1 - b.s0) * t;
        return <div key={i} style={{position: 'absolute', width: b.d, height: b.d, left: b.l, top: b.t, borderRadius: '50%', background: C.accent, transform: `translate(${x}px, ${y}px) scale(${s})`}} />;
      })}
    </div>
  );
};""", blobs=blobs, l=L, blur=blur)
    desc = r.choice([f"a gooey metaball animation with {n} circles merging and splitting (SVG goo filter, blur {blur}), {p['desc']}",
                     f"organic liquid blobs that fuse together smoothly, {n} orbs, {T*2}s seamless loop",
                     "smooth-union style metaballs built from an SVG filter, with a soft drop shadow"])
    plan = f"// PLAN: {n} circles under an SVG goo filter (feGaussianBlur {blur} + feColorMatrix alpha 22/-9); each blob ping-pongs between two poses with ease-in-out, completing 1 or 2 cycles per {L}-frame loop with staggered phase; {L} frames at {FPS} fps."
    return fam(r, p, desc, plan, b, ["Easing"], W, H, FPS, L, hud=hud, scaled=False)

def g_orbits(r, p):
    n = r.choice([3, 4, 5, 6]); tilt = r.choice([.32, .4, .5]); rot = r.choice([-25, -15, 15, 25]); base = r.choice([50, 60, 70]); step = r.choice([26, 32, 38])
    L = 360; hud = hudlabel(r, "orbits", .6); rings = []
    for k in range(n):
        rx = round((base + k * step) * 1.15)
        rings.append(dict(rx=rx, ry=round(rx * tilt, 1), m=r.choice([1, 2, 3]), off=round(r.random(), 3), rad=r.choice([4, 5, 6]), col="accent" if k % 2 == 0 else "acc2"))
    cr = r.choice([16, 20, 24])
    b = tsx("""const RINGS = __RINGS__;
const L = __L__; // loop length: planet i completes m full orbits per loop
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const pulse = 12 + (__CR__ - 12) * (0.5 - 0.5 * Math.cos((frame / (L / 4)) * Math.PI * 2));
  return (
    <svg width={1300} height={1300} viewBox="-300 -300 600 600" style={{overflow: 'visible'}}>
      <g transform="rotate(__ROT__)">
        {RINGS.map((rg, i) => {
          const a = ((frame / L) * rg.m + rg.off) * Math.PI * 2;
          const x = rg.rx * Math.cos(a), y = -rg.ry * Math.sin(a); // counter-clockwise like the SVG path
          const col = rg.col === 'accent' ? C.accent : C.acc2;
          return (
            <g key={i}>
              <ellipse rx={rg.rx} ry={rg.ry} fill="none" stroke={C.muted} strokeOpacity={0.55} strokeWidth={1.2} />
              <circle cx={x} cy={y} r={rg.rad} fill={col} />
            </g>
          );
        })}
        <circle r={pulse} fill={C.accent} style={{filter: `drop-shadow(0 0 20px ${C.accent})`}} />
      </g>
    </svg>
  );
};""", rings=rings, l=L, cr=cr, rot=rot)
    desc = r.choice([f"an orbital system: {n} tilted elliptical rings with dots orbiting at different speeds and a glowing core, {p['desc']}",
                     "an SVG orbit diagram with analytically animated planets, rotated 3D-feel ellipses and a pulsing nucleus",
                     f"minimal orbit animation ({n} rings, {rot}° tilt) in a {p['desc']} palette"])
    plan = f"// PLAN: {n} ellipses (ry = rx*{tilt}) rotated {rot}°; planet angle = 2π(frame/{L}·m + offset) with m∈1..3 so every orbit closes within the {L}-frame loop; the core radius pulses 4 times per loop; {L} frames at {FPS} fps."
    return fam(r, p, desc, plan, b, [], W, H, FPS, L, hud=hud, scaled=False)

def g_monogram(r, p):
    n = r.choice([5, 6, 7, 8, 9, 10]); ratio = r.choice([.38, .46, .55]); layers = r.choice([2, 3, 4]); T = r.choice([4.5, 5.5, 6.5]); hud = hudlabel(r, "line draw", .6)
    def poly(R, rot):
        pts = []
        for i in range(n * 2):
            rad = R if i % 2 == 0 else R * ratio; a = math.pi * i / n + rot
            pts.append((rad * math.cos(a), rad * math.sin(a)))
        return "M" + " L".join(f"{x:.1f},{y:.1f}" for x, y in pts) + " Z"
    ls = [dict(d=poly(150 - k * 28, k * .18), delay=round(k * .35 * FPS), col="accent" if k % 2 == 0 else "acc2") for k in range(layers)]
    P = round(T * FPS); dur = P * 3
    b = tsx("""const LAYERS = __LAYERS__;
const P = __P__, DUR = __DUR__, N = __N__;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = Easing.bezier(0.65, 0, 0.35, 1);
  // star polygons are N-fold symmetric, so turning by 360/N over the loop is seamless
  const rotate = (frame / DUR) * (360 / N);
  return (
    <svg width={860} height={860} viewBox="-170 -170 340 340" style={{overflow: 'visible', transform: `rotate(${rotate}deg)`}}>
      {LAYERS.map((l, i) => {
        const local = frame - l.delay;
        const ph = local < 0 ? 0 : (local % P) / P;
        const off = kf(ph, [0, 0.4, 0.85, 1], [1, 0, 0, -1], [ease, (t) => t, ease]);
        const fo = kf(ph, [0, 0.4, 0.6, 0.85, 1], [0, 0, 0.16, 0.16, 0], [(t) => t, ease, (t) => t, ease]);
        const op = kf(ph, [0, 0.85, 1], [1, 1, 0.2], [(t) => t, ease]);
        const col = l.col === 'accent' ? C.accent : C.acc2;
        return <path key={i} d={l.d} pathLength={1} fill={col} fillOpacity={fo} stroke={col} strokeWidth={2} strokeLinejoin="round" strokeDasharray="1" strokeDashoffset={off} opacity={op} />;
      })}
    </svg>
  );
};""", layers=ls, p=P, dur=dur, n=n)
    b = KF + b
    desc = r.choice([f"a line-drawing monogram: {layers} nested {n}-point stars that draw on, fill softly, then erase, while slowly rotating, {p['desc']}",
                     "an SVG stroke-dash logo reveal with layered star polygons and eased draw-on",
                     f"generative geometric mark ({n} points, inner ratio {ratio}) drawn with stroke-dashoffset"])
    plan = f"// PLAN: {layers} star polygons ({n} points) with pathLength=1; per layer a {P}-frame cycle draws on (0-40%), fills to 16% (40-60%), holds, then erases; layers are delayed 0.35s each; slow {360//n}° rotation over {dur} frames at {FPS} fps keeps the loop seamless."
    return fam(r, p, desc, plan, b, ["Easing"], W, H, FPS, dur, hud=hud, scaled=False)

def g_title(r, p):
    w = r.choice(["CLAUDE", "AURORA", "VECTOR", "NORTH", "ATLAS", "HALO", "MERIDIAN", "KINETIC"]); a = r.choice(["MOTION DESIGN", "CREATIVE CODE", "VISUAL SYSTEMS", "BRAND FILM"]); T = r.choice([5, 6, 7])
    P = T * FPS; hud = hudlabel(r, "title", .8); blink = max(1, round(P / 42))
    b = tsx("""const WORD = '__WORD__', SUB = '__SUB__';
const P = __P__, BLINK = __BLINK__; // loop length; number of dot blinks per loop
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const ease = Easing.bezier(0.22, 1, 0.36, 1);
  const size = Math.min(width * 0.16, height * 0.3);
  const reveal = (delay: number, extra = '') => {
    const ph = (((frame - delay) % P) + P) % P / P;
    const o = kf(ph, [0, 0.16, 0.82, 1], [0, 1, 1, 0], [ease, (t) => t, ease]);
    const bl = kf(ph, [0, 0.16, 0.82, 1], [18, 0, 0, 18], [ease, (t) => t, ease]);
    const y = kf(ph, [0, 0.16, 0.82, 1], [26, 0, 0, -18], [ease, (t) => t, ease]);
    const s = kf(ph, [0, 0.16, 0.82, 1], [0.97, 1, 1, 1], [ease, (t) => t, ease]);
    return {opacity: o, filter: `blur(${bl}px)`, transform: `${extra} translateY(${y}px) scale(${s})`.trim()};
  };
  const blink = 0.5 + 0.5 * Math.cos((frame / P) * BLINK * Math.PI * 2); // 1 → 0 → 1
  return (
    <div style={{position: 'relative'}}>
      <div style={{position: 'absolute', width: '150%', height: '34%', left: '-25%', top: '30%', border: `1.5px solid ${C.line}`, borderRadius: '50%', ...reveal(3, 'rotate(-8deg)')}} />
      <div style={{display: 'flex', alignItems: 'center', fontSize: size, fontWeight: 900, letterSpacing: '-0.05em', lineHeight: 1, textShadow: `0 0 60px ${C.acc2}55, 0 0 14px ${C.fg}33`, ...reveal(0)}}>
        {WORD}
        <i style={{display: 'inline-block', width: '0.15em', height: '0.15em', borderRadius: '50%', background: C.acc2, marginLeft: '0.07em', marginTop: '0.5em', boxShadow: `0 0 34px ${C.acc2}`, opacity: 0.25 + 0.75 * blink, transform: `scale(${0.8 + 0.2 * blink})`}} />
      </div>
      <div style={{display: 'flex', justifyContent: 'space-between', marginTop: 20, paddingTop: 14, borderTop: `1.5px solid ${C.line}`, font: `500 ${size * 0.07}px ${MONO}`, letterSpacing: '0.32em', color: C.muted, ...reveal(5)}}>
        <span>{SUB}</span><span>SHOWREEL 2026</span>
      </div>
    </div>
  );
};""", word=w, sub=a, p=P, blink=blink)
    b = KF + b
    desc = r.choice([f"a cinematic title card: '{w}' with a glowing blinking dot, orbit ring and mono subtitle row ({a} / SHOWREEL 2026), {p['desc']}",
                     f"a motion-reel end card: heavy wordmark {w} blurring in, soft glow, thin divider and spaced caption, {T}s loop",
                     f"a premium brand outro with the wordmark {w}, accent dot and credits line"])
    plan = f"// PLAN: wordmark {w} with ring and subtitle row; each layer runs the same 4-stop blur/translate reveal over a {P}-frame loop with 0/3/5-frame delays; the accent dot blinks {blink}x per loop; {P} frames at {FPS} fps."
    return fam(r, p, desc, plan, b, ["Easing"], W, H, FPS, P, hud=hud, scaled=False)

def g_countdown(r, p):
    T = r.choice([4, 5]); ez_ = r.choice(["expo", "snappy", "smooth"]); fs = r.choice([140, 180, 220]) * 2; P = T * FPS; hud = hudlabel(r, "countdown", .8)
    b = tsx("""const SEQ = ['3', '2', '1', 'GO'];
const P = __P__, FS = __FS__;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = __E__;
  const ph = (frame % P) / P;
  // digits slide up through a clipped window; each hold is followed by an eased step
  const y = kf(ph, [0, 0.16, 0.24, 0.41, 0.49, 0.66, 0.74, 1], [0, 0, -FS, -FS, -2 * FS, -2 * FS, -3 * FS, -3 * FS], [(t) => t, ease, (t) => t, ease, (t) => t, ease, (t) => t]);
  const R = 46, circ = 2 * Math.PI * R;
  const prog = kf(ph, [0, 0.74, 1], [0, 1, 1], [(t) => t, (t) => t]);
  const ringOp = kf(ph, [0, 0.74, 1], [1, 1, 0.2], [(t) => t, (t) => t]);
  const S = FS * 1.9;
  return (
    <div style={{position: 'relative', display: 'grid', placeItems: 'center', width: S, height: S}}>
      <svg viewBox="0 0 100 100" style={{position: 'absolute', inset: 0, width: '100%', height: '100%', transform: 'rotate(-90deg)'}}>
        <circle cx="50" cy="50" r={R} fill="none" stroke={C.line} strokeWidth={1.5} />
        <circle cx="50" cy="50" r={R} fill="none" stroke={C.accent} strokeWidth={1.5} strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={circ * (1 - prog)} opacity={ringOp} />
      </svg>
      <div style={{height: FS, overflow: 'hidden', fontSize: FS, fontWeight: 900, letterSpacing: '-0.06em', lineHeight: `${FS}px`, textAlign: 'center'}}>
        <div style={{transform: `translateY(${y}px)`}}>
          {SEQ.map((s, i) => <div key={s} style={{height: FS, color: i === 3 ? C.accent : C.fg}}>{s}</div>)}
        </div>
      </div>
    </div>
  );
};""", p=P, fs=fs, e=ez(ez_))
    b = KF + b
    desc = r.choice([f"a 3-2-1-GO countdown where digits slide up through a mask with {ez_} easing and a progress ring draws around them, {p['desc']}",
                     "a title-sequence countdown: stacked numerals translating in a clipped window, accent GO, circular timer",
                     f"an animated countdown ({T}s loop, {fs}px numerals) with rolling digits and a ring"])
    plan = f"// PLAN: stacked numerals 3-2-1-GO in a {fs}px clipped window; translateY steps at 16/41/66% of a {P}-frame loop using {ez_} easing; a ring draws linearly to 74% then dims; {P} frames at {FPS} fps."
    return fam(r, p, desc, plan, b, ["Easing"], W, H, FPS, P, hud=hud, scaled=False)
