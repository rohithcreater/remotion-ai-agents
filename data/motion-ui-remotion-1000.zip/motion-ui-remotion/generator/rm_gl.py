import json, random, re
import make_dataset as md
from rm_core import *
from rm_mo1 import FPS, W, H

GL_BODY = """const FS = __FS__;
const VS = 'attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}';
const compile = (gl: WebGLRenderingContext, type: number, src: string) => {
  const s = gl.createShader(type)!;
  gl.shaderSource(s, src); gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s) ?? 'shader error');
  return s;
};
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const ref = React.useRef<HTMLCanvasElement | null>(null);
  React.useEffect(() => {
    const c = ref.current; if (!c) return;
    // preserveDrawingBuffer so the frame survives until Remotion screenshots it (render with --gl=angle)
    const gl = c.getContext('webgl', {preserveDrawingBuffer: true}); if (!gl) return;
    const pr = gl.createProgram()!;
    gl.attachShader(pr, compile(gl, gl.VERTEX_SHADER, VS));
    gl.attachShader(pr, compile(gl, gl.FRAGMENT_SHADER, FS));
    gl.linkProgram(pr); gl.useProgram(pr);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(pr, 'p');
    gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    gl.viewport(0, 0, width, height);
    gl.uniform1f(gl.getUniformLocation(pr, 't'), frame / fps);   // time is a pure function of the frame
    gl.uniform2f(gl.getUniformLocation(pr, 'r'), width, height);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
  }, [frame, fps, width, height]);
  return <canvas ref={ref} width={width} height={height} style={{position: 'absolute', inset: 0, width: '100%', height: '100%'}} />;
};"""

def _wrap(orig, name, plan_extra, dur=240):
    def g(r, p):
        r2 = random.Random(r.random())  # same rng consumption pattern independent of orig
        desc, html = orig(r2, p)
        m = re.search(r"const FS=(\".*?\");\n", html, re.S)
        fs = json.loads(m.group(1))
        hud = hudlabel(r, plan_extra[0], .8)
        desc = desc.replace("WebGL", "WebGL (inside Remotion)") if "WebGL" in desc else desc + ", rendered as a Remotion WebGL canvas"
        plan = f"// PLAN: full-screen fragment shader ({plan_extra[1]}) drawn to a WebGL canvas every frame with uniform t = frame/fps so any frame renders deterministically; {dur} frames at {FPS} fps, 1920x1080."
        return fam(r, p, desc, plan, tsx(GL_BODY, fs=json.dumps(fs)), [], W, H, FPS, dur, hud=hud, scaled=False)
    g.__name__ = name
    return g

g_gl_metaballs = _wrap(md.g_gl_metaballs, "g_gl_metaballs", ("smooth union / sdf", "raymarched smooth-min SDF metaballs with fresnel iridescence"))
g_gl_aurora = _wrap(md.g_gl_aurora, "g_gl_aurora", ("gradient mesh", "iterated sine domain warping for an aurora gradient"))
g_gl_contours = _wrap(md.g_gl_contours, "g_gl_contours", ("interference", "interfering radial waves drawn as contour isolines"))
