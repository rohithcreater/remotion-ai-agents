#!/usr/bin/env python3
"""
Polished motion / UI dataset, Remotion edition.
Every sample = a brief -> a complete 5-file Remotion v4 project (same record format as the remotion-curated dataset).
  python make_remotion_dataset.py --n 1000 --seed 7 --out dataset --preview 64
"""
import argparse, hashlib, json, os, random, re
import rm_ui, rm_ui2, rm_ui3, rm_mo1, rm_mo2, rm_gl
from rm_core import SYSTEM, project, assemble
from make_dataset import PALS, OPEN, CTX

GENS = [getattr(m, x) for m in (rm_ui, rm_ui2, rm_ui3, rm_mo1, rm_mo2, rm_gl) for x in dir(m) if x.startswith("g_")]
GENS.sort(key=lambda g: g.__name__)
CONS = ["Use only remotion and React, no other libraries.", "Every animated value must be derived from useCurrentFrame().",
        "It should loop seamlessly.", "Keep the visual style minimal and premium.", "Use refined easing, no linear motion unless intended.",
        "Make it feel like a high-end product demo.", "Add subtle depth with soft shadows.", "Deterministic: no Math.random, Date or CSS animations.",
        "Type-safe TypeScript that compiles under strict mode."]

def fmt_spec(r, f):
    W, H, fps, dur = f["W"], f["H"], f["fps"], f["dur"]; secs = dur / fps
    ar = "square (1080x1080)" if W == H else "16:9 (1920x1080)"
    return r.choice([f"Format: {ar}, {fps} fps, {secs:.1f} seconds.", f"{ar} video, {fps}fps, about {secs:.0f}s.",
                     f"Render as {W}x{H} at {fps} fps ({dur} frames).", f"Make it a {secs:.1f} second {ar} composition."])

def make_prompt(r, f):
    ctx = r.choice(CTX); s = f"{r.choice(OPEN)} a Remotion video of {f['desc']}{(' ' + ctx) if ctx else ''}."
    s += " " + " ".join(r.sample(CONS, r.randint(1, 2)))
    if r.random() < .75: s += " " + fmt_spec(r, f)
    return s[0].lower() + s[1:] if r.random() < .15 else s

def build(n, seed):
    r = random.Random(seed); seen, out = set(), []; pool = list(GENS); fails = {g: 0 for g in GENS}; i = 0
    while len(out) < n and pool:
        g = pool[i % len(pool)]; i += 1
        p = r.choice(PALS); f = g(r, p)
        assert not re.search(r"__[A-Z0-9]+__", f["video"]), g.__name__
        sid = f"mu-{len(out)+1:05d}"
        files = project(sid, f["video"], f["W"], f["H"], f["fps"], f["dur"])
        code = assemble(f["plan"], files)
        h = hashlib.md5(code.replace(sid, "").encode()).hexdigest()
        if h in seen:
            fails[g] += 1
            if fails[g] > 80: pool.remove(g)
            continue
        fails[g] = 0; seen.add(h)
        out.append({"id": sid, "source": "motion-ui", "family": g.__name__[2:], "palette": p["name"],
                    "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": make_prompt(r, f)},
                                 {"role": "assistant", "content": code}], "_files": files})
    return out

def write_projects(rows, outdir):
    for row in rows:
        for path, c in row["_files"].items():
            fp = f"{outdir}/{row['id']}_{row['family']}/{path}"; os.makedirs(os.path.dirname(fp), exist_ok=True); open(fp, "w").write(c)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--n", type=int, default=1000); ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", default="dataset"); ap.add_argument("--preview", type=int, default=0)
    a = ap.parse_args(); os.makedirs(a.out, exist_ok=True)
    data = build(a.n, a.seed); random.Random(a.seed).shuffle(data)
    # stratified split: every family appears in val (one each first), then fill to 5%
    nval = len(data) - int(len(data) * .95); val, seen_v = [], set()
    for row in data:
        if row["family"] not in seen_v and len(val) < nval: seen_v.add(row["family"]); val.append(row)
    ids = {x["id"] for x in val}
    for row in data:
        if len(val) >= nval: break
        if row["id"] not in ids: val.append(row); ids.add(row["id"])
    train = [x for x in data if x["id"] not in ids]; k = len(train)
    for name, rows in (("dataset", data), ("train", train), ("val", val)):
        with open(f"{a.out}/{name}.jsonl", "w", encoding="utf-8") as fh:
            for row in rows: fh.write(json.dumps({x: row[x] for x in row if x != "_files"}, ensure_ascii=False) + "\n")
    if a.preview:
        seen_f, pick = {}, []
        for row in data:
            if seen_f.get(row["family"], 0) < max(1, a.preview // len(GENS)): seen_f[row["family"]] = seen_f.get(row["family"], 0) + 1; pick.append(row)
        write_projects(pick, f"{a.out}/preview")
    print(f"{len(data)} samples | train {k} | val {len(val)} ({len({x['family'] for x in val})} families) -> {a.out}/")
