import json, math
from rm_core import *

FPS = 30; W, H = 1920, 1080

KF = """// piecewise keyframes: stops t[i]→v[i] with an easing function per segment
const kf = (ph: number, ts: number[], vs: number[], es: ((t: number) => number)[]) => {
  for (let i = 0; i < ts.length - 1; i++) {
    if (ph <= ts[i + 1]) {
      const k = (ph - ts[i]) / (ts[i + 1] - ts[i]);
      return vs[i] + (vs[i + 1] - vs[i]) * es[i](Math.min(1, Math.max(0, k)));
    }
  }
  return vs[vs.length - 1];
};
"""


SN = {
"rise": """const y = kf(ph, [0, 0.25, 0.75, 1], [115, 0, 0, -115], [ease, (t) => t, ease]);
          const style: React.CSSProperties = {transform: `translateY(${y}%)`};""",
"flip": """const a = kf(ph, [0, 0.25, 0.75, 1], [-90, 0, 0, 90], [ease, (t) => t, ease]);
          const style: React.CSSProperties = {transform: `translateY(${a * -0.66}%) rotateX(${a}deg)`};""",
"scale": """const s = kf(ph, [0, 0.25, 0.75, 1], [0.2, 1, 1, 1.6], [ease, (t) => t, ease]);
          const o = kf(ph, [0, 0.25, 0.75, 1], [0, 1, 1, 0], [ease, (t) => t, ease]);
          const style: React.CSSProperties = {transform: `scale(${s})`, opacity: o};""",
"blur": """const bl = kf(ph, [0, 0.25, 0.75, 1], [26, 0, 0, 26], [ease, (t) => t, ease]);
          const y = kf(ph, [0, 0.25, 0.75, 1], [24, 0, 0, -24], [ease, (t) => t, ease]);
          const style: React.CSSProperties = {filter: `blur(${bl}px)`, opacity: 1 - bl / 26, transform: `translateY(${y}px)`};""",
"wave": """const tri = Math.abs(((local / (P / 2)) % 2 + 2) % 2 - 1); // ping-pong 0..1 over P/2 frames
          const style: React.CSSProperties = {transform: `translateY(${(0.14 - 0.28 * ease(tri)) * size}px)`};""",
}

def g_kinetic(r, p):
    w = r.choice(WORDS); style = r.choice(["rise", "flip", "scale", "blur", "wave"]); stg = r.choice([.04, .06, .08]); T = r.choice([2.8, 3.4, 4.2])
    ez_ = r.choice(["smooth", "snappy", "springy"]); wt = r.choice([700, 800, 900]); cap = r.choice(["MOTION DESIGN", "SHOWREEL 2026", "MADE IN CODE", "EVERY FRAME"])
    P = round(T * FPS); S = max(1, round(stg * FPS)); dur = P * 2; hud = hudlabel(r, "kinetic type")
    b = tsx("""const WORD = '__WORD__';
const P = __P__, STAGGER = __S__; // loop length and per-letter delay in frames
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const ease = __E__;
  const size = Math.min(width * 0.15, height * 0.26);
  const capOp = kf(((frame % P) / P), [0, 0.15, 0.3, 0.75, 1], [0, 0, 1, 1, 0], [(t) => t, (t) => t, (t) => t, (t) => t]);
  return (
    <div>
      <div style={{display: 'flex', fontSize: size, fontWeight: __WT__, letterSpacing: '-0.045em', lineHeight: 1, perspective: 700}}>
        {WORD.split('').map((ch, i) => {
          const local = frame - i * STAGGER;
          const ph = local < 0 ? 0 : (local % P) / P;
          __STYLECODE__
          const mask: React.CSSProperties = __MASK__;
          return (
            <div key={i} style={mask}>
              <span style={{display: 'inline-block', transformOrigin: '50% 100%', ...style}}>{ch}</span>
            </div>
          );
        })}
      </div>
      <div style={{marginTop: 22, textAlign: 'center', font: `500 ${size * 0.07}px ${MONO}`, letterSpacing: '0.4em', color: C.muted, opacity: capOp}}>__CAP__</div>
    </div>
  );
};""", word=w, p=P, s=S, e=ez(ez_), wt=wt, cap=cap)
    b = (b.replace('          const ph = local < 0 ? 0 : (local % P) / P;\n','') if style == 'wave' else b).replace("__STYLECODE__", SN[style]).replace("__MASK__", "{overflow: 'hidden', padding: '0.06em 0.01em'}" if style in ("rise", "flip") else "{}")
    b = KF + b
    desc = r.choice([f"kinetic typography: '{w}' revealing letter by letter ({style}, {stg}s stagger), weight {wt}, with a mono caption, {p['desc']}",
                     f"a motion-design title: per-letter {style} animation of {w} with {ez_} easing on a {T}s loop",
                     f"bold kinetic type card spelling {w} with staggered {style} and a spaced-out subtitle"])
    plan = f"// PLAN: 1920x1080 kinetic title; each letter of {w} runs a {style} keyframe cycle of {P} frames with a {S}-frame stagger (letter phase = (frame - i*{S}) % {P}); caption fades in at 30% of the cycle; {dur} frames at {FPS} fps."
    return fam(r, p, desc, plan, b, ["Easing"], W, H, FPS, dur, hud=hud, scaled=False)

def g_squash(r, p):
    D = r.choice([140, 180, 220]) * 1.6; size = r.choice([56, 72, 90]) * 1.6; T = r.choice([1.0, 1.2, 1.5]); sq = r.choice([1.3, 1.45, 1.6])
    P = round(T * FPS); dur = P * 5; hud = hudlabel(r, "squash & stretch")
    b = tsx("""const P = __P__, D = __D__, SIZE = __SIZE__, SQ = __SQ__;
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ph = (frame % P) / P;
  const fall = Easing.bezier(0.55, 0, 1, 0.45), out = Easing.out(Easing.quad), rise = Easing.bezier(0, 0.55, 0.45, 1), lin = (t: number) => t;
  // keyframes mirror classic squash & stretch: stretch on fall → contact → squash → rebound
  const y = kf(ph, [0, 0.47, 0.5, 0.58, 1], [-D, 0, 0, -D * 0.45, -D], [fall, lin, rise, (t) => t * 0 + Easing.in(Easing.quad)(t)]);
  const sx = kf(ph, [0, 0.47, 0.5, 0.58, 1], [0.94, 0.88, SQ, 0.9, 0.94], [out, lin, out, lin]);
  const sy = kf(ph, [0, 0.47, 0.5, 0.58, 1], [1.06, 1.14, 0.6, 1.12, 1.06], [out, lin, out, lin]);
  const shadow = 0.5 - 0.5 * Math.cos(((1 - Math.abs(ph * 2 - 1) * 1) * Math.PI)); // 0 at top → 1 at floor
  const near = clamp01(1 - Math.abs(y) / D);
  return (
    <div style={{position: 'relative', width: 520, height: D + SIZE + 80}}>
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 20, height: 1.5, background: C.line}} />
      <div style={{position: 'absolute', left: '50%', bottom: 4, width: SIZE, height: 28, marginLeft: -SIZE / 2, borderRadius: '50%', background: '#000', opacity: 0.1 + 0.28 * near, filter: 'blur(10px)', transform: `scale(${0.45 + (SQ - 0.45) * near * (0.4 + 0.6 * shadow)}, 1)`}} />
      <div style={{position: 'absolute', left: '50%', bottom: 24, width: SIZE, height: SIZE, marginLeft: -SIZE / 2, borderRadius: '50%', background: `radial-gradient(circle at 35% 30%, #ffffffaa, #fff0 38%), ${C.accent}`, boxShadow: '0 -6px 18px #0002 inset', transformOrigin: '50% 100%', transform: `translateY(${y}px) scale(${sx}, ${sy})`}} />
    </div>
  );
};""", p=P, d=round(D), size=round(size), sq=sq)
    b = b.replace("[fall, lin, rise, (t) => t * 0 + Easing.in(Easing.quad)(t)]", "[fall, lin, rise, Easing.in(Easing.quad)]")
    b = KF + b
    desc = r.choice([f"a squash-and-stretch bouncing ball ({round(size/1.6)}px, {T}s cycle) with a glossy highlight and synced contact shadow, {p['desc']}",
                     f"classic animation-principles demo: a ball that stretches on the fall and squashes {sq}x on impact with a soft floor line",
                     "a bouncing sphere with anticipation, squash on landing and a blurred ground shadow"])
    plan = f"// PLAN: ball bounce with a {P}-frame period; piecewise keyframes at 0/47/50/58/100% drive translateY and anisotropic scale (squash x{sq} on contact), the contact shadow scales with proximity to the floor; {dur} frames at {FPS} fps."
    return fam(r, p, desc, plan, b, ["Easing"], W, H, FPS, dur, hud=hud, scaled=False)

def g_particles(r, p):
    n = r.choice([1400, 2000, 2800]) // 2; pull = r.choice([80, 120, 180]); trail = r.choice([.1, .16, .24])
    cols = r.choice([[p["accent"], p["fg"]], [p["accent"], p["acc2"], p["fg"]], [p["accent"], p["acc2"], p["muted"]]]); dur = 240; hud = hudlabel(r, "particle system", .7)
    K = 8 if trail < .15 else 12 if trail < .2 else 16
    b = tsx("""const N = __N__, PULL = __PULL__, TRAIL = __K__, DUR = __DUR__;
const COLS = __COLS__;
const WIDTH = 1920, HEIGHT = 1080;
// Deterministic simulation: positions for every frame are computed once, so any frame can be rendered in any order.
const TRAJ: Float32Array[] = (() => {
  const px = new Float32Array(N), py = new Float32Array(N), vx = new Float32Array(N), vy = new Float32Array(N);
  for (let i = 0; i < N; i++) { px[i] = rnd(i * 2 + 1) * WIDTH; py[i] = rnd(i * 2 + 2) * HEIGHT; }
  const out: Float32Array[] = [];
  for (let f = 0; f < DUR; f++) {
    const t = (f / 30) * 1000;
    const ax = WIDTH / 2 + Math.cos(t / 1100) * WIDTH * 0.25, ay = HEIGHT / 2 + Math.sin(t / 1700) * HEIGHT * 0.25;
    const snap = new Float32Array(N * 2);
    for (let i = 0; i < N; i++) {
      const dx = ax - px[i], dy = ay - py[i], d = Math.hypot(dx, dy) + 30, k = (PULL / d) * 0.0016 * 2;
      vx[i] = (vx[i] + dx * k) * 0.97; vy[i] = (vy[i] + dy * k) * 0.97;
      px[i] += vx[i] * 2; py[i] += vy[i] * 2;
      snap[i * 2] = px[i]; snap[i * 2 + 1] = py[i];
    }
    out.push(snap);
  }
  return out;
})();
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ref = React.useRef<HTMLCanvasElement | null>(null);
  React.useEffect(() => {
    const c = ref.current; if (!c) return;
    const x = c.getContext('2d'); if (!x) return;
    x.clearRect(0, 0, WIDTH, HEIGHT);
    const last = Math.min(frame, DUR - 1);
    for (let k = TRAIL; k >= 0; k--) {
      const f = Math.max(0, last - k), s = TRAJ[f];
      x.globalAlpha = (1 - k / (TRAIL + 1)) * 0.9;
      for (let i = 0; i < N; i++) { x.fillStyle = COLS[i % COLS.length]; x.fillRect(s[i * 2], s[i * 2 + 1], 3, 3); }
    }
    x.globalAlpha = 1;
  }, [frame]);
  return <canvas ref={ref} width={WIDTH} height={HEIGHT} style={{position: 'absolute', inset: 0, width: '100%', height: '100%'}} />;
};""", n=n, pull=pull, k=K, dur=dur, cols=cols)
    desc = r.choice([f"a canvas particle swarm of {n} dots orbiting a moving attractor with motion trails, {p['desc']}",
                     f"generative particle system: thousands of pixels pulled toward a Lissajous path (pull {pull})",
                     f"a 2D particle cloud that swirls and clusters, {K}-frame trails, palette-driven colors"])
    plan = f"// PLAN: {n} particles pulled toward a Lissajous attractor; because frames can render in any order the whole trajectory (positions per frame, seeded rnd) is precomputed at module load and the canvas draws the last {K} frames as fading trails; {dur} frames at {FPS} fps."
    return fam(r, p, desc, plan, b, [], W, H, FPS, dur, hud=hud, grain=False, scaled=False)

def g_flow(r, p):
    n = r.choice([1500, 2200, 3000]); sc = r.choice([.0016, .0024, .0034]); sp = r.choice([1.2, 1.8, 2.4])
    cols = [p["accent"], p["acc2"], p["fg"], p["muted"]][:r.choice([2, 3, 4])]; dur = 240; hud = hudlabel(r, "flow field", .7)
    b = tsx("""const N = __N__, SCALE = __SC__, SPEED = __SP__, DUR = __DUR__, TRAIL = 56;
const COLS = __COLS__;
const WIDTH = 1920, HEIGHT = 1080;
const angle = (x: number, y: number, t: number) =>
  (Math.sin(x * SCALE + t * 0.00018 * 1000 / 30) + Math.cos(y * SCALE * 1.3 - t * 0.00014 * 1000 / 30) + Math.sin((x + y) * SCALE * 0.6)) * Math.PI * 0.8;
// Precompute every particle path so rendering is a pure function of the frame number.
const PATHS: {xs: Float32Array; ys: Float32Array; a: Float32Array}[] = (() => {
  const out = [];
  for (let i = 0; i < N; i++) {
    let x = rnd(i * 3 + 1) * WIDTH, y = rnd(i * 3 + 2) * HEIGHT, life = 40 + rnd(i * 3 + 3) * 200;
    const xs = new Float32Array(DUR), ys = new Float32Array(DUR), a = new Float32Array(DUR);
    for (let f = 0; f < DUR; f++) {
      const ang = angle(x, y, f * 33.3);
      x += Math.cos(ang) * SPEED * 3; y += Math.sin(ang) * SPEED * 3; life--;
      if (life < 0 || x < 0 || y < 0 || x > WIDTH || y > HEIGHT) { x = rnd(i * 977 + f * 3.3) * WIDTH; y = rnd(i * 613 + f * 5.1) * HEIGHT; life = 120 + rnd(i * 31 + f) * 160; xs[f] = x; ys[f] = y; a[f] = -1; continue; }
      xs[f] = x; ys[f] = y; a[f] = ang;
    }
    out.push({xs, ys, a});
  }
  return out;
})();
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ref = React.useRef<HTMLCanvasElement | null>(null);
  React.useEffect(() => {
    const c = ref.current; if (!c) return;
    const x = c.getContext('2d'); if (!x) return;
    x.clearRect(0, 0, WIDTH, HEIGHT);
    x.lineWidth = 2; x.lineCap = 'round';
    const last = Math.min(frame, DUR - 1);
    for (let i = 0; i < N; i++) {
      const P = PATHS[i];
      const ang = P.a[last] < 0 ? 0 : P.a[last];
      x.strokeStyle = COLS[Math.floor((((ang / (Math.PI * 2)) % 1) + 1) % 1 * COLS.length)];
      for (let k = TRAIL; k > 0; k -= 1) {
        const f1 = last - k + 1, f0 = last - k;
        if (f0 < 0 || P.a[f1] < 0 || P.a[f0] < 0) continue;
        x.globalAlpha = Math.pow(1 - k / TRAIL, 1.6) * 0.85;
        x.beginPath(); x.moveTo(P.xs[f0], P.ys[f0]); x.lineTo(P.xs[f1], P.ys[f1]); x.stroke();
      }
    }
    x.globalAlpha = 1;
  }, [frame]);
  return <canvas ref={ref} width={WIDTH} height={HEIGHT} style={{position: 'absolute', inset: 0, width: '100%', height: '100%'}} />;
};""", n=n, sc=sc, sp=sp, dur=dur, cols=cols)
    desc = r.choice([f"a generative flow field: {n} particles following a swirling vector field and leaving long soft trails, {p['desc']}",
                     "an organic noise-driven flow-field artwork painting ribbons of light on canvas",
                     f"canvas generative art with sinusoidal flow (scale {sc}) and {len(cols)}-color angle mapping"])
    plan = f"// PLAN: {n} particles advected by a sinusoidal angle field; full paths are precomputed (seeded rnd for respawns) and each frame draws the previous 56 steps as alpha-faded segments coloured by heading; {dur} frames at {FPS} fps."
    return fam(r, p, desc, plan, b, [], W, H, FPS, dur, hud=hud, grain=False, scaled=False)

def g_stars(r, p):
    n = r.choice([500, 800, 1200]); sp = r.choice([.012, .02, .03]); dur = 240; hud = hudlabel(r, "warp field", .7)
    b = tsx("""const N = __N__, SPEED = __SP__ * 2;
const WIDTH = 1920, HEIGHT = 1080;
const DUR = __DUR__;
// cumulative travel distance so speed can breathe while each frame stays a pure function of its index
const TRAVEL: number[] = (() => { const a = [0]; for (let f = 1; f <= DUR + 1; f++) a.push(a[f - 1] + SPEED * (1.2 + Math.sin(((f / 30) * 1000) / 1800) * 0.9)); return a; })();
const depth = (i: number, f: number) => { const z = rnd(i * 3 + 3) - TRAVEL[f]; return ((z % 1) + 1) % 1; };
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ref = React.useRef<HTMLCanvasElement | null>(null);
  React.useEffect(() => {
    const c = ref.current; if (!c) return;
    const x = c.getContext('2d'); if (!x) return;
    x.clearRect(0, 0, WIDTH, HEIGHT);
    x.lineCap = 'round';
    const f = Math.min(frame, DUR), k = Math.min(WIDTH, HEIGHT) * 0.25;
    for (let i = 0; i < N; i++) {
      const sx = (rnd(i * 3 + 1) - 0.5) * 2, sy = (rnd(i * 3 + 2) - 0.5) * 2;
      const z = depth(i, f), pz = depth(i, Math.max(0, f - 1) );
      if (z > pz || z < 0.01) continue; // just respawned
      const x1 = WIDTH / 2 + (sx / z) * k, y1 = HEIGHT / 2 + (sy / z) * k;
      const x0 = WIDTH / 2 + (sx / pz) * k, y0 = HEIGHT / 2 + (sy / pz) * k;
      x.strokeStyle = sx * sy > 0.3 ? C.acc2 : C.fg;
      x.globalAlpha = Math.min(1, (1 - z) * 1.4); x.lineWidth = (1 - z) * 3.4;
      x.beginPath(); x.moveTo(x0, y0); x.lineTo(x1, y1); x.stroke();
    }
    x.globalAlpha = 1;
  }, [frame]);
  return <canvas ref={ref} width={WIDTH} height={HEIGHT} style={{position: 'absolute', inset: 0, width: '100%', height: '100%'}} />;
};""", n=n, sp=sp, dur=dur)
    b = b.replace("const C = {", "const C = {", 1)
    desc = r.choice([f"a hyperspace starfield with {n} stars streaking from the center, speed pulsing, {p['desc']}",
                     "a warp-speed starfield on canvas: radial streaks with perspective and breathing velocity",
                     "an infinite tunnel of stars rushing toward the viewer with motion-blur trails"])
    plan = f"// PLAN: {n} stars at fixed (x,y) seeds; depth z = frac(seed - cumulativeTravel[frame]) where travel integrates a breathing speed, each star is a streak from its previous-frame to current projected position; {dur} frames at {FPS} fps."
    return fam(r, p, desc, plan, b, [], W, H, FPS, dur, hud=hud, grain=False, scaled=False)

def g_glitch(r, p):
    w = r.choice(WORDS); T = r.choice([2.2, 3, 4]); off = r.choice([3, 4, 6]); c1, c2 = r.choice([("#ff2a55", "#22e6ff"), ("#ff3b1f", "#3b7bff"), ("#ff00aa", "#00ffd5")])
    P = round(T * FPS); dur = P * 2; hud = hudlabel(r, "glitch", .7); step = r.choice([2, 3])
    b = tsx("""const WORD = '__WORD__';
const P = __P__, OFF = __OFF__ * 2, STEP = __STEP__; // glitch re-rolls every STEP frames
const slice = (seed: number) => {
  const on = rnd(seed * 1.7) > 0.45;
  const a = Math.floor(rnd(seed * 3.1) * 80), b = Math.floor(rnd(seed * 5.3) * (100 - a - 5));
  const dx = (rnd(seed * 7.9) > 0.5 ? 1 : -1) * (2 + Math.floor(rnd(seed * 9.7) * 10)) * 2;
  return on ? {clip: `inset(${a}% 0 ${b}% 0)`, dx} : {clip: 'inset(0)', dx: 0};
};
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const size = Math.min(width * 0.16, height * 0.3);
  const ph = (frame % P) / P;
  const tick = Math.floor(frame / STEP);
  const sa = slice(tick + 11), sb = slice(tick + 97);
  // main word jitter only near the end of each loop
  const jit = ph > 0.9 && ph < 0.96 ? (ph < 0.93 ? 8 : -6) : 0;
  const layer = (color: string, left: number, s: {clip: string; dx: number}) => (
    <div style={{position: 'absolute', inset: 0, color, left, mixBlendMode: 'screen', clipPath: s.clip, transform: `translateX(${s.dx}px)`}}>{WORD}</div>
  );
  return (
    <div style={{position: 'relative', fontSize: size, fontWeight: 900, letterSpacing: '-0.045em', transform: `skewX(${jit}deg) translateX(${jit * 0.8}px)`}}>
      {WORD}
      {layer('__C1__', -OFF, sa)}
      {layer('__C2__', OFF, sb)}
      <div style={{position: 'fixed', inset: 0, background: 'repeating-linear-gradient(0deg, #0000 0 4px, #0000001f 4px 6px)', pointerEvents: 'none'}} />
    </div>
  );
};""", word=w, p=P, off=off, step=step, c1=c1, c2=c2)
    desc = r.choice([f"a digital glitch title for '{w}': RGB channel split, random clip slices, skew jitter and CRT scanlines",
                     f"glitch text with chromatic aberration ({c1}/{c2}) on a {p['desc']} background",
                     f"a VHS-style glitching word {w}, {T}s loop"])
    plan = f"// PLAN: '{w}' with two screen-blended colour layers; slice clip-path and x-offset are re-rolled every {step} frames from seeded rnd (deterministic glitch), skew jitter in the last 10% of a {P}-frame loop, scanline overlay; {dur} frames at {FPS} fps."
    return fam(r, p, desc, plan, b, [], W, H, FPS, dur, hud=hud, scaled=False)
