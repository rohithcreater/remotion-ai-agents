import json, math
from rm_core import *

def g_spinner(r, p):
    kind = r.choice(["ring", "dots", "pulse", "bars", "orbit", "morph"]); S = r.choice([44, 56, 64, 80, 96]) * 1.6
    W = r.choice([4, 5, 6, 8]); T = r.choice([.8, 1, 1.2, 1.6]); ez_ = r.choice(list(EASE)); fps = 30
    P = max(12, round(T * fps * (1.8 if kind == "morph" else 1.4 if kind == "orbit" else 1.6 if kind == "pulse" else 1))); dur = P * 4
    common = dict(s=round(S), w=W, p=P)
    if kind == "ring":
        b = tsx("""const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const rot = ((frame % __P__) / __P__) * 360;
  const R = 46, circ = 2 * Math.PI * R;
  return (
    <svg width={__S__} height={__S__} viewBox="0 0 100 100" style={{transform: `rotate(${rot}deg)`}}>
      <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor={C.accent} stopOpacity={0} /><stop offset="1" stopColor={C.accent} /></linearGradient></defs>
      <circle cx="50" cy="50" r={R} fill="none" stroke="url(#g)" strokeWidth={__W__ * 1.4} strokeLinecap="round" strokeDasharray={`${circ * 0.82} ${circ}`} />
    </svg>
  );
};""", **common)
    elif kind == "dots":
        b = tsx("""const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = __E__;
  const D = __D__, H = __H__;
  return (
    <div style={{display: 'flex', gap: __G__}}>
      {[0, 1, 2].map((i) => {
        const ph = (((frame - i * (__P__ / 6)) % __P__) + __P__) % __P__ / __P__;
        const up = ph < 0.5 ? ease(ph * 2) : 1 - ease((ph - 0.5) * 2);
        return <div key={i} style={{width: D, height: D, borderRadius: '50%', background: C.accent, opacity: 0.35 + 0.65 * up, transform: `translateY(${-H * up}px) scale(${0.8 + 0.2 * up})`}} />;
      })}
    </div>
  );
};""", **common, e=ez(ez_), d=round(S / 4), h=round(S / 3), g=round(S / 6))
    elif kind == "pulse":
        b = tsx("""const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = __E__;
  return (
    <div style={{position: 'relative', width: __S__, height: __S__}}>
      {[0, 0.5].map((off) => {
        const ph = (frame / __P__ + off) % 1, k = ease(ph);
        return <div key={off} style={{position: 'absolute', inset: 0, borderRadius: '50%', background: C.accent, opacity: 0.9 * (1 - k), transform: `scale(${0.2 + 0.95 * k})`}} />;
      })}
    </div>
  );
};""", **common, e=ez(ez_))
    elif kind == "bars":
        b = tsx("""const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <div style={{display: 'flex', gap: __W__, alignItems: 'center', height: __S__}}>
      {[0, 1, 2, 3, 4].map((i) => {
        const ph = (((frame - i * (__P__ / 9)) % __P__) + __P__) % __P__ / __P__;
        const sy = 0.25 + 0.75 * (0.5 - 0.5 * Math.cos(ph * Math.PI * 2));
        return <div key={i} style={{width: __W__ + 2, height: '100%', borderRadius: 99, background: C.accent, transform: `scaleY(${sy})`}} />;
      })}
    </div>
  );
};""", **common)
    elif kind == "orbit":
        b = tsx("""const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const rot = ((frame % __P__) / __P__) * 360;
  const D = __D__;
  return (
    <div style={{position: 'relative', width: __S__, height: __S__, transform: `rotate(${rot}deg)`}}>
      <div style={{position: 'absolute', inset: 0, borderRadius: '50%', border: `1px solid ${C.line}`}} />
      <div style={{position: 'absolute', top: -D / 2, left: '50%', width: D, height: D, marginLeft: -D / 2, borderRadius: '50%', background: C.accent, boxShadow: `0 0 22px ${C.accent}`}} />
    </div>
  );
};""", **common, d=W + 6)
    else:
        b = tsx("""const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ph = (frame % __P__) / __P__;
  const t = ph < 0.5 ? ph * 2 : 2 - ph * 2;
  const e = Easing.bezier(0.7, 0, 0.2, 1)(t);
  return (
    <div style={{width: __S__, height: __S__, background: C.accent, borderRadius: `${50 - 28 * e}%`, transform: `rotate(${ph * 360}deg) scale(${1 - 0.22 * e})`, boxShadow: `0 14px 40px ${C.sh}`}} />
  );
};""", **common)
    desc = r.choice([f"a {kind} loading indicator, {round(S)}px, {T}s cycle, {p['desc']} palette",
                     f"a minimal {kind}-style spinner with a {ez_} feel on a {p['desc']} background",
                     f"a premium {kind} loader with soft depth, {p['desc']}"])
    plan = f"// PLAN: a looping {kind} spinner, {P} frame period at {fps} fps, 1080x1080; phase = (frame % {P}) / {P} drives rotation/scale so the loop is seamless and deterministic."
    return fam(r, p, desc, plan, b, ["Easing"], 1080, 1080, fps, dur)

def g_segmented(r, p):
    labels = r.choice([["Day", "Week", "Month"], ["Monthly", "Yearly"], ["List", "Grid", "Board"], ["Light", "Dark", "System"],
                       ["Overview", "Activity", "Settings", "Billing"], ["Design", "Code", "Preview"]])
    n = len(labels); ez_ = r.choice(list(EASE)); dur_s = r.choice([.3, .4, .5, .65]); style = r.choice(["pill", "underline"]); fps = 30
    hold = 57; total = hold * n
    b = tsx("""const LABELS = __L__;
const HOLD = __HOLD__; // frames each tab stays selected
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = __E__;
  const n = LABELS.length;
  const step = Math.floor(frame / HOLD);
  const local = frame - step * HOLD;
  // slide from the previous tab to the current one during the first __D__ frames of each hold
  const from = step % n, to = (step + 1) % n;
  const t = ease(seg(local - (HOLD - __D__), 0, __D__, (x) => x));
  const wrap = to === 0 ? n : to;
  const sel = from + (wrap - from) * t;
  const active = Math.round(sel) % n;
  return __VIEW__;
};""", l=labels, hold=hold, e=ez(ez_), d=max(6, round(dur_s * fps)),
        view=("""(
    <div style={{position: 'relative', display: 'grid', gridTemplateColumns: `repeat(${n}, 1fr)`, padding: 6, borderRadius: 999, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 14px 40px ${C.sh}`, width: n * 112}}>
      <div style={{position: 'absolute', top: 6, bottom: 6, left: 6, width: `calc((100% - 12px) / ${n})`, borderRadius: 999, background: C.accent, boxShadow: `0 6px 18px ${C.sh2}`, transform: `translateX(${(sel % n) * 100}%)`}} />
      {LABELS.map((l, i) => (
        <div key={l} style={{position: 'relative', zIndex: 1, textAlign: 'center', padding: '12px 0', fontWeight: 600, fontSize: 15, letterSpacing: '-0.01em', color: i === active ? C.on : C.muted}}>{l}</div>
      ))}
    </div>
  )""" if style == "pill" else """(
    <div style={{position: 'relative', display: 'flex', gap: 30, borderBottom: `1px solid ${C.line}`}}>
      {LABELS.map((l, i) => (
        <div key={l} style={{padding: '14px 2px', fontWeight: 600, fontSize: 16, letterSpacing: '-0.01em', color: i === active ? C.fg : C.muted}}>{l}</div>
      ))}
      <div style={{position: 'absolute', bottom: -1, left: 0, height: 2, width: 44, borderRadius: 2, background: C.accent, transform: `translateX(${(sel % n) * 96}px)`}} />
    </div>
  )"""))
    desc = r.choice([f"a {style} segmented control with options {', '.join(labels)} ({ez_} easing, {dur_s}s)",
                     f"an animated tab switcher ({' / '.join(labels)}) with a gliding {'pill' if style=='pill' else 'underline'}, {p['desc']} theme",
                     f"a {style}-style tab bar: {', '.join(labels)}; auto-cycles through every tab"])
    plan = f"// PLAN: {style} tab switcher auto-cycling {n} tabs, each held {hold} frames; the indicator glides over {max(6, round(dur_s*fps))} frames with {ez_} easing, loop length {total} frames at {fps} fps."
    return fam(r, p, desc, plan, b, ["Easing", "interpolate"], 1080, 1080, fps, total)

def g_slider(r, p):
    label = r.choice(["Volume", "Brightness", "Speed", "Intensity"]); h = r.choice([8, 10, 14]); ez_ = r.choice(list(EASE)); fps = 30; P = 150
    b = tsx("""const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const ease = __E__;
  const ph = (frame / __P__) * Math.PI * 2;
  const val = 0.5 + 0.4 * Math.sin(ph);
  const active = Math.sin(ph) > 0.2 ? 1 : 0;
  const prevActive = Math.sin(ph - 0.12) > 0.2 ? 1 : 0;
  // smooth the hover state so the track grows and the thumb scales in
  const k = ease(clamp01((Math.sin(ph) - 0.05) / 0.5));
  const H = __H__ + __DH__ * k;
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 16, padding: '16px 22px', borderRadius: 999, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 18px 50px ${C.sh}`, width: 360}}>
      <svg viewBox="0 0 24 24" width={20} height={20} fill={C.fg}><path d="M3 9v6h4l5 4V5L7 9H3zm13.5 3A4.5 4.5 0 0 0 14 8v8a4.5 4.5 0 0 0 2.5-4z" /></svg>
      <div style={{position: 'relative', flex: 1, height: H, borderRadius: 99, background: C.line}}>
        <div style={{height: '100%', width: `${val * 100}%`, borderRadius: 'inherit', background: `linear-gradient(90deg, ${C.accent}, ${C.acc2})`, boxShadow: `0 0 18px ${C.accent}66`}} />
        <div style={{position: 'absolute', top: '50%', left: `${val * 100}%`, width: 20, height: 20, margin: '-10px 0 0 -10px', borderRadius: '50%', background: C.fg, boxShadow: `0 3px 10px ${C.sh2}`, transform: `scale(${k})`}} />
      </div>
      <span style={{font: `600 13px ${MONO}`, width: 30, textAlign: 'right', color: C.muted}}>{Math.round(val * 100)}</span>
    </div>
  );
};""", e=ez(ez_), p=P, h=h, dh=6)
    b = b.replace("  const active = Math.sin(ph) > 0.2 ? 1 : 0;\n  const prevActive = Math.sin(ph - 0.12) > 0.2 ? 1 : 0;\n", "")
    desc = r.choice([f"a {label.lower()} slider pill with a gradient fill and a thumb that grows in when active, {p['desc']}",
                     f"an animated {label.lower()} control: glassy pill, speaker icon, live readout driven by a sine sweep",
                     f"a {h}px-track {label.lower()} slider whose track thickens with a {ez_} transition"])
    plan = f"// PLAN: slider card; value = 0.5 + 0.4*sin(2π·frame/{P}); track height and thumb scale ease in while the value rises; {P} frame loop at {fps} fps."
    return fam(r, p, desc, plan, b, ["Easing"], 1080, 1080, fps, P * 2)

def g_player(r, p):
    g = r.choice(GRADS); title = r.choice(["motion study 02", "midnight loop", "kinetic sketch", "slow signal", "frame by frame", "blue hour"])
    sub = r.choice(["made in code", "generative", "ambient · 2:40", "live session", "demo reel"]); total = r.choice([150, 180, 200, 240]); fps = 30; dur = 300
    b = tsx("""const TRACK = __T__; // track length in seconds
const fmt = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const Icon: React.FC<{d: string; size?: number}> = ({d, size = 22}) => (
  <svg viewBox="0 0 24 24" width={size} height={size} fill={C.fg}><path d={d} /></svg>
);
const Scene: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const pos = (TRACK * 0.3 + frame / fps) % TRACK;
  const pct = (pos / TRACK) * 100;
  // pause for a beat in the middle of the loop, with a spring-like press on the button
  const pausing = frame > 120 && frame < 180;
  const press = frame >= 118 && frame < 130 ? 1 - 0.14 * Math.sin(((frame - 118) / 12) * Math.PI) : frame >= 178 && frame < 190 ? 1 - 0.14 * Math.sin(((frame - 178) / 12) * Math.PI) : 1;
  const shown = pausing ? (TRACK * 0.3 + 120 / fps) % TRACK : (TRACK * 0.3 + (frame > 180 ? frame - 60 : frame) / fps) % TRACK;
  const sp = (shown / TRACK) * 100;
  const sh = 50 + 50 * Math.sin((frame / durationInFrames) * Math.PI * 2 * 1.5);
  return (
    <div style={{width: 350, padding: 18, borderRadius: 30, background: C.card, boxShadow: `0 1px 0 ${C.line} inset, 0 30px 70px ${C.sh}`}}>
      <div style={{display: 'flex', gap: 14, alignItems: 'center'}}>
        <div style={{width: 68, height: 68, borderRadius: 18, background: 'linear-gradient(135deg, __G1__, __G2__, __G3__)', backgroundSize: '220% 220%', backgroundPosition: `${sh}% ${sh}%`, boxShadow: '0 10px 24px __G2__66'}} />
        <div>
          <div style={{fontSize: 16, fontWeight: 700, letterSpacing: '-0.02em'}}>__TITLE__</div>
          <div style={{fontSize: 13, color: C.muted}}>__SUB__</div>
        </div>
      </div>
      <div style={{margin: '20px 0 8px', height: 5, borderRadius: 9, background: C.line, position: 'relative'}}>
        <div style={{height: '100%', width: `${sp}%`, borderRadius: 'inherit', background: C.accent, position: 'relative'}}>
          <div style={{position: 'absolute', right: -6, top: '50%', width: 12, height: 12, marginTop: -6, borderRadius: '50%', background: C.accent, boxShadow: `0 2px 8px ${C.sh2}`}} />
        </div>
      </div>
      <div style={{display: 'flex', justifyContent: 'space-between', font: `11px ${MONO}`, color: C.muted}}>
        <span>{fmt(shown)}</span><span>-{fmt(TRACK - shown)}</span>
      </div>
      <div style={{display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 32, marginTop: 14}}>
        <Icon d="M6 5h2v14H6zM20 5v14L9 12z" />
        <div style={{transform: `scale(${press})`, display: 'grid', placeItems: 'center'}}>
          <Icon size={32} d={pausing ? 'M7 4v16l13-8z' : 'M6 5h4v14H6zM14 5h4v14h-4z'} />
        </div>
        <Icon d="M16 5h2v14h-2zM4 5v14l11-7z" />
      </div>
    </div>
  );
};""", t=total, g1=g[0], g2=g[1], g3=g[2], title=title, sub=sub)
    b = b.replace("  const pos = (TRACK * 0.3 + frame / fps) % TRACK;\n  const pct = (pos / TRACK) * 100;\n", "")
    desc = r.choice([f"a compact music player card titled '{title}' with animated gradient art, scrubber, time labels and play/pause",
                     f"a now-playing widget ({p['desc']}) with a moving progress bar and a springy pause/play press",
                     f"a media player UI card, {total}s track, soft shadows and a clean typographic hierarchy"])
    plan = f"// PLAN: music player card, 1080x1080 at {fps} fps, {dur} frames; the scrubber advances with frame/fps, pauses between frames 120-180 with a play-icon swap and button press scale; art gradient drifts with frame."
    return fam(r, p, desc, plan, b, ["Easing"], 1080, 1080, fps, dur)
